Use solar.uni as a template to create systems. Or download Planet Editor so you can edit systems with a graphical interface.

Mauricio Oliveira Carneiro - Hobbit
Sorhal Consultoria LTDA

http://www.sorhal.com.br/hobbit
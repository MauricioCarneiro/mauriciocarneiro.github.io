function client_loop (s)
    while true do
            local a = io.read("*l")
            if a == nil then break end 
            local e = s:write(a.."\n")
            if e then return false end
    end
    return true
end

local s = ssl.wrap("keys/client.pem", "keys/rootcert.pem")
s:connect("localhost", 16001)
print("Connection Opened")
if (client_loop(s)) then
    print("Connection Closed")
    s:shutdown()
else
    print("Connection Cleared")
    s:clear()
end
s:free()

function server_loop(s)
    while true do
        local a, e = s:read()
        if e == 0 then return true -- 0 for end of file
        else if e then return false end end -- halt on anything else
        io.write(a)
    end
    return true
end


local s = ssl.wrap("keys/server.pem", "keys/rootcert.pem", nil, "keys/dh1024.pem")
s:bind(16001)

while true do 
    s:accept()
    print("Connection Opened") 
    if server_loop(s) then
        s:shutdown()
        print("Connection Closed") 
    else
        s:clear()
        print("Connection Cleared")
    end
end

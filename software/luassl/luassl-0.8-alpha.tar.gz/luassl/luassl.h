/*=========================================================================*\
* Secure Socket Layer Support for LUA
* Author: Mauricio Oliveira Carneiro
* http://www.tecgraf.puc-rio.br/~carneiro/luassl
*
* last modified: 06/26/2003
\*=========================================================================*/
#ifndef LUASOCKET_H
#define LUASOCKET_H

/*-------------------------------------------------------------------------*\
* Current luassl version
\*-------------------------------------------------------------------------*/
#define LUASSL_VERSION "LuaSSL 0.1 - alpha"

/*-------------------------------------------------------------------------*\
* Library's namespace
\*-------------------------------------------------------------------------*/
#define LUASSL_LIBNAME "ssl"

/*-------------------------------------------------------------------------*\
* This macro prefixes all exported API functions
\*-------------------------------------------------------------------------*/
#ifndef LUASSL_API
#define LUASSL_API extern
#endif

#include <openssl/ssl.h>
#include <openssl/bio.h>

typedef struct t_ssl_ {
    SSL *obj;
    BIO *bio;
    SSL_CTX *ctx;
} t_ssl, *p_ssl;

/*-------------------------------------------------------------------------*\
* Initializes the library.
\*-------------------------------------------------------------------------*/
LUASSL_API int luaopen_ssllib(lua_State *L);

#endif /* LUASSL_H */

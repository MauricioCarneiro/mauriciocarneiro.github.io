/*=========================================================================*\
* Secure Socket Layer Support (SSL) for LUA
* Mauricio Oliveira Carneiro
* 
* last modified: 06/26/2003
\*=========================================================================*/

/*=========================================================================*\
* Standard include files
\*=========================================================================*/
#include <lua.h>
#include <lauxlib.h>

/*=========================================================================*\
* LuaSSL includes
\*=========================================================================*/
#include "luassl.h"
#include "common.h"
#include "auxiliar.h"

#include <string.h>
#include <openssl/bio.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <openssl/ssl.h>
#include <openssl/x509v3.h>

/*=========================================================================*\
* Exported functions
\*=========================================================================*/

static int luassl_wrap(lua_State *L);
static int luassl_connect(lua_State *L);
static int luassl_accept(lua_State *L);
static int luassl_bind(lua_State *L);
static int luassl_read(lua_State *L);
static int luassl_write(lua_State *L);
static int luassl_shutdown(lua_State *L);
static int luassl_clear(lua_State *L);
static int luassl_free(lua_State *L);
static int luassl_renegotiate(lua_State *L);
static int luassl_getport(lua_State *L);

static luaL_reg ssl_funcs[] = {
    {"wrap",        luassl_wrap},
    {"connect",     luassl_connect},
    {"bind",        luassl_bind},
    {"accept",      luassl_accept},
    {"read",        luassl_read},
    {"write",       luassl_write},
    {"shutdown",    luassl_shutdown},
    {"clear",       luassl_clear},
    {"free",        luassl_free},
    {"renegotiate", luassl_renegotiate},
    {"getport",     luassl_getport},
    {NULL,          NULL}
};

static int luassl_create(lua_State *L);
        
static luaL_reg func[] = {
    {"create",      luassl_create},
    {NULL,          NULL}
};

/*-------------------------------------------------------------------------*\
* Initializes all library modules.
\*-------------------------------------------------------------------------*/
LUASSL_API int luaopen_ssllib(lua_State *L)
{
    /* create namespace table */
    lua_pushstring(L, LUASSL_LIBNAME);
    lua_newtable(L);
    lua_settable(L, LUA_GLOBALSINDEX);
    /* make sure modules know what is our namespace */
    lua_pushstring(L, "LUASSL_LIBNAME");
    lua_pushstring(L, LUASSL_LIBNAME);
    lua_settable(L, LUA_GLOBALSINDEX);
    luaL_openlib(L, LUASSL_LIBNAME, func, 0);

    /* load all Lua code */
    lua_dofile(L, "luassl.lua");

    aux_newclass(L, "sslobj", ssl_funcs);
    return 0;
}

static int luassl_create(lua_State *L)
{
    lua_newtable(L);
    aux_setclass(L, "sslobj", -1);
    return 1;
}

static int luassl_wrap(lua_State *L) 
{
    SSL_CTX *ctx;

    const char *certfile   = luaL_optstring(L, 2, NULL);
    const char *cafile     = luaL_optstring(L, 3, NULL);
    const char *cadir      = luaL_optstring(L, 4, NULL);
    const char *dhfile     = luaL_optstring(L, 5, NULL);
    const char *cipherlist = luaL_optstring(L, 6, "ALL:!ADH:!LOW:!EXP:!MD5:@STRENGTH");
    int verify_options = luaL_optnumber(L, 7, SSL_VERIFY_PEER);
    int options = luaL_optnumber(L, 8, SSL_OP_ALL | SSL_OP_NO_SSLv2);

    if(!SSL_library_init())
        luaL_error(L, "** OpenSSL initialization failed!\n");

    SSL_load_error_strings();
    seed_prng();

    ctx = SSL_CTX_new(SSLv23_method());
    if ((cafile || cadir) && SSL_CTX_load_verify_locations(ctx, cafile, cadir) != 1)
        luaL_error(L, "Error loading CA file and/or directory");
    if ((cafile || cadir) && SSL_CTX_set_default_verify_paths(ctx) != 1)
        luaL_error(L, "Error loading default CA file and/or directory");
    if (certfile && SSL_CTX_use_certificate_chain_file(ctx, certfile) != 1)
        luaL_error(L, "Error loading certificate from file");
    if (certfile && SSL_CTX_use_PrivateKey_file(ctx, certfile, SSL_FILETYPE_PEM) != 1)
        luaL_error(L, "Error loading private key from file");
    SSL_CTX_set_verify(ctx, verify_options, verify_callback);
    SSL_CTX_set_verify_depth(ctx, 4);
    if (SSL_CTX_set_cipher_list(ctx, cipherlist) != 1)
        luaL_error(L, "Error setting cipher list (no valid ciphers)");
    SSL_CTX_set_options(ctx, options);

    if (dhfile)
    {
        BIO *dhbio;
        dhbio = BIO_new_file(dhfile, "r");
        if (!dhbio)
            luaL_error(L, "Error opening file %s", dhfile);
        SSL_CTX_set_tmp_dh(ctx, PEM_read_bio_DHparams(dhbio, NULL, NULL, NULL));
        BIO_free(dhbio);
    }

    /* Verificar se ja existe antes de criar */
    lua_pushstring(L, "ctx");
    lua_pushlightuserdata(L, ctx);
    lua_rawset(L, 1);

    return 1;
}

static int luassl_accept(lua_State *L)
{
    SSL     *ssl;
    BIO     *bio, *client;
    SSL_CTX *ctx;
    const char *cert = luaL_optstring(L, 2, NULL);
    int err;

    lua_pushstring(L, "bio");
    lua_rawget(L, 1);
    bio = (BIO *) lua_touserdata(L, -1);
    lua_pushstring(L, "ctx");
    lua_rawget(L, 1);
    ctx = (SSL_CTX *) lua_touserdata(L, -1);

    /* BIO accept */
    if (BIO_do_accept(bio) <= 0)
        luaL_error(L, "Error accepting connection");

    /* SSL accept */
    client = BIO_pop(bio);
    if (!(ssl = SSL_new(ctx)))
        luaL_error(L, "Error creating SSL context");
    SSL_set_accept_state(ssl);
    SSL_set_bio(ssl, client, client);
    if (SSL_accept(ssl) <= 0)
        luaL_error(L, "Error accepting SSL connection");


// Reavaliar importancia de POST CONNECTION CHECK 

    if (cert && (err = post_connection_check(ssl, cert)) != X509_V_OK)
        luaL_error(L, "-Error: peer certificate: %s\n Error checking certificates after connection", X509_verify_cert_error_string(err));



    /* Verificar se ja existe antes de criar */
    lua_pushstring(L, "ssl");
    lua_pushlightuserdata(L, ssl);
    lua_rawset(L, 1);

    return 0;
}

static int luassl_connect(lua_State *L)
{
    BIO        *bio;
    SSL        *ssl;
    SSL_CTX    *ctx;
    char       *server;
    const char *host = luaL_checkstring(L, 2);
    const char *port = luaL_checkstring(L, 3);
    const char *cert = luaL_optstring(L, 4, NULL);
    int        err;

    lua_pushstring(L, "bio");
    lua_gettable(L, 1);
    bio = (BIO *) lua_touserdata(L, -1);
    lua_pushstring(L, "ssl");
    lua_gettable(L, 1);
    ssl = (SSL *) lua_touserdata(L, -1);
    lua_pushstring(L, "ctx");
    lua_gettable(L, 1);
    ctx = (SSL_CTX *) lua_touserdata(L, -1);

    server = (char *) malloc (strlen(host) + strlen(port) + 2);
    strcpy(server, host);
    strcat(server, ":");
    strcat(server, port);


    bio = BIO_new_connect(server);
    if (!bio)
        luaL_error(L, "Error creating connection BIO");
    if (BIO_do_connect(bio) <= 0)
        luaL_error(L, "Error creating connection to remote machine");
    ssl = SSL_new(ctx);
    SSL_set_bio(ssl, bio, bio);
    if (SSL_connect(ssl) <= 0)
        luaL_error(L, "Error connecting SSL object");
    


//  Reavaliar importancia de POST CONNECTION CHECK
    if (cert && (err = post_connection_check(ssl, cert)) != X509_V_OK)
    {
        luaL_error (L, "-Error: peer certificate: %s\nError checking SSL object after connection", X509_verify_cert_error_string(err));
    }



    /* Verificar se ja existe antes de criar */
    lua_pushstring(L, "bio");
    lua_pushlightuserdata(L, bio);
    lua_rawset(L, 1);
    lua_pushstring(L, "ssl");
    lua_pushlightuserdata(L, ssl);
    lua_rawset(L, 1);

    return 0;
}
static int luassl_bind(lua_State *L)
{
    BIO *bio;
    char *port =(char *) luaL_checkstring(L, 2);

    bio = BIO_new_accept(port);
    if (!bio)
        luaL_error(L, "Error creating server socket");

    if (BIO_do_accept(bio) <= 0)
        luaL_error(L, "Error binding server socket");

    /* Verificar se ja existe antes de criar */
    lua_pushstring(L, "bio");
    lua_pushlightuserdata(L, bio);
    lua_rawset(L, 1);

    return 0;
}
static int luassl_read(lua_State *L)
{
    int err;
    SSL *ssl;
    char buf[20];

    lua_pushstring(L, "ssl");
    lua_gettable(L, 1);
    ssl = (SSL *) lua_touserdata(L, -1);

    err = SSL_read(ssl, buf, sizeof(buf)-1);

    if (err <= 0) {
        lua_pushnil(L);
        lua_pushnumber(L, err);
        return 2;
    }
    else {
        buf[err] = 0;
        lua_pushlstring(L, buf, err);
    }
    return 1;
}

static int luassl_write(lua_State *L)
{
    int err, lbuf, nwritten;
    SSL *ssl;
    const char *buf = luaL_checklstring(L, 2, &lbuf);

    lua_pushstring(L, "ssl");
    lua_gettable(L, 1);
    ssl = (SSL *) lua_touserdata(L, -1);

    for (nwritten = 0; nwritten < lbuf && err > 0; nwritten += err)
        err = SSL_write(ssl, buf, lbuf); 

    if (err <= 0) {
        lua_pushnumber(L, err);
        return 1;
    }
    return 0;
}
static int luassl_shutdown(lua_State *L)
{
    SSL *ssl;
    lua_pushstring(L, "ssl");
    lua_gettable(L, 1);
    ssl = (SSL *) lua_touserdata(L, -1);
    if (ssl) 
        SSL_shutdown(ssl);
    return 0;
}
static int luassl_clear(lua_State *L)
{
    SSL *ssl;
    lua_pushstring(L, "ssl");
    lua_gettable(L, 1);
    ssl = (SSL *) lua_touserdata(L, -1);
    if (ssl) 
        SSL_clear(ssl);
    return 0;
}
static int luassl_free(lua_State *L)
{
    SSL *ssl;
    SSL_CTX *ctx;
    lua_pushstring(L, "ssl");
    lua_gettable(L, 1);
    ssl = (SSL *) lua_touserdata(L, -1);
    if (ssl) 
        SSL_free(ssl);
    lua_pushstring(L, "ctx");
    lua_gettable(L, 1);
    ctx = (SSL_CTX *) lua_touserdata(L, -1);
    if (ctx) 
        SSL_CTX_free(ctx);
    return 0;
}
static int luassl_renegotiate(lua_State *L)
{
    SSL *ssl;
    lua_pushstring(L, "ssl");
    lua_gettable(L, 1);
    ssl = (SSL *) lua_touserdata(L, -1);
    SSL_renegotiate(ssl);
    SSL_do_handshake(ssl);
    return 0;
}

static int luassl_getport(lua_State *L)
{
    BIO *bio;
    char *port;
    lua_pushstring(L, "bio");
    lua_gettable(L, 1);
    bio = (BIO *) lua_touserdata(L, -1);
    port = BIO_get_accept_port(bio);
    lua_pushstring(L, port);
    free(port);
    return 1;
}


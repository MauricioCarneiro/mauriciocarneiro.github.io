#ifndef COMMON_H
#define COMMON_H

#include <openssl/ssl.h>
#include <openssl/x509v3.h>

int verify_callback(int ok, X509_STORE_CTX *store);
long post_connection_check(SSL *ssl, const char *host);
void seed_prng(void);

#endif /* COMMON_H */

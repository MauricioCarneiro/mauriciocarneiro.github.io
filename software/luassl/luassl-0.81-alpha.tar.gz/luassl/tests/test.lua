s = ssl.wrap("keys/client.pem", "keys/rootcert.pem")
s:connect("localhost", 16001, "Gandalf")
e = s:write("OLA POLEGAR!!!\n")

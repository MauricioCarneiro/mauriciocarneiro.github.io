/* ************************************************************************

   Copyright 2003 por: Mauricio Oliveira Carneiro <carneiro@tecgraf.puc-rio.br>
                       Rodolfo Jardim de Azevedo <rjazevedo@iname.com>

   Ultima alteracao: 22 de outubro de 2003

   E' dada permissao para modificar e redistribuir esse programa desde que
   essa mensagem de copyright seja mantida.

   Esse programa deve ser distribuido segundo a GPL 2.0 ou superior

 ************************************************************************ */

#ifndef _CORRECAO_H_
#define _CORRECAO_H_

#define MAX_PROBLEMAS 20
#define MAX_PARTICIPANTES 200
#define MAX_STRING 50
#define MAX_HORA 50

#define PLACAR "placar.conf"
#define PARTICIPANTES "participantes.conf"
#define HORA_CONTEST "hora_contest.tmp"

#define TEMPO_ZERO 0
#define TEMPO_PENALIDADE 20

typedef char mystring[MAX_STRING];

typedef struct {
	char id[10];
	mystring nome, submissao[MAX_PROBLEMAS]; 
	unsigned aceito[MAX_PROBLEMAS], erro[MAX_PROBLEMAS], pontos, submeteu;
	unsigned int hora[MAX_PROBLEMAS], penalidade; 
} TParticipante;

typedef struct {
	mystring numero, url;
} TProblemas;

typedef struct {
	mystring problema, hora, numero, id, resultado;
	int correta;
	char resto[10010];
} TSubmissao;

typedef struct {
	unsigned horas, minutos, segundos;
} Hora;

extern FILE *config, *particip;
extern unsigned nProblemas, nParticipantes;
extern mystring inicio, final, treino, hora_judge;
extern TProblemas problemas[MAX_PROBLEMAS];
extern TParticipante participantes[MAX_PARTICIPANTES];

void LeArquivos();
void LeHora();
void FechaArquivos();
void AbreArquivos();
void LeProblemas();
void LeParticipantes();
int ComparaParticipante(const void *p1, const void *p2);
int LeSubmissao(TSubmissao *submissao);
int LeLog(TSubmissao *submissao);
int ProblemaValido(char *problema);
int ParticipanteValido(char *participante);
void StringToMinutos(int *h, char *s);
void CalculaHora(int *destino, char *origem);
void CalculaResultado(TParticipante *participante);

int HoraValida(char *hora, char *inicio, char *final);

void ParseData(char *data);
void ParseHora(char *hora);
void TempoRestante(char *tempo);

#endif

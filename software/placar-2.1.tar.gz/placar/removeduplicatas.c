/* ************************************************************************

   Copyright 2003 por: Mauricio Oliveira Carneiro <carneiro@tecgraf.puc-rio.br>
                       Rodolfo Jardim de Azevedo <rjazevedo@iname.com>

   Ultima alteracao: 22 de outubro de 2003

   E' dada permissao para modificar e redistribuir esse programa desde que
   essa mensagem de copyright seja mantida.

   Esse programa deve ser distribuido segundo a GPL 2.0 ou superior

 ************************************************************************ */

#include <stdio.h>
#include "funcs.h"


char linhas[2][10000];

main()
{
  char atual = 1, ultima = 0;

  memset(linhas, 20000, 0);
  
  fgets(linhas[atual], 10000, stdin);
  strcpy(linhas[ultima], linhas[atual]);
  
  while (!feof(stdin)) {
    if (strcmp(linhas[atual], linhas[ultima])) {
      printf("%s", linhas[ultima]);
      ultima = !(atual = ultima);
    }
    fgets(linhas[atual], 10000, stdin);
  }

  printf("%s", linhas[ultima]);
}


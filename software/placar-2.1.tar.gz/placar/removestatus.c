/* ************************************************************************

   Copyright 2003 por: Mauricio Oliveira Carneiro <carneiro@tecgraf.puc-rio.br>
                       Rodolfo Jardim de Azevedo <rjazevedo@iname.com>

   Ultima alteracao: 22 de outubro de 2003

   E' dada permissao para modificar e redistribuir esse programa desde que
   essa mensagem de copyright seja mantida.

   Esse programa deve ser distribuido segundo a GPL 2.0 ou superior

 ************************************************************************ */

#include <stdio.h>
#include <string.h>
#include "funcs.h"

char linha[10000];

main(int argc, char *argv[])
{
  char ch = 0, descartando = 0;
  int contador;

  if (argc != 2) {
    fprintf(stderr, "Uso: %s <prefixo>\nRemove as linhas comecadas por <prefixo>\n",
	    argv[0]);
    exit(1);
  }

  while ((ch = getchar()) != EOF) {
    putchar(ch);
    if (ch == '\n') {
      scanf("%s", linha);
      if (!strcmp(linha, argv[1])) {
        fgets(linha, 10000, stdin);
        linha[0] = 0;
      }
      else
        printf("%s", linha);
    }
  }
}


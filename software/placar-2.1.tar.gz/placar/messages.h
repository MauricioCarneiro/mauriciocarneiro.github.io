#ifndef MESSAGES_H_
#define MESSAGES_H_

#define CONTEST_STARTS_IN	"Inicio: <span class=\"tempo\">"
#define CONTEST_TIME		"Hor&aacute;rio do Valladolid"
#define CONTEST_FINISHED	"<span class=\"tempo\">CONTEST ENCERRADO</span>"
#define TIME_LEFT			"Tempo Restante: <span class=\"tempo\">"
#define TEAMS				"Participantes"
#define SCORE				"Pontua&ccedil;�o"
#define PENALTY				"Penalidade"
#define SUBMISSION_STATS	"Submiss�es (Aceitas/Total)"

#endif

/* ************************************************************************

   Copyright 2003 por: Mauricio Oliveira Carneiro <carneiro@tecgraf.puc-rio.br>
                       Rodolfo Jardim de Azevedo <rjazevedo@iname.com>
		       Rafael Martinelli <martinelli@ime.uerj.br>

   Ultima alteracao: 03 de julho de 2004

   E' dada permissao para modificar e redistribuir esse programa desde que
   essa mensagem de copyright seja mantida.

   Esse programa deve ser distribuido segundo a GPL 2.0 ou superior

 ************************************************************************ */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "funcs.h"
#include "messages.h"

void ImprimeCabecalho(char * tempo_restante)
{
	int i;
	printf("<html>\n<head>\n<META HTTP-EQUIV=\"Refresh\" CONTENT=\"60\">\n<title>%s</title>\n<link href=\"placar.css\" rel=\"stylesheet\" type=\"text/css\">\n</head>\n<body>\n<div class=\"titulo\">%s</div>\n<br><div class=\"negrito\">%s</div><br><br><br>\n", treino, treino, tempo_restante);

	printf("<table border=\"0\" cellpadding=\"5\" align=\"center\">\n<tr class=\"fundo_escuro\">\n<td width=\"200\" class=\"negrito\">%s</td>\n", TEAMS);

	for (i = 0; i < nProblemas; i ++)
		printf("<td width=80><a href=\"%s\" target=\"_blank\">%s</a></td>\n", problemas[i].url, problemas[i].numero);
	printf("<td class=\"negrito\">%s</td><td class=\"negrito\">%s</td>\n", SCORE, PENALTY);
	printf("</tr>\n");
}

void ImprimeParticipante (int i)
{
	printf("<tr>\n\t<td class=\"fundo_escuro\"><a href=\"http://acm.uva.es/cgi-bin/OnlineJudge?AuthorInfo:%s\" target=\"_blank\">%s</a></td>\n", participantes[i].id, participantes[i].nome);
}

void MostraResultados(char * tempo_restante)
{
	unsigned int i, j;
	unsigned int nCorretas[MAX_PROBLEMAS], nErradas[MAX_PROBLEMAS],
	total1 = 0, total2 = 0;
	TSubmissao submissao;

	for (i = 0; i < nProblemas; i ++)
		nCorretas[i] = nErradas[i] = 0;
	for (i = 0; i < nParticipantes; i ++)
		CalculaResultado(&(participantes[i]));
	qsort(participantes, nParticipantes, sizeof(TParticipante), ComparaParticipante);

	ImprimeCabecalho(tempo_restante);

	for (i = 0; i < nParticipantes; i ++) {
		if (participantes[i].submeteu) {
			ImprimeParticipante(i);
			for (j = 0; j < nProblemas; j ++) {
				if (participantes[i].aceito[j]) {
					printf("\t<td class=\"accepted\">%d ", participantes[i].hora[j]);
					nCorretas[j] ++;
				}
				else
					printf("\t<td class=\"normal\">%d ", participantes[i].hora[j]);

				if (participantes[i].erro[j]) {
					printf("<span class=\"wrong\">(%d)</span></td>\n", participantes[i].erro[j]);
					nErradas[j] += participantes[i].erro[j];
				} else
					printf("<span class=\"wrong\">(%d)</span></td>\n", participantes[i].erro[j]);
			}
			printf("\t<td class=\"accepted\">%d</td><td class=\"accepted\">%d</td></tr>\n", participantes[i].pontos, participantes[i].penalidade);
		}
	}
	printf("<tr class=\"fundo_claro\">\n\t<td class=\"normal\">%s</td>\n", SUBMISSION_STATS);

	for (i = 0; i < nProblemas; i ++) {
		printf("\t<td class=\"normal\">%d/%d</td>\n", nCorretas[i],
				nCorretas[i] + nErradas[i]);
		total1 += nCorretas[i];
		total2 += nErradas[i];
	}

	printf("\t<td class=\"normal\">%d/%d</td><td>&nbsp;</td>\n</tr>\n</table>\n", total1, total1 + total2);
	puts("</font></center>\n</body>\n</html>");

}

main()
{
	mystring pular1, pular2, pular3, tempo_restante;
	unsigned iParticipante, iProblema;
	TSubmissao submissao;


	LeArquivos();
	LeHora();
	TempoRestante(tempo_restante);

	while (LeLog(&submissao)) {
		if (HoraValida(submissao.hora, inicio, final)) {
			if ((iProblema = ProblemaValido(submissao.problema)) != -1) {
				if ((!strcmp(submissao.resultado, "Compiling"))  ||
					(!strcmp(submissao.resultado, "Received")) ||
					(!strcmp(submissao.resultado, "Waiting")) ||
					(!strcmp(submissao.resultado, "Running"))) {
					continue;
				}

				if ((iParticipante = ParticipanteValido(submissao.id)) != -1){
					participantes[iParticipante].submeteu = 1;
					if (!participantes[iParticipante].aceito[iProblema])
						if (submissao.correta) {
							participantes[iParticipante].aceito[iProblema] = 1;
							CalculaHora(&participantes[iParticipante].hora[iProblema], submissao.hora);
							strcpy(participantes[iParticipante].submissao[iProblema], submissao.numero);
						}
						else {
							participantes[iParticipante].erro[iProblema] ++;
							participantes[iParticipante].submeteu = 1;
						}
				}
			}
		}
	}
	MostraResultados(tempo_restante);
}


/* ************************************************************************

   Copyright 2003 por: Mauricio Oliveira Carneiro <carneiro@tecgraf.puc-rio.br>
                       Rodolfo Jardim de Azevedo <rjazevedo@iname.com>

   Ultima alteracao: 22 de outubro de 2003

   E' dada permissao para modificar e redistribuir esse programa desde que
   essa mensagem de copyright seja mantida.

   Esse programa deve ser distribuido segundo a GPL 2.0 ou superior

 ************************************************************************ */

#include <stdio.h>
#include "funcs.h"

char line[10002];
main(int argc, char *argv[])
{
	char ch = 0, descartando = 0;
	int contador, n,i,j;
	char *p, time[100], date[200], date2[100];
	FILE *f;

	LeArquivos();
	
	/* vou atualizar a hora agora */
	*hora_judge = 0;
	if (argc != 2) {
		fprintf(stderr, "Uso: %s <N>\nRemove as primeiras N linhas da entrada\n",
				argv[0]);
		exit(1);
	}

	sscanf(argv[1], "%d", &n);
	*date=0;
	
	for (contador = 0; contador < n; contador ++) {
	fgets(line, 10000, stdin);
	if (!*hora_judge) {
		sscanf(line, " %*s %s %s %*s %s %n", date, date2, time, &j);
		if (!strcmp(date, "date")) {
				j = 0;
				for (i=0; i<strlen(date2); i++)
					if (date2[i] != '/')
						hora_judge[j++] = date2[i];
				p = time;
				hora_judge[j++] = *p;
				p++;
				hora_judge[j++] = *p;
				p+=2;
				hora_judge[j++] = *p;
				p++;
				hora_judge[j++] = *p;
				p+=2;
				hora_judge[j++] = *p;
				p++;
				hora_judge[j++] = *p;
				hora_judge[j] = 0;
			}
		}
	}

	f = fopen(HORA_CONTEST, "wt");
	if (*hora_judge) fprintf(f, "%s\n", hora_judge);
	else fprintf(f, "%s\n", final);
	fclose(f);

	while ((ch = getchar()) != EOF)
		putchar(ch);
}


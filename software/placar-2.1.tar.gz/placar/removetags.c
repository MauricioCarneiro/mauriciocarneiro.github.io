/* ************************************************************************

   Copyright 2003 por: Mauricio Oliveira Carneiro <carneiro@tecgraf.puc-rio.br>
                       Rodolfo Jardim de Azevedo <rjazevedo@iname.com>

   Ultima alteracao: 22 de outubro de 2003

   E' dada permissao para modificar e redistribuir esse programa desde que
   essa mensagem de copyright seja mantida.

   Esse programa deve ser distribuido segundo a GPL 2.0 ou superior

 ************************************************************************ */

#include <stdio.h>
#include "funcs.h"

main()
{
  char ch = 0, descartando = 0;
  int contador;

  while ((ch = getchar()) != EOF) {
    if (ch == '<')
      descartando = 1;
    else if (ch == '>') {
      descartando = 0;
      ch = ' ';
    }

    if (!descartando)
      putchar(ch);
  }
}


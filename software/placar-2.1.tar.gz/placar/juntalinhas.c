/* ************************************************************************

   Copyright 2003 por: Mauricio Oliveira Carneiro <carneiro@tecgraf.puc-rio.br>
                       Rodolfo Jardim de Azevedo <rjazevedo@iname.com>

   Ultima alteracao: 22 de outubro de 2003

   E' dada permissao para modificar e redistribuir esse programa desde que
   essa mensagem de copyright seja mantida.

   Esse programa deve ser distribuido segundo a GPL 2.0 ou superior

 ************************************************************************ */

#include <stdio.h>
#include <stdio.h>
#include <string.h>

#define STRINGS_POR_SUBMISSAO 6

int main (void)
{
	int i, j;
	char linha[1000], resultado[10000];
	resultado[0] = 0;
	for (j=0; j<10; j++) {
		scanf(" %[^\n] ", linha);
		strcat(resultado, linha);
		for (i=1; i<STRINGS_POR_SUBMISSAO; i++) {
			scanf(" %[^\n] ", linha);
			strcat(resultado, linha);
		}
		printf("%s\n", resultado);
		resultado[0] = 0;
	}
	return 0;
}

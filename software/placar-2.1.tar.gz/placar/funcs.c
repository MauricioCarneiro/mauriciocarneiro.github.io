/* ************************************************************************

   Copyright 2003 por: Mauricio Oliveira Carneiro <carneiro@tecgraf.puc-rio.br>
                       Rodolfo Jardim de Azevedo <rjazevedo@iname.com>

   Ultima alteracao: 22 de outubro de 2003

   E' dada permissao para modificar e redistribuir esse programa desde que
   essa mensagem de copyright seja mantida.

   Esse programa deve ser distribuido segundo a GPL 2.0 ou superior

 ************************************************************************ */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "funcs.h"
#include "messages.h"

FILE *config, *particip;
unsigned nProblemas, nParticipantes;
mystring inicio, final, treino, hora_judge;
TParticipante participantes[MAX_PARTICIPANTES];
TProblemas problemas[MAX_PROBLEMAS];

int ComparaParticipante(const void *p1, const void *p2)
{
	const TParticipante *participante1 = p1, *participante2 = p2;

	if (participante1 -> pontos < participante2 -> pontos)
		return 1;
	else if (participante2 -> pontos < participante1 -> pontos)
		return -1;
	else
		return participante1->penalidade - participante2->penalidade;
}


void AbreArquivos()
{
	config = fopen(PLACAR, "rt");
	if (!config) {
		fprintf(stderr, "Erro abrindo o arquivo %s\n", PLACAR);
		exit(1);
	}

	particip = fopen(PARTICIPANTES, "rt");
	if (!particip) {
		fprintf(stderr, "Erro abrindo o arquivo %s\n", PARTICIPANTES);
		exit(1);
	}
}


void FechaArquivos()
{
	fclose(config);
	fclose(particip);
}


void LeArquivos()
{
	char tmp[10000];
	AbreArquivos();

	fscanf(config, "%s %s ", inicio, final);
	fgets(tmp, 10000, config);
	fgets(tmp, 10000, config);
	fscanf(config, "%[^\n] ", treino);

	LeProblemas();
	LeParticipantes();

	FechaArquivos();
}

void LeHora()
{
	FILE *f;
	f = fopen(HORA_CONTEST, "rt");
	fscanf(f, "%s", hora_judge);
	fclose(f);
}


void LeProblemas()
{
	unsigned int contador, indice;

	fscanf(config, "%d ", &nProblemas);

	if (nProblemas > MAX_PROBLEMAS) {
		fprintf(stderr, "Numero de problemas (%d) superior ao maximo %d.\n", nProblemas, MAX_PROBLEMAS);
		exit(1);
	}

	for (contador = 0, indice = 0; contador < nProblemas; contador ++, indice++) {
		fscanf(config, "%s ", &(problemas[indice].numero));
		fscanf(config, "%[^\n] ", problemas[indice].url);
	}
}


void LeParticipantes()
{
	unsigned int contador, indice;

	nParticipantes = 0;

	while (!feof(particip)) {
		if (nParticipantes >= MAX_PARTICIPANTES) {
			fprintf(stderr, "Numero de participantes (%d) superior ao maximo %d.\n",
					nParticipantes, MAX_PARTICIPANTES);
			exit(1);
		}

		if (fscanf(particip, "%s ", participantes[nParticipantes].id) == 0) {
			nParticipantes ++;
			return;
		}
		fgets(participantes[nParticipantes].nome, MAX_STRING, particip);

		participantes[nParticipantes].nome[strlen(participantes[nParticipantes].nome) - 1] = 0;
		participantes[nParticipantes].submeteu = 0;

		for (contador = 0; contador < nProblemas; contador ++) {
			participantes[nParticipantes].aceito[contador] = 0;
			participantes[nParticipantes].erro[contador] = 0;
			participantes[nParticipantes].hora[contador] = 0;
			participantes[nParticipantes].submissao[contador][0] = '\0';
		}
		nParticipantes ++;
	}
}


int LeSubmissao(TSubmissao *submissao)
{
	char data[100], hora[100];
	int r;	
	r = scanf(" %s %s %s %s %s %s", data, hora, submissao -> numero, submissao ->
			id, submissao -> problema, submissao -> resultado);
	if (r!=6) return 0;
	memset(submissao->resto, 0, 1010);
	fgets(submissao->resto, 1000, stdin);
	ParseData(data);
	ParseHora(hora);
	strcpy(submissao->hora, data);
	strcat(submissao->hora, hora);
	submissao -> correta = ! strcmp(submissao -> resultado, "Accepted");
	return 1;
}

int LeLog(TSubmissao *submissao)
{
	int r;	
	r=scanf("%s %s %s %s %s", submissao->hora, submissao -> numero, submissao ->
			id, submissao -> problema, submissao -> resultado);
	if (r!=5) return 0;
	scanf("%[^\n] ", submissao->resto);
	submissao -> correta = ! strcmp(submissao -> resultado, "Accepted");
	return 1;
}

int ProblemaValido(char *problema)
{
	unsigned int contador;

	for (contador = 0; contador < nProblemas; contador ++)
		if (!strcmp(problema, problemas[contador].numero))
			return contador;

	return -1;
}


int ParticipanteValido(char *participante)
{
	unsigned int contador;

	for (contador = 0; contador < nParticipantes; contador ++)
		if (!strcmp(participante, participantes[contador].id))
			return contador;

	return -1;
}


void StringToMinutos(int *h, char *s)
{
	int l;
	l = strlen(s)-3;
	*h = s[l--];
	*h += s[l--] * 10;
	*h += s[l--] * 60;
	*h += s[l--] * 600;
}

void CalculaHora(int *destino, char *origem)
{
	int h, i;

	StringToMinutos(&h, origem);
	StringToMinutos(&i, inicio);

	/* se o contest vira a meia noite, o dia da submissao sera diferente
	  do dia de inicio, precisando assim somar os tempos, assumo aqui que
	  a diferenca, se existir, eh de um dia. */ 
	if (strncmp(origem, inicio, 8)) 
		*destino = (24*60) - i + h;
	else
		*destino = h - i;
}

void CalculaResultado(TParticipante *participante)
{
	unsigned int contador, contador2;

	participante -> pontos = 0;
	participante->penalidade = 0;

	for (contador = 0; contador < nProblemas; contador ++)
		if (participante -> aceito[contador]) {
			participante -> pontos ++;
			participante->penalidade += participante->hora[contador];
			for (contador2 = 0; contador2 < participante -> erro[contador]; contador2 ++)
				participante->penalidade += TEMPO_PENALIDADE;
		}
}

int HoraValida(char *hora, char *inicio, char *final)
{
	return  strcmp(hora, inicio) >= 0 && strcmp(hora, final) <= 0;
}

void ParseData(char *data)
{
	int i, j=0;
	char data2[100];
	int l = strlen(data);
	for (i=0; i<=l; i++)
		if (data[i] != '/')
			data2[j++] = data[i];
	strcpy(data, data2);
}

void ParseHora(char *hora)
{
	int i, j=0;
	char hora2[100];
	int l = strlen(hora);
	for (i=0; i<l; i++) {
		if (hora[i] == '.') {
			hora2[j]=0;
			break;
		}
		if (hora[i] != ':')
			hora2[j++] = hora[i];
	}
	strcpy(hora, hora2);
}

void TempoRestante(char * tempo)
{
	char t[20];
	int l = strlen(hora_judge),i,j,vaium=0;
	int d1s, d1m, d1h, d2s, d2m, d2h; 
	long long d1;

	if ((strcmp(hora_judge, inicio) < 0) && strncmp(inicio, final, 8) <= 0) {
		strcpy(tempo, CONTEST_STARTS_IN);
		j = strlen(tempo);
		for (i=0; i<strlen(inicio); i++) {
			if (i%2==0 && i!=2 && i) {
				if (i<=6) tempo[j++] = '/';
				else if (i==8) {tempo[j]=0; strcat(tempo, " - "); j+=3; }
				else tempo[j++] = ':';
			}
			tempo[j++] = inicio[i];
		}
		tempo[j] = 0;
		strcat(tempo, "</span><br>");
		strcat(tempo, CONTEST_TIME);
		return;
	}

	if (strcmp(hora_judge, final) >= 0) {
		strcpy(tempo, CONTEST_FINISHED);
		return;
	}
	
	/* se o contest vira a meia noite, o dia da submissao sera diferente
	  do dia de inicio, precisando assim somar os tempos, assumo aqui que
	  a diferenca, se existir, eh de um dia. */ 

	if (strncmp(hora_judge, final, 8)) {
		/* soma final com 24-hora_judge */
		d1s = atoi(hora_judge+12);
		d1m = atoi(hora_judge+10) - d1s;
		d1h = atoi(hora_judge+8) - d1m - d1s;
		d2s = atoi(final+12);
		d2m = atoi(final+10) - d2s;
		d2h = atoi(final+8) - d2m - d2s;


		if (d1s > 0) {
		   	d1s = 60 - d1s;
			vaium = 100;
		}
		if (d1m > -vaium) {
			d1m = 6000-vaium - d1m;
			vaium = 10000;
		}
		else vaium = 0;
		d1h = 240000-vaium - d1h;


		/* soma com hora final */
		vaium = d1s + d2s;
		d1s = vaium % 60;
		vaium /= 60;
		vaium *= 100;

		vaium = d1m + d2m + vaium;
		d1m = vaium % 6000;
		vaium /= 6000;
		vaium *= 10000;

		d1h = d1h + d2h + vaium;


		vaium = d1h + d2h + vaium;

	
		d1 = d1h + d1m + d1s;
		if (d1 <= 0) {
			strcpy(tempo, CONTEST_FINISHED);
			return;
		}
		sprintf(t, "%06lld", d1);
	}
	else  {
		/* subtrai hora_judge de final */
		d1s = atoi(hora_judge+12);
		d1m = atoi(hora_judge+10) - d1s;
		d1h = atoi(hora_judge+8) - d1m - d1s;
		d2s = atoi(final+12);
		d2m = atoi(final+10) - d2s;
		d2h = atoi(final+8) - d2m - d2s;


		if (d2s < d1s) {
			vaium = 100;
			d1s = d2s+60 - d1s;
		}
		else d1s = d2s - d1s;
		if (d2m-vaium < d1m) { 
			d1m = (d2m-vaium)+6000 - d1m;
			vaium = 10000;
		}
		else {
			d1m = d2m - vaium - d1m;
			vaium = 0;
		}
		d1h = d2h-vaium - d1h;

		d1 = d1h + d1m + d1s;
		if (d1 <= 0) {
			strcpy(tempo, CONTEST_FINISHED);
			return;
		}
		sprintf(t, "%06lld", d1);
	}
	strcpy(tempo, TIME_LEFT);
	j = strlen(tempo);
	for (i=0; i<6; i++,j++) {
		if (i==2||i==4)
			tempo[j++] = ':';
		tempo[j] = t[i];
	}
	tempo[j] = 0;
	strcat(tempo, "</span>");
}

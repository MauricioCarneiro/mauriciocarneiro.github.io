/******************************************************************************
 * Splice Finder                                                              *
 * Author: Mauricio Carneiro                                                  *
 * http://www.procc.fiocruz.br/~carneiro                                      *
 ******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *seq;

/******************************************************************************
 * fasta_open                                                                 *
 *                                                                            *
 * Opens a fasta file and put the sequence on the 'seq' global variable       *
 ******************************************************************************/
int fasta_open (char *filename)
{
    FILE *f = fopen(filename, "r");
    int l, lseq, step;
    char *tseq, sname[2000];
    if (!f) {
        fprintf(stderr, "File %s not found\n", filename);
        return 0;
    }

    /* Discard the sequence header */
    fscanf(f, ">%s %*[^\n] ", sname);
    printf("Reading sequence %s...\n", sname);
    
    lseq = step = 1000000;
    tseq = seq = (char *) malloc (lseq + 1);
    l = 0;
    while (fgets(tseq, step-l+1, f)) {
        int k = strlen(tseq);
        l += k - 1; /* amount read so far without the '\n' */
        if (l == step) {
            lseq += step; /* increase the size by step */
            seq = (char *) realloc (seq, lseq + 1); /* alloc more memory */
            /* Assert we have enough memory */
            if (!seq) {
                fprintf(stderr, "Not enough memory, sequence too big!\n");
                return 0;
            }
            l=0; /* reset the amount read in this (next) step */
        } 
        if (tseq[k-1] == '\n')
            tseq += k - 1; /* ready to read the next line beginning from the '\n' */
        else 
            tseq += k; /* special case where we read one full step and didn't reach a '\n' */
    }
    if (seq[strlen(seq) - 1] == '\n')
        seq[strlen(seq) - 1] = 0;  /* chop the last '\n' */
    return 1;
}

int find_opening (int from, int to)
{
    int i,c;
    c=0; /* machine state */
    for (i=from; i<=to; i++) {
        if (c) {
            if (seq[i] == 't' || seq[i] == 'T') 
                return i;
            c=0;
        }
        if (seq[i] == 'g' || seq[i] == 'G') 
            c=1;
    }
    return -1;
}

int find_closure (int from, int to)
{
    int i,c;
    c=0; /* machine state */
    for (i=from; i>=to; i--) {
        if (c) {
            if (seq[i] == 'a' || seq[i] == 'A') 
                return i;
            c=0;
        }
        if (seq[i] == 'g' || seq[i] == 'G') 
            c=1;
    }
    return -1;
}

int main (int argc, char **argv)
{
    int from, to, count, i;
    int start[200], end[200], nstart, nend;

    /* Assert correct parameters */
    if (argc < 2) {
        fprintf(stderr, "Correct usage:\n\t%s <sequence.fasta> [count] [from] [to]\n\nWhere:\n\tcount - the number of openings/closures to print (default: 5)\n\tfrom - position in the sequence to start searching (default: 1)\n\tto - position in the sequence to stop searching (default: end of sequence)\n\nExample:\n\t%s dmel.fasta 10 125 5000\n", argv[0], argv[0]);
        return 1;
    }

    /* Assert that we can open the file and read the contents */
    if(!fasta_open(argv[1])) return 1;

    if (argc > 2) count = atoi(argv[2]); else count = 5;
    if (argc > 3) from = atoi(argv[2]) - 1; else from = 0;
    if (argc > 4) to = atoi(argv[3]) - 1; else to = strlen(seq) - 1;

    /* just to make sure we don't go outta boundaries */
    if (from < 0) from = 0;
    if (to >= strlen(seq)) to = strlen(seq) - 1;

    for (i=0; i<count; i++) {
        int k;
        if (i) k = start[i-1]; else k = from;
        start[i] = find_opening(k, to);

        /* Assert we found an opening */
        if (start[i] < 0) break;
    }
    nstart = i;
    /* Assert that we have found at least one opening */
    if (nstart == 0) {
        fprintf(stderr, "No opening was found\n");
        return 1;
    } 

    for (i=0; i<count; i++) {
        int k;
        if (i) k = end[i-1]; else k = to;
        end[i] = find_closure(k, from);

        /* Assert we found a closure */
        if (end[i] < 0) break;
    }
    nend = i;
    /* Assert that we have found at least one closure */
    if (nend < 0) {
        fprintf(stderr, "No closure was found\n");
        return 1;
    }

	free(seq);
    printf("\nopening candidates =");
    for (i=0; i<nstart; i++) printf(" %d", start[i]+1);
    printf("\nclosure candidates =");
    for (i=0; i<nend; i++)   printf(" %d", end[i]+1);
    printf("\n");
    return 0;
}

---------------------------------------------------------------------------
-- Default model description file
---------------------------------------------------------------------------
function brain()
  dvrlua_setvolumeinfo(62, 128, 128, 84, 1, 1, 1)
  dvrlua_loadvolume("brain.vol")
  dvrlua_setlight(0, 0, 0, -1, 100, 100, 100, 1)
end

function syn_64()
  dvrlua_setvolumeinfo(36, 64, 64, 64, 1, 1, 1)
  dvrlua_loadvolume("syn_64.vol")
  dvrlua_setlight(0, 0, 0, 1, 0, 255, 0, 0)
end

function toe()
  dvrlua_setvolumeinfo(0, 48, 101, 11, 1, 1, 4)
  dvrlua_loadvolume("toe.vol")
  dvrlua_setlight(0, 0, 0, -1, 100, 100, 100, 1)
end

function foot()
  dvrlua_setvolumeinfo(0, 40, 108, 46, 1, 1, 1)
  dvrlua_loadvolume("foot.vol")
  dvrlua_setlight(0, 0, 0, -1, 100, 100, 100, 1)
end  

toe()

/*
 * linalg.c
 *
 * A simple linear algebra package.
 *
 * Copyright (c) 1994 The Board of Trustees of The Leland Stanford
 * Junior University.  All rights reserved.
 *
 * Permission to use, copy, modify and distribute this software and its
 * documentation for any purpose is hereby granted without fee, provided
 * that the above copyright notice and this permission notice appear in
 * all copies of this software and that you do not sell the software.
 * Commercial licensing is available by contacting the author.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
 *
 * Author:
 *    Phil Lacroute
 *    Computer Systems Laboratory
 *    Electrical Engineering Dept.
 *    Stanford University
 *
 * Altered by: Ana Elisa Schmidt, Diego Nehab
 *
 */


#include <string.h>
#include <math.h>
#include <assert.h>

#include "linalg.h"

#define M_PI  3.14159265358979323846264338327950288  /* PI */

/*
 * laAddVector3
 *
 * Performs v3 = v2 + v1.
 */

void laAddVector3(laVector3 v3, laVector3 v2, laVector3 v1)
  {
    v3[iX] = v2[iX] + v1[iX];
    v3[iY] = v2[iY] + v1[iY];
    v3[iZ] = v2[iZ] + v1[iZ];
  }

/*
 * laAddVector4
 *
 * Performs v3 = v2 + v1.
 */

void laAddVector4(laVector4 v3, laVector4 v2, laVector4 v1)
  {
    v3[iX] = v2[iX] + v1[iX];
    v3[iY] = v2[iY] + v1[iY];
    v3[iZ] = v2[iZ] + v1[iZ];
  }

/*
 * laSubVector3
 *
 * Performs v3 = v2 - v1.
 */

void laSubVector3(laVector3 v3, laVector3 v2, laVector3 v1)
  {
    v3[iX] = v2[iX] - v1[iX];
    v3[iY] = v2[iY] - v1[iY];
    v3[iZ] = v2[iZ] - v1[iZ];
  }

/*
 * laSubVector4
 *
 * Performs v3 = v2 - v1.
 */

void laSubVector4(laVector4 v3, laVector4 v2, laVector4 v1)
  {
    v3[iX] = v2[iX] - v1[iX];
    v3[iY] = v2[iY] - v1[iY];
    v3[iZ] = v2[iZ] - v1[iZ];
  }

/*
 * laCopyVector3
 *
 * Performs v2 := v1.
 */

void laCopyVector3(laVector3 v2, laVector3 v1)
  {
    memcpy(v2, v1, sizeof (laVector3));
  }
 
/*
 * laCopyVector4
 *
 * Performs v2 := v1.
 */

void laCopyVector4(laVector4 v2, laVector4 v1)
  {
    memcpy(v2, v1, sizeof (laVector4));
  }
 
/*
 * laCopyMatrix3
 *
 * Performs m2 := m1.
 */

void laCopyMatrix3(laMatrix3 m2, laMatrix3 m1)
  {
    memcpy(m2, m1, sizeof (laMatrix3));
  }
 
/*
 * laCopyMatrix3
 *
 * Performs m2 := m1.
 */

void laCopyMatrix4(laMatrix4 m2, laMatrix4 m1)
  {
    memcpy(m2, m1, sizeof (laMatrix4));
  }
 
/*
 * MatrixMult
 *
 * Perform the matrix multiplication p = a * b.
 */

void laMatrixMult(double *p, double *a, double *b, int l, int m, int n)
  /*
  double *p;   result matrix, size l by n 
  double *a;   first factor, size l by m 
  double *b;   second factor, size m by n 
  */
  {
    int i, j, k;

    assert(l > 0 && m > 0 && n > 0);

    for (i = 0; i < l; i++) 
    {
        for (j = 0; j < n; j++) 
        {
            p[i*n+j] = 0;
            for (k = 0; k < m; k++)
                p[i*n+j] += a[i*n+k] * b[k*n+j];
        }
    }
  }    

/*
 * laIdentity3
 *
 * Initialize a Matrix3 to the identity.
 */

void laIdentity3( laMatrix3 m)
{
    m[0][0] = 1.;    m[0][1] = 0.;    m[0][2] = 0.;
    m[1][0] = 0.;    m[1][1] = 1.;    m[1][2] = 0.;
    m[2][0] = 0.;    m[2][1] = 0.;    m[2][2] = 1.;
}

/*
 * laIdentity4
 *
 * Initialize a Matrix4 to the identity.
 */

void laIdentity4(laMatrix4 m)
{
    m[0][0] = 1.;    m[0][1] = 0.;    m[0][2] = 0.;    m[0][3] = 0.;
    m[1][0] = 0.;    m[1][1] = 1.;    m[1][2] = 0.;    m[1][3] = 0.;
    m[2][0] = 0.;    m[2][1] = 0.;    m[2][2] = 1.;    m[2][3] = 0.;
    m[3][0] = 0.;    m[3][1] = 0.;    m[3][2] = 0.;    m[3][3] = 1.;
}

/*
 * laNormalize3
 *
 * Normalize a vector (divide it by its magnitude).  Return VPERROR_SINGULAR
 * if the magnitude is too small.
 */

int laNormalize3(laVector3 v)
{
    double magsqr, invmag;
    int i;

    magsqr = 0.;
    for (i = 0; i < 3; i++)
       magsqr += v[i]*v[i];
    if (fabs(magsqr) < FLT_ZERO)
        return(0);
    invmag = 1. / sqrt(magsqr);
    for (i = 0; i < 3; i++)
        v[i] *= invmag;
    return(1);
}

/*
 * laMatrixVectorMult4
 *
 * Perform the matrix-vector multiplication v2 = m*v1.
 */

void laMatrixVectorMult4(laVector4 v2, laMatrix4 m, laVector4 v1)
{
    int i, j;

    for (i = 0; i < 4; i++) {
        v2[i] = 0;
        for (j = 0; j < 4; j++)
            v2[i] += m[i][j] * v1[j];
    }
}

/*
 * laMatrixMult4
 *
 * Perform the matrix multiplication m3 = m2 * m1.
 */

void laMatrixMult4(laMatrix4 m3, laMatrix4 m2, laMatrix4 m1)
{
    laMatrixMult((double *)m3, (double *)m2, (double *)m1, 4, 4, 4);
}


/*
 * laDotProduct
 *
 * Returns v1 . v2.
 */

double laDotProduct (double *v1, double  *v2)
{
    return (v1[0]*v2[0] + v1[1]*v2[1] + v1[2]*v2[2]);
}


/*
 * laCrossProduct
 *
 * Compute the cross product p = v * w.
 */

void laCrossProduct(laVector3 p, laVector3 v, laVector3 w)
{
    p[0] = v[1]*w[2] - v[2]*w[1];
    p[1] = v[2]*w[0] - v[0]*w[2];
    p[2] = v[0]*w[1] - v[1]*w[0];
}


/*
 * laLoadTranslation
 *
 * Load a translation matrix.
 */

void laLoadTranslation(laMatrix4 m, double tx, double ty, double tz)
{
    laIdentity4(m);
    m[0][3] = tx;
    m[1][3] = ty;
    m[2][3] = tz;
}

/*
 * VPLoadRotation
 *
 * Load a rotation matrix.
 */

void laLoadRotation(laMatrix4 m, int axis, double degrees)
{
    double radians, sintheta, costheta;

    radians = degrees * M_PI / 180.;
    sintheta = sin(radians);
    costheta = cos(radians);
    laIdentity4(m);
    switch (axis) {
    case iX:
      m[1][1] = costheta;
      m[1][2] = sintheta;
      m[2][1] = -sintheta;
      m[2][2] = costheta;
      break;
    case iY:
      m[0][0] = costheta;
      m[0][2] = -sintheta;
      m[2][0] = sintheta;
      m[2][2] = costheta;
      break;
    case iZ:
      m[0][0] = costheta;
      m[0][1] = sintheta;
      m[1][0] = -sintheta;
      m[1][1] = costheta;
      break;
    default:
      assert(0);  /* eixo invalido */
    }
}

/*
 * VPLoadScale
 *
 * Load a scale matrix.
 */

void laLoadScale(laMatrix4 m, double sx, double sy, double sz)
{
    laIdentity4(m);
    m[0][0] = sx;
    m[1][1] = sy;
    m[2][2] = sz;
}

/*
 * laTranslate
 *
 * Multiply the current matrix by a translation matrix.
 */

int laTranslate(laMatrix4 m, double tx, double ty, double tz)
{
    laMatrix4 t, tmp;

    laLoadTranslation(t, tx, ty, tz);
    laMatrixMult4(tmp, t, m);
    laCopyMatrix4(m, tmp);
    return(1);
}

/*
 * laRotate
 *
 * Multiply the current matrix by a rotation matrix.
 */

int laRotate(laMatrix4 m, int axis, double degrees)
{
    laMatrix4 r, tmp;

    if (axis != iX && axis != iY && axis != iZ)
    return(0);
    laLoadRotation(r, axis, degrees);
    laMatrixMult4(tmp, r, m);
    laCopyMatrix4(m, tmp);
    return(1);
}

/*
 * laScale
 *
 * Multiply the current matrix by a scale matrix.
 */

int laScale(laMatrix4 m, double sx, double sy, double sz)
{
    laMatrix4 s, tmp;

    laLoadScale(s, sx, sy, sz);
    laMatrixMult4(tmp, s, m);
    laCopyMatrix4(m, tmp);
    return(1);
}




/***************************************************************************\
* DVRLUA.C                                                                  *
* Lua interfacing for program configuration.                                *
* Diego Nehab                                                               *
\***************************************************************************/

#include <stdio.h>

#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>

#include "dvr.h"
#include "dvrlua.h"

/**************************************************************\
* Checks if there are too many parameters.                     *
\**************************************************************/
static void dvrlua_check_nparam(int numArg)
{
  lua_Object o = lua_getparam(numArg);
  luaL_arg_check(o == LUA_NOOBJECT, numArg, 
    "too many parameters");
}

/**************************************************************\
* Checks if parameter is a number in [0, 255].                 *
\**************************************************************/
static unsigned char dvrlua_check_color(int numArg)
{
  double c;

  c = (double) luaL_check_number(numArg);
  
  luaL_arg_check(!((c < 0) || (c > 255)), numArg,
    "color component expected");

  return (unsigned char) c;
}

/***************************************************************************\
* Set model information.                                                    *
\***************************************************************************/
static void dvrlua_setvolumeinfo(void)
{
  int header, width, height, depth;
  float dx, dy, dz;

  header = (int) luaL_check_number(1);
  width = (int) luaL_check_number(2);
  height = (int) luaL_check_number(3);
  depth = (int) luaL_check_number(4);
  dx = (float) luaL_check_number(5);
  dy = (float) luaL_check_number(6);
  dz = (float) luaL_check_number(7);
  dvrlua_check_nparam(8);

  dvr_setvolumeinfo(header, width, height, depth, dx, dy, dz);
}

/***************************************************************************\
* Get model information.                                                    *
\***************************************************************************/
static void dvrlua_getvolumeinfo(void)
{
  long header, width, height, depth;
  double voxel_width, voxel_height, voxel_depth;

  dvr_getvolumeinfo(&header, &width, &height, &depth, &voxel_width, 
    &voxel_height, &voxel_depth);

  lua_pushnumber((float) header);
  lua_pushnumber((float) width);
  lua_pushnumber((float) height);
  lua_pushnumber((float) depth);
  lua_pushnumber((float) voxel_width);
  lua_pushnumber((float) voxel_height);
  lua_pushnumber((float) voxel_depth);
}  

/***************************************************************************\
* Reset camera and view volume to defaults.                                 *
\***************************************************************************/
static void dvrlua_resetviewparameters(void)
{
  dvr_resetviewparameters();
}

/***************************************************************************\
* Rotates current camera leaving the reference point unchanged.             *
\***************************************************************************/
static void dvrlua_rotatecamera(void)
{
  double dx, dy, dz;

  dx = luaL_check_number(1);
  dy = luaL_check_number(2);
  dz = luaL_check_number(3);
  dvrlua_check_nparam(4);

  dvr_rotatecamera(dx, dy, dz);
}

/***************************************************************************\
* Set camera.                                                               *
\***************************************************************************/
static void dvrlua_setcamera(void)
{
  double eyex, eyey, eyez, refx, refy, refz, vupx, vupy, vupz;

  eyex = luaL_check_number(1);
  eyey = luaL_check_number(2);
  eyez = luaL_check_number(3);
  refx = luaL_check_number(4);
  refy = luaL_check_number(5);
  refz = luaL_check_number(6);
  vupx = luaL_check_number(7);
  vupy = luaL_check_number(8);
  vupz = luaL_check_number(9);
  dvrlua_check_nparam(10);

  dvr_setcamera(eyex, eyey, eyez, refx, refy, refz, vupx, vupy, vupz);
}

/***************************************************************************\
* Get camera.                                                               *
\***************************************************************************/
static void dvrlua_getcamera(void)
{
  double eyex, eyey, eyez, refx, refy, refz, vupx, vupy, vupz;

  dvr_getcamera(&eyex, &eyey, &eyez, &refx, &refy, &refz, &vupx, &vupy, &vupz);
  
  lua_pushnumber((float) eyex);
  lua_pushnumber((float) eyey);
  lua_pushnumber((float) eyez);
  lua_pushnumber((float) refx);
  lua_pushnumber((float) refy);
  lua_pushnumber((float) refz);
  lua_pushnumber((float) vupx);
  lua_pushnumber((float) vupy);
  lua_pushnumber((float) vupz);
}

/***************************************************************************\
* Define a light source.                                                    *
\***************************************************************************/
void dvrlua_setlight(void)
{
  int light, camera;
  double x, y, z;
  unsigned char r, g, b;

  light = (int) luaL_check_number(1);
  x = luaL_check_number(2);
  y = luaL_check_number(3);
  z = luaL_check_number(4);
  
  r = dvrlua_check_color(5);
  g = dvrlua_check_color(6);
  b = dvrlua_check_color(7);

  camera = (int) luaL_check_number(8);

  dvrlua_check_nparam(9);

  dvr_setlight(light, x, y, z, r, g, b, camera);
}

/***************************************************************************\
* Set background color.                                                     *
\***************************************************************************/
void dvrlua_setbackground(void)
{
  unsigned char r, g, b;

  r = dvrlua_check_color(1);
  g = dvrlua_check_color(2);
  b = dvrlua_check_color(3);

  dvrlua_check_nparam(4);

  dvr_setbackground(r, g, b);
}

/***************************************************************************\
* Set view volume.                                                          *
\***************************************************************************/
static void dvrlua_setviewvolume(void)
{
  double left, right, bottom, top, front, back;

  left = luaL_check_number(1);
  right = luaL_check_number(2);
  bottom = luaL_check_number(3);
  top = luaL_check_number(4);
  front = luaL_check_number(5);
  back = luaL_check_number(6);
  dvrlua_check_nparam(7);

  dvr_setviewvolume(left, right, bottom, top, front, back);
}

/***************************************************************************\
* Get view volume.                                                          *
\***************************************************************************/
static void dvrlua_getviewvolume(void)
{
  double left, right, bottom, top, front, back;

  dvr_getviewvolume(&left, &right, &bottom, &top, &front, &back);

  lua_pushnumber((float) left);
  lua_pushnumber((float) right);
  lua_pushnumber((float) bottom);
  lua_pushnumber((float) top);
  lua_pushnumber((float) front);
  lua_pushnumber((float) back);
}

/***************************************************************************\
* Get volume bounding box.                                                  *
\***************************************************************************/
static void dvrlua_getboundingbox(void)
{
  double xmin, xmax, ymin, ymax, zmin, zmax;

  dvr_getboundingbox(&xmin, &xmax, &ymin, &ymax, &zmin, &zmax);

  lua_pushnumber((float) xmin);
  lua_pushnumber((float) xmax);
  lua_pushnumber((float) ymin);
  lua_pushnumber((float) ymax);
  lua_pushnumber((float) zmin);
  lua_pushnumber((float) zmax);
}

/***************************************************************************\
* Load model file into memory.                                              *
\***************************************************************************/
static void dvrlua_loadvolume(void)
{
  char *filename;
  int err;
  
  filename = luaL_check_string(1);
  dvrlua_check_nparam(2);

  err = dvr_loadvolume(filename);
  if (err != DVR_OK) 
    lua_error("loadvolume: unable to load model!");
}

/***************************************************************************\
* Initializes Lua interfacing.                                              *
\***************************************************************************/
void dvrlua_open(void)
{
  /* initialize lua */
  lua_open();
  
  iolib_open();
  strlib_open();
  mathlib_open();

  /* register dvrlua functions */
  lua_register("dvrlua_setvolumeinfo", dvrlua_setvolumeinfo);
  lua_register("dvrlua_getvolumeinfo", dvrlua_getvolumeinfo);
  lua_register("dvrlua_resetviewparameters", dvrlua_resetviewparameters);
  lua_register("dvrlua_setcamera", dvrlua_setcamera);
  lua_register("dvrlua_setlight", dvrlua_setlight);
  lua_register("dvrlua_setbackground", dvrlua_setbackground);
  lua_register("dvrlua_rotatecamera", dvrlua_rotatecamera);
  lua_register("dvrlua_getcamera", dvrlua_getcamera);
  lua_register("dvrlua_setviewvolume", dvrlua_setviewvolume);
  lua_register("dvrlua_getviewvolume", dvrlua_getviewvolume);
  lua_register("dvrlua_getboundingbox", dvrlua_getboundingbox);
  lua_register("dvrlua_loadvolume", dvrlua_loadvolume);
}

/***************************************************************************\
* Runs a model description file.                                            *
\***************************************************************************/
int dvrlua_run(char *filename)
{
  return lua_dofile(filename);
}

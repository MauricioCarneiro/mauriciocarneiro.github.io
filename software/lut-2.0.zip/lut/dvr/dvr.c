/***************************************************************************\
* DVR.C                                                                     *
* Ray casting implementation.                                               *
* Diego Nehab                                                               *
\***************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <math.h>

#include "linalg.h"

#include "dvr.h"
#include "dvrpriv.h"

/***************************************************************************\
* Some useful macros.                                                       *
\***************************************************************************/
#define sq(_) ((_)*(_))
#define offset(z, y, x) ((z)*volume.width*volume.height + (y)*volume.width + (x))
#define sgn(_) ((_) < 0 ? -1 : 1)
#define ignore(_) (void *)(_)

#define NUM_LIGHTS 5
#define MAX_OPACITY 0.99
#define MIN_FLOAT 0.00001

/***************************************************************************\
* Global variables.                                                         *
\***************************************************************************/
/* volume information */
static struct {
  /* volume filename */
  char *filename;
  /* bytes to skip in the beginning of volume file */
  long header;
  /* volume dimensions in voxels */
  long width, height, depth;
  /* voxel dimensions in world coordinates */
  double voxel_width, voxel_height, voxel_depth;
  /* volume data matrix */
  unsigned char *data;
  /* number of voxels in volume */
  long size;
  /* boundbox */
  double xmin, xmax, ymin, ymax, zmin, zmax;
  /* minimum and maximum values within volume */
  unsigned char min, max;
  /* lighted voxels */
  unsigned char *red, *green, *blue;
  /* minimum density to be considered */
  unsigned char min_value;
} volume;

/* final image information */
static struct {
  /* channel buffers */
  unsigned char *red, *green, *blue;
  /* final image dimensions */
  long width, height;
  /* background color */
  unsigned char bgr, bgg, bgb;
} image;

/* view information */
static struct {
  /* view volume, big enough to view the volume by any angle */
  double left, right, bottom, top, front, back;
  /* camera */
  double eyex, eyey, eyez, refx, refy, refz, vupx, vupy, vupz;
  /* eye2world transformation */
  laMatrix4 eye2world;
} view;  

/* light definitons */
static struct {
  /* light direction, paralel projection */
  double x, y, z;
  /* light color in range [0, 1] */
  double r, g, b;
  /* is the light defined */
  int defined;
  /* camera = 0, world coordinates, camera = 1, eye coordinates */
  int camera;
} light[NUM_LIGHTS];

static struct {
  /* color functions */
  unsigned char r, g, b;
} LUT[256];

/* opacity functions */
static double opacity[256];

/***************************************************************************\
* Reset camera and view volume to defaults.                                 *
\***************************************************************************/
void dvr_resetviewparameters(void)
{
  double diagonal;

  /* default view volume */
  diagonal = sqrt(sq(volume.width*volume.voxel_width) + sq(volume.height*volume.voxel_height) + 
    sq(volume.depth*volume.voxel_depth));
  view.left = -diagonal/2; view.right = diagonal/2; view.bottom = -diagonal/2; view.top = diagonal/2;
  view.front = diagonal/2; view.back = 3*diagonal/2;

  /* default camera */
  view.eyex = view.eyey = 0.0; view.eyez = diagonal;
  view.vupx = view.vupz = 0.0; view.vupy = 1.0;
  view.refx = view.refy = view.refz = 0.0;

  /* generate eye2world transformation */
  updateeye2world();
}

/***************************************************************************\
* Set image information.                                                    *
\***************************************************************************/
void dvr_setimageinfo(long width, long height, unsigned char *red, 
                     unsigned char *green, unsigned char *blue)
{
  assert(red && green && blue && width > 0 && height > 0);
  
  image.width = width;
  image.height = height;
  image.red = red;
  image.blue = blue;
  image.green = green;
}
                   
/***************************************************************************\
* Set background color.                                                     *
\***************************************************************************/
void dvr_setbackground(unsigned char r, unsigned char g, unsigned char b)
{
  image.bgr = r;
  image.bgg = g;
  image.bgb = b;
}
                     
/***************************************************************************\
* Set volume information.                                                   *
\***************************************************************************/
void dvr_setvolumeinfo(long header, long width, long height, long depth, 
                   double voxel_width, double voxel_height, double voxel_depth)
{
  assert(header >= 0 && width > 0 && height > 0 && depth > 0 
    && voxel_width > 0 && voxel_height > 0 && voxel_depth > 0);
  
  volume.header = header;
  volume.width = width;
  volume.depth = depth;
  volume.height = height;
  volume.voxel_width = voxel_width;
  volume.voxel_height = voxel_height;
  volume.voxel_depth = voxel_depth;
  volume.size = width*height*depth;

  /* volume bounding box */
  volume.xmax = (width-1)*voxel_width/2;   volume.xmin = -volume.xmax;
  volume.ymax = (height-1)*voxel_height/2; volume.ymin = -volume.ymax;
  volume.zmax = (depth-1)*voxel_depth/2;   volume.zmin = -volume.zmax;
  
  dvr_resetviewparameters();
}

/***************************************************************************\
* Get volume information.                                                    *
\***************************************************************************/
void dvr_getvolumeinfo(long *header, long *width, long *height, 
                      long *depth, double *voxel_width, double *voxel_height, 
                      double *voxel_depth)
{
  if (header) *header = volume.header;
  if (width) *width = volume.width;
  if (depth) *depth = volume.depth;
  if (height) *height = volume.height;
  if (voxel_width) *voxel_width = volume.voxel_width;
  if (voxel_height) *voxel_height = volume.voxel_height;
  if (voxel_depth) *voxel_depth = volume.voxel_depth;
}

/***************************************************************************\
* Get volume information.                                                    *
\***************************************************************************/
void dvr_getdensitycount(long int *count, int min, int max)
{
  long int v;

  assert(volume.data != NULL && volume.size > 0); 

  if (count) {
    memset(count, 0, 256*sizeof(long int));
    v = 0;
    while (v < volume.size) {
      if ((volume.data[v] >= min) && (volume.data[v] <= max)) 
        count[volume.data[v]]++;
      v++;
    }   
  }
}

/***************************************************************************\
* Generate view volume in world coordinates.                                *
\***************************************************************************/
static void updateeye2world(void)
{
  laVector3 u, v, w;
  laMatrix4 trans, rot;

  /* {u, v, w} form the camera orthonormal basis */
  w[iX] = view.eyex - view.refx;
  w[iY] = view.eyey - view.refy;
  w[iZ] = view.eyez - view.refz;
  laNormalize3(w);
  v[iX] = view.vupx;
  v[iY] = view.vupy;
  v[iZ] = view.vupz;
  laNormalize3(v);
  laCrossProduct(u, v, w);
  laCrossProduct(v, w, u);
  
  /* create translation matrix */
  laIdentity4(trans);
  laLoadTranslation(trans, view.eyex, view.eyey, view.eyez);

  /* create rotation matrix */
  laIdentity4(rot);
  rot[0][0] = u[iX];
  rot[1][0] = u[iY];
  rot[2][0] = u[iZ];
  rot[0][1] = v[iX];
  rot[1][1] = v[iY];
  rot[2][1] = v[iZ];
  rot[0][2] = w[iX];
  rot[1][2] = w[iY];
  rot[2][2] = w[iZ];

  /* compose transformations */
  laMatrixMult4(view.eye2world, trans, rot);
}

/***************************************************************************\
* Set camera.                                                               *
\***************************************************************************/
void dvr_setcamera(double eyex, double eyey, double eyez,
                  double refx, double refy, double refz,
                  double vupx, double vupy, double vupz)
{
  view.eyex = eyex;
  view.eyey = eyey;
  view.eyez = eyez;
  view.refx = refx;
  view.refy = refy;
  view.refz = refz;
  view.vupx = vupx;
  view.vupy = vupy;
  view.vupz = vupz;

  updateeye2world();
}

/***************************************************************************\
* Rotates current camera leaving the reference point unchanged.             *
\***************************************************************************/
void dvr_rotatecamera(double dx, double dy, double dz)
{
  laMatrix4 rot;
  laVector4 eye, up, tmp;

  eye[iX] = view.eyex;
  eye[iY] = view.eyey;
  eye[iZ] = view.eyez;
  eye[iW] = 1.0;

  up[iX] = view.vupx;
  up[iY] = view.vupy;
  up[iZ] = view.vupz;
  up[iW] = 1.0;
  
  if (fabs(dx) > FLT_ZERO) {
    laLoadRotation(rot, iX, dx);
    laMatrixVectorMult4(tmp, rot, eye);
    laCopyVector4(eye, tmp);
    laMatrixVectorMult4(tmp, rot, up);
    laCopyVector4(up, tmp);
  }

  if (fabs(dy) > FLT_ZERO) {
    laLoadRotation(rot, iY, dy);
    laMatrixVectorMult4(tmp, rot, eye);
    laCopyVector4(eye, tmp);
    laMatrixVectorMult4(tmp, rot, up);
    laCopyVector4(up, tmp);
  }

  if (fabs(dz) > FLT_ZERO) {
    laLoadRotation(rot, iZ, dz);
    laMatrixVectorMult4(tmp, rot, eye);
    laCopyVector4(eye, tmp);
    laMatrixVectorMult4(tmp, rot, up);
    laCopyVector4(up, tmp);
  }

  view.eyex = eye[iX];
  view.eyey = eye[iY];
  view.eyez = eye[iZ];

  view.vupx = up[iX];
  view.vupy = up[iY];
  view.vupz = up[iZ];

  updateeye2world();
}

/***************************************************************************\
* Get camera.                                                               *
\***************************************************************************/
void dvr_getcamera(double *eyex, double *eyey, double *eyez,
                  double *refx, double *refy, double *refz,
                  double *vupx, double *vupy, double *vupz)
{
  if (eyex) *eyex = view.eyex;
  if (eyex) *eyey = view.eyey;
  if (eyex) *eyez = view.eyez;
  if (refx) *refx = view.refx;
  if (refy) *refy = view.refy;
  if (refz) *refz = view.refz;
  if (vupx) *vupx = view.vupx;
  if (vupy) *vupy = view.vupy;
  if (vupz) *vupz = view.vupz;
}

/***************************************************************************\
* Set viewvolume.                                                           *
\***************************************************************************/
void dvr_setviewvolume(double left, double right, double bottom, double top,
                      double front, double back)
{
  view.left = left;
  view.right = right;
  view.bottom = bottom;
  view.top = top;
  view.front = front;
  view.back = back;
}

/***************************************************************************\
* Define a light source.                                                    *
\***************************************************************************/
void dvr_setlight(int light_number, double x, double y, double z, unsigned char r, 
                 unsigned char g, unsigned char b, int camera)
{
  double l;
  
  assert(light_number >= 0 && light_number < NUM_LIGHTS);

  l = sqrt(sq(x) + sq(y) + sq(z));
  assert(l > MIN_FLOAT);

  light[light_number].x = -x/l;
  light[light_number].y = -y/l;
  light[light_number].z = -z/l;
  light[light_number].r = r/255.0;
  light[light_number].g = g/255.0;
  light[light_number].b = b/255.0;
  light[light_number].defined = 1;
  light[light_number].camera = camera;
}
                      
/***************************************************************************\
* Get viewvolume.                                                           *
\***************************************************************************/
void dvr_getviewvolume(double *left, double *right, double *bottom, double *top,
                      double *front, double *back)
{
  if (left) *left = view.left;
  if (right) *right = view.right;
  if (bottom) *bottom = view.bottom;
  if (top) *top = view.top;
  if (front) *front = view.front;
  if (back) *back = view.back;
}

/***************************************************************************\
* Get volume bounding box.                                                  *
\***************************************************************************/
void dvr_getboundingbox(double *xmin, double *xmax, double *ymin, double *ymax,
                      double *zmin, double *zmax)
{
  if (xmin) *xmin = volume.xmin;
  if (xmax) *xmax = volume.xmax;
  if (ymin) *ymin = volume.ymin;
  if (ymax) *ymax = volume.ymax;
  if (zmin) *zmin = volume.zmin;
  if (zmax) *zmax = volume.zmax;
}

/***************************************************************************\
* Set opacity LUT function.                                                 *
\***************************************************************************/
void dvr_setopacity(double *op)
{
  memcpy(opacity, op, 256*sizeof(double));
}

/***************************************************************************\
* Returns a pointer to the internal opacity vector.                         *
\***************************************************************************/
double *dvr_getopacity(void)
{
  return opacity;
}

/***************************************************************************\
* Set color LUT function.                                                   *
\***************************************************************************/
void dvr_setcolor(unsigned char *red, unsigned char *green, unsigned char *blue)  
{
  int i;

  for (i = 0; i < 256; i++) {
    LUT[i].r = red[i];
    LUT[i].g = green[i];
    LUT[i].b = blue[i];
  }
}

/***************************************************************************\
* Load volume file into memory.                                              *
\***************************************************************************/
static void findbrightness(void)
{
  int min, max;
  long os;

  min = +32767;
  max = -32767;

  os = 0;
  while (os < volume.size) {
    if (volume.data[os] > max)
      max = volume.data[os];
    if (volume.data[os] < min)
      min = volume.data[os];
    os++;
  }

  volume.min = min;
  volume.max = max;
}

/***************************************************************************\
* Load volume file into memory.                                             *
\***************************************************************************/
int dvr_loadvolume(char *filename)
{
  FILE *input;

  assert(filename);
  volume.filename = mystrdup(filename);

  if (volume.data) free(volume.data);
  if (volume.red) free(volume.red);
  if (volume.green) free(volume.green);
  if (volume.blue) free(volume.blue);
  volume.data = (unsigned char *) malloc(volume.size);
  volume.red = (unsigned char *) malloc(volume.size);
  volume.green = (unsigned char *) malloc(volume.size);
  volume.blue = (unsigned char *) malloc(volume.size);
  assert(volume.data && volume.red && volume.green && volume.blue);
  if (!volume.data || !volume.red || !volume.green || !volume.blue) {
    if (volume.data) free(volume.data);
    if (volume.red) free(volume.red);
    if (volume.green) free(volume.green);
    if (volume.blue) free(volume.blue);
    return DVR_ERROR;
  }
  
  input = fopen(volume.filename, "rb");
  assert(input);
  if (input == NULL) {
    free(volume.data);
    volume.data = NULL;
    return DVR_ERROR;
  }

  if (fseek(input, volume.header, SEEK_SET)) {
    fclose(input);
    free(volume.data);
    volume.data = NULL;
    return DVR_ERROR;
  }

  if (fread(volume.data, volume.size, 1, input) != 1) {
    fclose(input);
    free(volume.data);
    volume.data = NULL;
    return DVR_ERROR;
  }

  fclose(input);

  findbrightness();
  
  return DVR_OK;
}

/***************************************************************************\
* Slices the volume.                                                        *
\***************************************************************************/
int dvr_xyslice(long z, char *slice)
{
  long xy;
  
  assert(slice);
  if (!slice)
    return DVR_ERROR;

  assert(z < volume.depth && z >= 0);
  if (z >= volume.depth || z < 0)
    return DVR_ERROR;

  xy = volume.width*volume.height;
  memcpy(slice, volume.data + xy*z, xy);

  return DVR_OK;
}

/***************************************************************************\
* Slices the volume.                                                         *
\***************************************************************************/
int dvr_yzslice(long x, char *slice)
{
  long yz, p, v;
  
  assert(slice);
  if (!slice)
    return DVR_ERROR;

  assert(x < volume.width && x >= 0);
  if (x >= volume.width || x < 0)
    return DVR_ERROR;

  yz = volume.height*volume.depth;
  p = 0;
  v = x;
  while (p < yz) {
    slice[p] = volume.data[v];
    p++;
    v += volume.width;
  }

  return DVR_OK;
}

/***************************************************************************\
* Slices the volume.                                                         *
\***************************************************************************/
int dvr_zxslice(long y, char *slice)
{
  long xy, v, i, k, p, base;
  
  assert(slice);
  if (!slice)
    return DVR_ERROR;

  assert(y < volume.height && y >= 0);
  if (y >= volume.height || y < 0)
    return DVR_ERROR;

  xy = volume.width*volume.height;
  p = 0;
  base = y*volume.width;
  for (i = 0; i < volume.width; i++) {
    v = base + i;
    for (k = 0; k < volume.depth; k++) {
      slice[p] = volume.data[v];
      p++;
      v += xy;
    }
  }
  return DVR_OK;
}

/***************************************************************************\
* Get voxel color and opacity from transference function table.             *
\***************************************************************************/
static void getLUT(unsigned char d, unsigned char *r, unsigned char *g, 
                  unsigned char *b, double *o)
{
  if (r) *r = LUT[d].r;
  if (g) *g = LUT[d].g;
  if (b) *b = LUT[d].b;
  if (o) *o = opacity[d];
}

/***************************************************************************\
* Calculate voxel normal by gradient aproximation.                          *
\***************************************************************************/
static void gradient(long x, long y, long z, double *ugx, double *ugy, double *ugz) 
{
  double l, gx, gy, gz;
  long os1, os2;

  if (x == 0) {
    os1 = offset(z,y,x);
    os2 = offset(z,y,x+1);
  }
  else if (x == volume.width-1) {
    os1 = offset(z,y,x-1);
    os2 = offset(z,y,x);
  }
  else {
    os1 = offset(z,y,x-1);
    os2 = offset(z,y,x+1);
  }
  
  gx = (double) (volume.data[os1] - volume.data[os2]);

  if (y == 0) {
    os1 = offset(z,y,x);
    os2 = offset(z,y+1,x);
  }
  else if (y == volume.height-1) {
    os1 = offset(z,y-1,x);
    os2 = offset(z,y,x);
  }
  else {
    os1 = offset(z,y-1,x);
    os2 = offset(z,y+1,x);
  }

  gy = (double) (volume.data[os1] - volume.data[os2]);

  if (z == 0) {
    os1 = offset(z,y,x);
    os2 = offset(z+1,y,x);
  }
  else if (z == volume.depth-1) {
    os1 = offset(z-1,y,x);
    os2 = offset(z,y,x);
  }
  else {
    os1 = offset(z-1,y,x);
    os2 = offset(z+1,y,x);
  }

  gz = (double) (volume.data[os1] - volume.data[os2]);

  gx *= volume.voxel_width;
  gy *= volume.voxel_height;
  gz *= volume.voxel_depth;
  
  l = sqrt((gx*gx)+(gy*gy)+(gz*gz));

  if (l > MIN_FLOAT) {
    gx /= l;
    gy /= l;
    gz /= l;
  }

  *ugx = gx; *ugy = gy; *ugz = gz;
}

/***************************************************************************\
* Generate red, green and blue volume components based on LUT and lights.   *
\***************************************************************************/
static void lightvoxels(void)
{
  double gx, gy, gz;
  int i, j, k, l;
  double rd, gd, bd, scalar;
  unsigned char r, g, b, d;
  long os;

  for (i=0; i<volume.width; i++) {
    for (j=0; j<volume.height; j++) {
      for (k=0; k<volume.depth; k++) {
        gradient(i, j, k, &gx, &gy, &gz);
        os = offset(k, j, i);
        d = volume.data[os];
        getLUT(d, &r, &g, &b, NULL);
        rd = 0; gd = 0; bd = 0;
        for (l=0; l<NUM_LIGHTS; l++) {
          if (light[l].defined) {
            scalar = light[l].x*gx + light[l].y*gy + light[l].z*gz;
            if (scalar > MIN_FLOAT) {
              rd += r*scalar*light[l].r;
              gd += g*scalar*light[l].g;
              bd += b*scalar*light[l].b;
            }
          }
        }
        rd += r; gd += g; bd += b;
        r = (rd <= 255.0) ? (unsigned char) rd : 255;
        g = (gd <= 255.0) ? (unsigned char) gd : 255;
        b = (bd <= 255.0) ? (unsigned char) bd : 255;
        volume.red[os] = r;
        volume.green[os] = g;
        volume.blue[os] = b;
      }
    }
  }
}

/***************************************************************************\
* This is where the real rendring takes place. The function raycasts into   *
* the volume, from (x0, y0, z0) to (x1, y1, z1) in volume coordinates using *
* the tripod algorithm to generate the visited points. The color calculated *
* is returned in r, g and b.                                                *
\***************************************************************************/
static void raycast(long x0, long y0, long z0, long x1, long y1, long z1, 
                    unsigned char *ur, unsigned char *ug, unsigned char *ub)
{
  /* current voxel being visited */
  int  x,  y,  z;
  /* tripod parameters */
  int  n, sx, sy, sz, dx, dy, dz;
  int  exy, exz, ezy;
  int  ax, ay, az, bx, by, bz;
  long os;

  /* acumulated pixel color */
  double pr = 0.0, pg = 0.0, pb = 0.0;
  /* accumulated pixel opacity */
  double po = 0.0;

  /* current voxel density, directly from volume */
  unsigned char vd; 
  /* current voxel color, function of density */
  unsigned char vr, vg, vb;
  /* current voxel opacity, function of density */
  double vo;

  /* initialize for first voxel */
  dx = x1 - x0; dy = y1 - y0; dz = z1 - z0;
  x = x0; y = y0; z = z0;
  sx = sgn(dx); sy = sgn(dy); sz = sgn(dz);
  ax = abs(dx); ay = abs(dy); az = abs(dz);
  bx = 2*ax;  by = 2*ay;  bz = 2*az;
  exy = ay - ax; exz = az - ax; ezy = ay - az;
  n = ax + ay + az;

  /* for all visited voxels... */
  while (n--) {
    /* visits voxel (x, y, z) */
    /* if voxel is within bounds */
    if ((x >= 0) && (y >= 0) && (z >= 0) && (x < volume.width) && (y < volume.height) && (z < volume.depth)) {

      os = offset(z, y, x);

      /* gets current voxel density, used to define voxel color and opacity */
      vd = volume.data[os];

      /* get lighted voxel color components */
      vr = volume.red[os];
      vg = volume.green[os];
      vb = volume.blue[os];

      /* get voxel opacity */
      getLUT(vd, NULL, NULL, NULL, &vo);
      
      if (vo > MIN_FLOAT) {
        /* add voxel contribution to pixel color */
        pr += (1 - po) * vo * vr;
        pg += (1 - po) * vo * vg;
        pb += (1 - po) * vo * vb;

        /* acumulate pixel opacity and break if saturated */
        po += (1 - po) * vo;
  
        /* ray is saturated */
        if (po >= MAX_OPACITY) {
          break;
        }
      }
    }
  
    /* go to next voxel by the tripod algorithm */
    if (exy < 0) {
      if (exz < 0) {
        x += sx; exy += by; exz += bz;
      }
      else {
        z += sz; exz -= bx; ezy += by;
      }
    }
    else {
      if (ezy < 0) {
        z += sz; exz -= bx; ezy += by;
      }                                                 
      else {                                                 
        y += sy; exy -= bx; ezy += bz;
      }                                                 
    }                                                   
  }
  
  if (pr > 255 ) pr = 255;
  if (pg > 255 ) pg = 255;
  if (pb > 255 ) pb = 255;
  if (po > 1.0 ) po = 1.0;

  /* finaly blend pixel color with background color */
  *ur = (unsigned char) (pr*po + (1-po)*image.bgr); 
  *ug = (unsigned char) (pg*po + (1-po)*image.bgg); 
  *ub = (unsigned char) (pb*po + (1-po)*image.bgb); 
}

/***************************************************************************\
* Change light coordinates from eye to world.                               *
\***************************************************************************/
static void updatecameralights(void)
{
  laVector3 u, v, w;
  laMatrix4 rot;
  int i;

  /* {u, v, w} form the camera orthonormal basis */
  w[iX] = view.eyex - view.refx;
  w[iY] = view.eyey - view.refy;
  w[iZ] = view.eyez - view.refz;
  laNormalize3(w);
  v[iX] = view.vupx;
  v[iY] = view.vupy;
  v[iZ] = view.vupz;
  laNormalize3(v);
  laCrossProduct(u, v, w);
  laCrossProduct(v, w, u);
  
  /* create rotation matrix */
  laIdentity4(rot);
  rot[0][0] = u[iX];
  rot[1][0] = u[iY];
  rot[2][0] = u[iZ];
  rot[0][1] = v[iX];
  rot[1][1] = v[iY];
  rot[2][1] = v[iZ];
  rot[0][2] = w[iX];
  rot[1][2] = w[iY];
  rot[2][2] = w[iZ];

  for (i=0; i<NUM_LIGHTS; i++) {
    if (light[i].defined) {
      if (light[i].camera) {
        laVector4 tmp, lgt;

        lgt[iX] = light[i].x;
        lgt[iY] = light[i].y;
        lgt[iZ] = light[i].z;
        lgt[iW] = 1.0;
        
        laMatrixVectorMult4(tmp, rot, lgt);
     
        light[i].x = tmp[iX];
        light[i].y = tmp[iY];
        light[i].z = tmp[iZ];
      }
    }
  }
}

/***************************************************************************\
* Calculates vectors used to interpolate in the projection plane.           *
\***************************************************************************/
static void interpolants(laVector4 dx, laVector4 dy, laVector4 p0, laVector4 p1)
{
  laVector4 lbf, lbb, ltf, rbf, tmp;

  lbf[iX] = view.left;
  lbf[iY] = view.bottom;
  lbf[iZ] = -view.front;
  lbf[iW] = 1.0;
  laMatrixVectorMult4(tmp, view.eye2world, lbf);
  laCopyVector4(lbf, tmp);

  lbb[iX] = view.left;
  lbb[iY] = view.bottom;
  lbb[iZ] = -view.back;
  lbb[iW] = 1.0;
  laMatrixVectorMult4(tmp, view.eye2world, lbb);
  laCopyVector4(lbb, tmp);

  ltf[iX] = view.left;
  ltf[iY] = view.top;
  ltf[iZ] = -view.front;
  ltf[iW] = 1.0;
  laMatrixVectorMult4(tmp, view.eye2world, ltf);
  laCopyVector4(ltf, tmp);

  rbf[iX] = view.right;
  rbf[iY] = view.bottom;
  rbf[iZ] = -view.front;
  rbf[iW] = 1.0;
  laMatrixVectorMult4(tmp, view.eye2world, rbf);
  laCopyVector4(rbf, tmp);

  laSubVector4(tmp, rbf, lbf);
  dx[iX] = tmp[iX] / image.width;
  dx[iY] = tmp[iY] / image.width;
  dx[iZ] = tmp[iZ] / image.width;

  laSubVector4(tmp, ltf, lbf);
  dy[iX] = tmp[iX] / image.height;
  dy[iY] = tmp[iY] / image.height;
  dy[iZ] = tmp[iZ] / image.height;

  laCopyVector4(p0, lbf);
  laCopyVector4(p1, lbb);
}

/***************************************************************************\
* Renders the image by raycasting through the volume.                       *
\***************************************************************************/
void dvr_render(int relight)
{
  laVector4 dx, dy, p0, p1, tp0, tp1;
  long i, j;
  long os;

  assert(image.red && image.green && image.blue && image.width > 0 && image.height > 0);
  interpolants(dx, dy, p0, p1);

  updatecameralights();

  if (relight)
    lightvoxels();

  os = 0;
  for (i=0; i<image.height; i++) {
    laCopyVector4(tp0, p0);
    laCopyVector4(tp1, p1);
    for (j=0; j<image.width; j++) {
      long x0, y0, z0, x1, y1, z1;
      unsigned char r, g, b;
      /* if the ray intercepts the volume */
      if (cyrusbeck(p0, p1, &x0, &y0, &z0, &x1, &y1, &z1)) {
        /* calculate pixel color by raycasting */
        raycast(x0, y0, z0, x1, y1, z1, &r, &g, &b);
      }
      else {
        /* paint pixel with background color */
        r = image.bgr;
        g = image.bgg;
        b = image.bgb;
      }
      image.red[os] = r;
      image.green[os] = g;
      image.blue[os] = b;

      laAddVector4(p0, p0, dx);
      laAddVector4(p1, p1, dx);
      os++;
    }
    laCopyVector4(p0, tp0);
    laCopyVector4(p1, tp1);
    laAddVector4(p0, p0, dy);
    laAddVector4(p1, p1, dy);
  }
}

/***************************************************************************\
* Global initialization.                                                    *
\***************************************************************************/
void dvr_open(void)
{
  int i;
  
  volume.data = NULL;
  volume.filename = NULL;
  volume.header = -1;
  volume.width = -1;
  volume.height = -1;
  volume.depth = -1;
  volume.size = -1;
  volume.voxel_width = 0.0f;
  volume.voxel_height = 0.0f;
  volume.voxel_depth = 0.0f;

  image.width = 0;
  image.height = 0;
  image.red = NULL;
  image.green = NULL;
  image.blue = NULL;

  image.bgr = 0;
  image.bgg = 0;
  image.bgb = 0;

  for (i=0; i<NUM_LIGHTS; i++)
    light[i].defined = 0;

  for (i=0; i<256; i++) {
    LUT[i].r = i;
    LUT[i].g = i;
    LUT[i].b = i;
    opacity[i] = i/255.0;
  }
}

/***************************************************************************\
* Cyrus-Beck clipping algorithm.                                            *
\***************************************************************************/

/***************************************************************************\
* Cyrus beck auxiliar function.                                             *
\***************************************************************************/
static int clipt(double d, double n, double *tE, double *tS)
{
  int in = 1;
  double t;

  /* intersecao PE */
  if (d < 0.0) {   
    t = n / d;
    if (t > *tS) 
      in = 0;
    else if (t > *tE) 
      *tE = t;
  }
  /* intersecao PS */
  else if (d > 0.0) {
    t = n / d;
    if (t < *tE) 
      in = 0;
    else if (t < *tS) 
      *tS = t;
  }
  /* linha esta fora */
  else if (n < 0.0)
    in = 0;  

  return (in);
}

/***************************************************************************\
* Clips the line segment from p0 to p1 against the bounding box defined by  *
* left, right, bottom, top, front and back. The returned endpoints are in   *
* volume coordinates.                                                       *
\***************************************************************************/
static int cyrusbeck(laVector4 p0, laVector4 p1, long *x0, long *y0, long *z0,
                     long *x1, long *y1, long *z1)
{
  double dx = p1[iX] - p0[iX], dy = p1[iY] - p0[iY], dz = p1[iZ] - p0[iZ];
  double tE = 0.0, tS = 1.0;
  int visible = 0;

  if ((dx == 0.0) && (dy == 0.0) && (dz == 0.0)) {
    /* points are ignored but we won't get a divide by zero error */
    assert(0);
  }
  else {
    /* LEFT */
    if (clipt(-dx,p0[iX]-volume.xmin,&tE,&tS)) {
      /* RIGHT */
      if (clipt(dx,volume.xmax-p0[iX],&tE,&tS)) {
        /* BOTTOM */
        if (clipt(-dy,p0[iY]-volume.ymin,&tE,&tS)) {
          /* TOP */
          if (clipt(dy,volume.ymax-p0[iY],&tE,&tS)) {
            /* NEAR  */
            if (clipt(-dz,p0[iZ]-volume.zmin,&tE,&tS)) { 
              /* FAR */
              if (clipt(dz,volume.zmax-p0[iZ],&tE,&tS)) {
                visible = 1;
                if (tS < 1)  {                              
                  *x1 = (long) ((p0[iX]+tS*dx)/volume.voxel_width  + (volume.width-1)/2.0); 
                  *y1 = (long) ((p0[iY]+tS*dy)/volume.voxel_height + (volume.height-1)/2.0); 
                  *z1 = (long) ((p0[iZ]+tS*dz)/volume.voxel_depth + (volume.depth-1)/2.0);
                }
                else {
                  *x1 = (long) (p1[iX]/volume.voxel_width  + (volume.width-1)/2.0);
                  *y1 = (long) (p1[iY]/volume.voxel_height + (volume.height-1)/2.0);
                  *z1 = (long) (p1[iZ]/volume.voxel_depth + (volume.depth-1)/2.0);
                }
                if (tE > 0) { 
                  *x0 = (long) ((p0[iX]+tE*dx)/volume.voxel_width + (volume.width-1)/2.0); 
                  *y0 = (long) ((p0[iY]+tE*dy)/volume.voxel_height + (volume.height-1)/2.0);
                  *z0 = (long) ((p0[iZ]+tE*dz)/volume.voxel_depth + (volume.depth-1)/2.0);
                }
                else {
                  *x0 = (long) (p0[iX]/volume.voxel_width + (volume.width-1)/2.0);
                  *y0 = (long) (p0[iY]/volume.voxel_height + (volume.height-1)/2.0);
                  *z0 = (long) (p0[iZ]/volume.voxel_depth + (volume.depth-1)/2.0);
                }
              }
            }
          }
        }
      }
    }
  }
  
  return (visible);
}

/***************************************************************************\
* strdup implementation.                                                    *
\***************************************************************************/
static char *mystrdup(char *s)
{
  char *temp;

  /* get some memory */
  temp = malloc((strlen(s) + 1) * sizeof(unsigned char));
  /* if we got our memory, copy string */
  if (temp) strcpy(temp, s);
  /* return the copy or NULL if out of memory */
  return temp;
}

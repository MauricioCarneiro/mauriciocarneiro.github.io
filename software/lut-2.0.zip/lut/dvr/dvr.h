/***************************************************************************\
* DVR.H                                                                     *
* Diego Nehab                                                               *
\***************************************************************************/

#ifndef __DVR_
#define __DVR_

/***************************************************************************\
* Constants.                                                                *
\***************************************************************************/
enum {
  DVR_ERROR,
  DVR_OK
};

/***************************************************************************\
* Set volume information.                                                   *
\***************************************************************************/
void dvr_setvolumeinfo(long header, long width, long height, long depth, 
                      double voxel_width, double voxel_height, double voxel_depth);

/***************************************************************************\
* Get volume information.                                                   *
\***************************************************************************/
void dvr_getvolumeinfo(long *header, long *width, long *height, long *depth, 
                      double *voxel_width, double *voxel_height, double *voxel_depth);

/***************************************************************************\
* Returns the count of voxels for each density value.                       *
\***************************************************************************/
void dvr_getdensitycount(long int *count, int min, int max);

/***************************************************************************\
* Set image information.                                                    *
\***************************************************************************/
void dvr_setimageinfo(long width, long height, unsigned char *red, 
                     unsigned char *green, unsigned char *blue);

/***************************************************************************\
* Set background color.                                                     *
\***************************************************************************/
void dvr_setbackground(unsigned char r, unsigned char g, unsigned char b);

/***************************************************************************\
* Set color transference function.                                          *
\***************************************************************************/
void dvr_setcolor(unsigned char *red, unsigned char *green, unsigned char *blue);

/***************************************************************************\
* Set opacity LUT function.                                                 *
\***************************************************************************/
void dvr_setopacity(double *op);

/***************************************************************************\
* Returns a pointer to the internal opacity vector.                         *
\***************************************************************************/
double *dvr_getopacity(void);

/***************************************************************************\
* Reset camera and view volume to defaults.                                 *
\***************************************************************************/
void dvr_resetviewparameters(void);

/***************************************************************************\
* Set camera.                                                               *
\***************************************************************************/
void dvr_setcamera(double eyex, double eyey, double eyez,
                  double refx, double refy, double refz,
                  double vupx, double vupy, double vupz);

/***************************************************************************\
* Rotates current camera leaving the reference point unchanged.             *
\***************************************************************************/
void dvr_rotatecamera(double dx, double dy, double dz);

/***************************************************************************\
* Get camera.                                                               *
\***************************************************************************/
void dvr_getcamera(double *eyex, double *eyey, double *eyez,
                  double *refx, double *refy, double *refz,
                  double *vupx, double *vupy, double *vupz);

/***************************************************************************\
* Define a light source.                                                    *
\***************************************************************************/
void dvr_setlight(int light, double x, double y, double z, unsigned char r, 
                 unsigned char g, unsigned char b, int camera);

/***************************************************************************\
* Set viewvolume.                                                           *
\***************************************************************************/
void dvr_setviewvolume(double left, double right, double bottom, double top,
                      double front, double back);
                      
/***************************************************************************\
* Get viewvolume.                                                           *
\***************************************************************************/
void dvr_getviewvolume(double *left, double *right, double *bottom, double *top,
                      double *front, double *back);
                      
/***************************************************************************\
* Get volume bounding box.                                                  *
\***************************************************************************/
void dvr_getboundingbox(double *xmin, double *xmax, double *ymin, double *ymax,
                      double *zmin, double *zmax);

/***************************************************************************\
* Load volume file into memory.                                             *
\***************************************************************************/
int dvr_loadvolume(char *filename);

/***************************************************************************\
* Renders the image by raycasting through the volume.                       *
\***************************************************************************/
void dvr_render(int relight);

/***************************************************************************\
* Global initialization.                                                    *
\***************************************************************************/
void dvr_open(void);

/***************************************************************************\
* Set opacity LUT function.                                                 *
\***************************************************************************/
void dvr_opacity(double *op);

/***************************************************************************\
* Slices the volume.                                                        *
\***************************************************************************/
int dvr_xyslice(long z, char *slice);
int dvr_yzslice(long x, char *slice);
int dvr_zxslice(long y, char *slice);

#endif 

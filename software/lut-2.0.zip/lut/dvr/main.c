/***************************************************************************\
* MAIN.C                                                                    *
* Program main module, user interface.                                      *
* Interface with IUP, CD, DVRLua, DVR, G3D, V3D and LUT.                    *
* Diego Nehab                                                               *
\***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include <iup.h>
#include <cd.h>
#include <cdiup.h>
#include <g3d.h>
#include <g3dcdcv.h>
#include "g3dcd.h"
#include <v3d.h>

#include "dvr.h"
#include "dvrlua.h"
#include "lut.h"

static Ihandle *iup_canvas;
static g3dVisSurf *g3d_vissurf;
static cdCanvas *cd_canvas;

static unsigned char *red, *green, *blue;
static int cw, ch;
static int iw, ih;

static long int count[256];

/***************************************************************************\
* IUP repaint callback.                                                     *
\***************************************************************************/
static void iup_repaint_cb(void)
{
  cdActivate(cd_canvas);
  cdPutImageRGB(iw, ih, red, green, blue, 0, 0, cw, ch);
}

/***************************************************************************\
* LUT callback.                                                             *
\***************************************************************************/
static void lut_cb(int what)
{
  double *opacity;
  unsigned char red[256], green[256], blue[256];

  switch (what) {
    case LUT_OK:
    case LUT_APPLY:
      opacity = dvr_getopacity();
      lut_fillopacity(opacity);
      lut_fillcolor(red, green, blue);
      dvr_setcolor(red, green, blue);
      dvr_render(1);
      iup_repaint_cb();
    case LUT_CANCEL:
      break;
  }
}

/***************************************************************************\
* V3d repaint callback.                                                     *
\***************************************************************************/
static void v3d_repaint_cb(Ihandle *self)
{
  double eyex, eyey, eyez, refx, refy, refz, vupx, vupy, vupz;

  V3dGetCamera(self, &eyex, &eyey, &eyez, &refx, &refy, &refz, &vupx, &vupy, &vupz);
  dvr_setcamera(eyex, eyey, eyez, refx, refy, refz, vupx, vupy, vupz);
  dvr_render(0);
  iup_repaint_cb();
}

/***************************************************************************\
* V3d draft callback.                                                       *
\***************************************************************************/
static void v3d_draft_cb(Ihandle *self, int updated)
{
  v3d_repaint_cb(self);
}

/***************************************************************************\
* (File|Exit) callback.                                                     *
\***************************************************************************/
static int exit_cb(void)
{
  return IUP_CLOSE;
}

/***************************************************************************\
* (File|Load) callback.                                                     *
\***************************************************************************/
static int load_cb(void)
{
  char filename[256] = "*.lua";
  
  if (IupGetFile(filename) == 0) {
    dvrlua_run(filename);
    dvr_render(1);
    cdPutImageRGB(iw, ih, red, green, blue, 0, 0, cw, ch);
  }
  
  return IUP_DEFAULT;
}

/***************************************************************************\
* (Opacity|Edit) callback.                                                  *
\***************************************************************************/
static int edit_op_cb(void)
{
  lut_show();  

  return IUP_DEFAULT;
}

/***************************************************************************\
* (Opacity|Save) callback.                                                  *
\***************************************************************************/
static int save_op_cb(void)
{
  char filename[256] = "*.lut";
  
  if (IupGetFile(filename) >= 0)
    lut_save(filename);

  return IUP_DEFAULT;
}

/***************************************************************************\
* (Opacity|Load) callback.                                                  *
\***************************************************************************/
static int load_op_cb(void)
{
  char filename[256] = "*.lut";
  
  if (IupGetFile(filename) == 0)
    lut_load(filename);

  return IUP_DEFAULT;
}

/***************************************************************************\
* Main canvas resize callback.                                              *
\***************************************************************************/
static int resize_cb(Ihandle *self, int w, int h)
{
  cdActivate(cd_canvas);
  cdGetCanvasSize(&cw, &ch, NULL, NULL);
  V3dResize(self, cw, ch);
  iw = cw/2;
  ih = ch/2;
  if (red) free(red);
  if (blue) free(blue);
  if (green) free(green);
  red = (unsigned char *) malloc(iw*ih);
  green = (unsigned char *) malloc(iw*ih);
  blue = (unsigned char *) malloc(iw*ih);
  assert(red && green && blue);
  dvr_setimageinfo(iw, ih, red, green, blue);
  dvr_render(0);
  return IUP_DEFAULT;
}

/***************************************************************************\
* Main canvas mouse button callback.                                        *
\***************************************************************************/
static int button_cb(Ihandle *self, int b, int e, int x, int y, char *s)
{
  if (b != IUP_BUTTON2) 
    V3dSetup(self, b, e, x, y, s);
  return IUP_DEFAULT;
}

/***************************************************************************\
* Main canvas mouse motion callback.                                        *
\***************************************************************************/
static int motion_cb(Ihandle *self, int x, int y, char *s)
{
  V3dChange(self, x, y, s);
  return IUP_DEFAULT;
}

/***************************************************************************\
* V3D bounding box callback function.                                       *
\***************************************************************************/
static int boundingbox_cb(Ihandle *iup_canvas, double *xmin, double *xmax,
                          double *ymin, double *ymax, double *zmin, double *zmax)
{
  dvr_getboundingbox(xmin, xmax, ymin, ymax, zmin, zmax);
  return 1;
}

/***************************************************************************\
* Program initialization.                                                   *
\***************************************************************************/
static void init(void) 
{
  /* initialize hybrid and lua bind */
  dvr_open();
  dvrlua_open();
  
  IupShow(IupGetHandle("the_dialog"));

  /* initialize g3d and v3d */
  iup_canvas = IupGetHandle("the_canvas");
  IupSetAttribute(iup_canvas, IUP_RASTERSIZE, NULL);
  g3d_vissurf = G3dCreateVisSurf(G3D_CD_CANVAS, iup_canvas);
  G3dActivateVisSurf(g3d_vissurf);
  V3dOpen(iup_canvas, g3d_vissurf);
  
  /* associate callbacks */
  IupSetFunction("motion_cb", (Icallback) motion_cb);
  IupSetFunction("edit_op_cb", (Icallback) edit_op_cb);
  IupSetFunction("load_op_cb", (Icallback) load_op_cb);
  IupSetFunction("save_op_cb", (Icallback) save_op_cb);
  IupSetFunction("button_cb", (Icallback) button_cb);
  IupSetFunction("resize_cb", (Icallback) resize_cb);
  IupSetFunction("exit_cb",   (Icallback) exit_cb);
  IupSetFunction("load_cb", (Icallback) load_cb);
  IupSetFunction("repaint_cb", (Icallback) iup_repaint_cb);

  /* run default model file */
  dvrlua_run("main.lua");

  /* set v3d viewing parameters */
  V3dRegFunc(iup_canvas, v3d_repaint_cb, v3d_draft_cb, boundingbox_cb);
  V3dSetType(iup_canvas, 'o');

  {double left, right, bottom, top, front, back;
  dvr_getviewvolume(&left, &right, &bottom, &top, &front, &back);
  V3dSetViewVolume(iup_canvas, left, right, bottom, top, front, back);}
  
  {double eyex, eyey, eyez, refx, refy, refz, vupx, vupy, vupz;
  dvr_getcamera(&eyex, &eyey, &eyez, &refx, &refy, &refz, &vupx, &vupy, &vupz);
  V3dSetCamera(iup_canvas, eyex, eyey, eyez, refx, refy, refz, vupx, vupy, vupz);}

  /* set hybrid image parameters */
  G3dGetVisSurfSize(&cw, &ch, NULL, NULL);
  iw = cw/2;
  ih = ch/2;
  red = (unsigned char *) malloc(iw*ih);
  green = (unsigned char *) malloc(iw*ih);
  blue = (unsigned char *) malloc(iw*ih);
  assert(red && green && blue);
  dvr_setimageinfo(iw, ih, red, green, blue);

  /* initializes LUT library */
  lut_open(255,0,255);
  lut_setcallback(lut_cb);
  
  dvr_getdensitycount(count, 5, 255);
  lut_histogram(count,255);

  cd_canvas = G3dCdGetCdCanvas(g3d_vissurf);
  cdActivate(cd_canvas);

  /* render image... this will take a while Zzzz Zzzzz */
  lut_cb(LUT_OK);
}

/***************************************************************************\
* Main function.                                                            *
\***************************************************************************/
int main(int argc, char **argv)
{
  char *err;

  /* loads program dialog definitions */
  IupOpen();

  err = IupLoad("main.led");
  if (err != NULL) {
    IupMessage("LED Error:", err);
  }
  /* if there are no errors */
  else {
    init();
  }

  IupMainLoop();
  IupClose();

  return 1;
}

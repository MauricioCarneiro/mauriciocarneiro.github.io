/***************************************************************************\
* DVRPRIV.H                                                                 *
* DVR private function declarations.                                        *
* Diego Nehab                                                               *
\***************************************************************************/

/***************************************************************************\
* strdup implementation.                                                    *
\***************************************************************************/
static char *mystrdup(char *s);

/***************************************************************************\
* Generate view volume in world coordinates.                                *
\***************************************************************************/
static void updateeye2world(void);

/***************************************************************************\
* Get voxel color and opacity from transference function table.             *
\***************************************************************************/
static void getLUT(unsigned char d, unsigned char *r, unsigned char *g, 
                  unsigned char *b, double *a);

/***************************************************************************\
* Calculate voxel normal by gradient aproximation.                          *
\***************************************************************************/
static void gradient(long x, long y, long z, double *ugx, double *ugy, double *ugz);

/***************************************************************************\
* Light voxel.                                                              *
\***************************************************************************/
static void lightvoxels(void);

/***************************************************************************\
* This is where the real rendring takes place. The function raycasts into   *
* the volume, from (x0, y0, z0) to (x1, y1, z1) in volume coordinates using *
* the tripod algorithm to generate the visited points. The color calculated *
* is returned in r, g and b.                                                *
\***************************************************************************/
static void raycast(long x0, long y0, long z0, long x1, long y1, long z1, 
                    unsigned char *ur, unsigned char *ug, unsigned char *ub);

/***************************************************************************\
* Calculates vectors used to interpolate in the projection plane.           *
\***************************************************************************/
static void interpolants(laVector4 dx, laVector4 dy, laVector4 p0, laVector4 p1);

/***************************************************************************\
* Cyrus beck auxiliar function.                                             *
\***************************************************************************/
static int clipt(double d, double n, double *tE, double *tS);

/***************************************************************************\
* Clips the line segment from p0 to p1 against the bounding box defined by  *
* left, right, bottom, top, front and back. The returned endpoints are in   *
* volume coordinates.                                                       *
\***************************************************************************/
static int cyrusbeck(laVector4 p0, laVector4 p1, long *x0, long *y0, long *z0,
                     long *x1, long *y1, long *z1);











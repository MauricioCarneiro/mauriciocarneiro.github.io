/*
** Definiccoes exportadas por LINALG.C
*/

#ifndef _LINALG_H
#define _LINALG_H

enum {
  iX,
  iY,
  iZ,
  iW
};

#define FLT_ZERO 1.0e-11

typedef double laVector3[3];    /* 3 element vector */
typedef double laVector4[4];    /* 4 element vector */
typedef double laMatrix3[3][3];    /* 3 by 3 element matrix */
typedef double laMatrix4[4][4];    /* 4 by 4 element matrix */

void laIdentity3( laMatrix3 m);  
void laIdentity4( laMatrix4 m);
int  laNormalize3( laVector3 v);
void laAddVector3( laVector3 v3, laVector3 v2, laVector3 v1);
void laAddVector4( laVector4 v3, laVector4 v2, laVector4 v1);
void laSubVector3( laVector3 v3, laVector3 v2, laVector3 v1);
void laSubVector4( laVector4 v3, laVector4 v2, laVector4 v1);
void laCopyVector3( laVector3 v2, laVector3 v1);
void laCopyVector4( laVector4 v2, laVector4 v1);
void laCopyMatrix3( laMatrix3 m2, laMatrix3 m1);
void laCopyMatrix4( laMatrix4 m2, laMatrix4 m1);
void laMatrixVectorMult4( laVector4 v2, laMatrix4 m, laVector4 v1);
void laMatrixMult(double *p, double *a, double *b, int l, int m, int n);
void laMatrixMult4( laMatrix4 m3, laMatrix4 m2, laMatrix4 m1);
void laCrossProduct( laVector3 p, laVector3 v, laVector3 w);
double laDotProduct (double *v1, double *v2);
int  laSolveSystem4( laMatrix4 a, double** b, int m);
void laLoadTranslation( laMatrix4 m, double tx, double ty, double tz );
void laLoadRotation( laMatrix4 m, int axis, double degrees );
void laLoadScale( laMatrix4 m, double sx, double sy, double sz );
int  laTranslate(laMatrix4 m, double tx, double ty, double tz);
int  laRotate(laMatrix4 m, int axis, double degrees);
int  laScale(laMatrix4 m, double sx, double sy, double sz);

#endif

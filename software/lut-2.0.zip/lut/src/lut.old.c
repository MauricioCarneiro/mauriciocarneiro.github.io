/***************************************************************************\
* LUT.C                                                                     *
* Interative transference function look up table editor for DVR programs.   *
* Diego Nehab, 14/11/97                                                     *
* Completely re-written, 12/2/99                                            *
* Changed by Mauricio Carneiro, 4/5/2000                                    *
\***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include <iup.h>
#include <iupkey.h>
#include <iupcb.h>

#include <cd.h>
#include <cdiup.h>
#include <cdimage.h>

#include "lut.h"
#include "func.h"
#include "funclua.h"
#include "trans.h"
#include "icons.h"

#define DOT_SIZE 3
#define bc(_) ((_)+DOT_SIZE+2)
#define bci(_) ((_)-DOT_SIZE-2)

/***************************************************************************\
* Global variables & data structure definitions.                            *
\***************************************************************************/
typedef unsigned char uchar;

static p_point selected;
static p_func function;
static p_func backup;
static p_trans transform;

static int drag;
static int zx;
static int zy;
static int px;
static int py;
static int hist_nclasses;  /* number of classes in the histogram */
static int hist_xmin;      /* minor number of the classes in the histogram */
static int hist_xmax;      /* major number of the classes in the histogram */
static int histsize;       /* size of the histogram */
static long int *histogram;/* histogram vector */

static Ihandle *iup_colorbrowser;
static Ihandle *iup_op_canvas;
static Ihandle *iup_pal_canvas;
static Ihandle *iup_color_canvas;
static Ihandle *iup_coordinate_label;
static Ihandle *iup_dialog;
static Ihandle *iup_opacity_menu;
static Ihandle *iup_menu;
static Ihandle *iup_img_zoom;
static Ihandle *iup_img_zoompressed;


static cdCanvas *cd_op_screen_canvas;
static cdCanvas *cd_color_screen_canvas;
static cdCanvas *cd_pal_screen_canvas;
static cdCanvas *cd_op_buffer_canvas;
static cdCanvas *cd_pal_buffer_canvas;
static cdCanvas *cd_color_buffer_canvas;
static void *cd_op_buffer_image;
static void *cd_pal_buffer_image;
static void *cd_color_buffer_image;
static void *cd_histogram_image;

static p_callback callback;

static Ihandle *iup_red_txt, *iup_green_txt, *iup_blue_txt;
uchar pal_red[LUT_CANVASWIDTH*20], pal_green[LUT_CANVASWIDTH*20], pal_blue[LUT_CANVASWIDTH*20];
int cb_red, cb_green, cb_blue, cb_has_data;
static int op_button_cb(Ihandle *self, int b, int e, int x, int y, char *r);
static int op_motion_cb(Ihandle *self, int x, int y, char *r);
static void op_zoommotion_cb (Ihandle *self, int x, int y, char *r);
/***************************************************************************\
* Drawing functions.                                                        *
\***************************************************************************/

/***************************************************************************\
* Draws a 3D looking frame.                                                 *
\***************************************************************************/
static void draw_frame(int xmin, int xmax, int ymin, int ymax) 
{
  cdLineStyle(CD_CONTINUOUS);
  cdForeground(cdEncodeColor(128, 128, 128));
  cdLine(xmin, ymin+1, xmin, ymax);
  cdLine(xmin+1, ymax, xmax-1, ymax);
  cdForeground(CD_BLACK);
  cdLine(xmin+1, ymin+2, xmin+1, ymax-1);
  cdLine(xmin+2, ymax-1, xmax-2, ymax-1);
  cdForeground(cdEncodeColor(223, 223, 223));
  cdLine(xmax-1, ymin+1, xmax-1, ymax-1);
  cdLine(xmin+1, ymin+1, xmax-1, ymin+1);
}
  
/***************************************************************************\
* Draws a control point with specified colors.                              *
\***************************************************************************/
static void draw_dot(int x, int y, long int fg, long int bg)
{
  cdLineStyle(CD_CONTINUOUS);
  cdLineWidth(1);
  cdForeground(bg);
  cdSector(bc(x), bc(y), 2*DOT_SIZE, 2*DOT_SIZE, 0, 360);
  cdForeground(fg);
  cdArc(bc(x), bc(y), 2*DOT_SIZE, 2*DOT_SIZE, 0, 360);
}

/***************************************************************************\
* Draws a mark for the palette bar.                                         *
\***************************************************************************/
static void draw_uptriang(int x, long int fg, long int bg)
{
  cdLineStyle(CD_CONTINUOUS);
  cdLineWidth(1);
  cdForeground(bg);
  cdBegin(CD_FILL);
  cdVertex(bc(x), bc(4));
  cdVertex(bc(x-2), bc(0));
  cdVertex(bc(x+2), bc(0));
  cdEnd();
  cdForeground(fg);
  cdLine(bc(x), bc(4), bc(x-2), bc(0));
  cdLine(bc(x), bc(4), bc(x+2), bc(0));
  cdLine(bc(x-2), bc(0), bc(x+2), bc(0));
}

/***************************************************************************\
* Selected color feedback canvas redraw callback.                           *
\***************************************************************************/
static int color_update(int r, int g, int b)
{
  cdCanvas *old_cv;

  old_cv = cdActiveCanvas();
  cdActivate(cd_color_buffer_canvas);

  cdBackground(CD_WHITE);
  cdForeground(cdEncodeColor((uchar) r, (uchar) g, (uchar) b));
  cdBox(2, 57, 2, 34);
  draw_frame(0, 59, 0, 36);
  if (old_cv) cdActivate(old_cv);

  return IUP_DEFAULT;
}

/***************************************************************************\
* Selected color feedback canvas redraw callback.                           *
\***************************************************************************/
static int color_redraw_cb(void)
{
  cdCanvas *old_cv;

  old_cv = cdActiveCanvas();
  cdActivate(cd_color_screen_canvas);
  cdPutImage(cd_color_buffer_image, 0, 0);
  if (old_cv) cdActivate(old_cv);

  return IUP_DEFAULT;
}

/***************************************************************************\
* Draws the selected point with the correct colors, and update the label    *
* that gives information about it's coordinates.                            *
\***************************************************************************/
static void draw_selected(p_point point) 
{
  int x, y, r, g, b, tag;
  char buffer[100];
  
  if (point != NULL) {
    func_getxy(point, &x, &y, &tag);
    trans_worldtoscreen(transform, &x, &y, x, y);
    func_getcolor(point, NULL, &r, &g, &b, NULL);
    switch (tag) {
      case FUNC_FIRST: case FUNC_RIGHT:
        draw_dot(x, y, CD_RED, CD_RED);
        break;
      case FUNC_LAST: case FUNC_LEFT:
        draw_dot(x, y, CD_BLUE, CD_BLUE);
        break;
      case FUNC_CONNECTED:
        draw_dot(x, y, CD_DARK_GREEN, CD_DARK_GREEN);
        break;
    }
    /* update RGB texts */
    if (IupGetInt(iup_red_txt, IUP_VALUE) != r) {
      sprintf(buffer, "%d", r);
      IupSetAttribute(iup_red_txt, IUP_VALUE, buffer);
    }
    if (IupGetInt(iup_green_txt, IUP_VALUE) != g) {
      sprintf(buffer, "%d", g);
      IupSetAttribute(iup_green_txt, IUP_VALUE, buffer);
    }
    if (IupGetInt(iup_blue_txt, IUP_VALUE) != b) {
      sprintf(buffer, "%d", b);
      IupSetAttribute(iup_blue_txt, IUP_VALUE, buffer);
    }
    /* update color in color browser */
    sprintf(buffer, "%d %d %d", r, g, b);
    IupSetAttribute(iup_colorbrowser, IUP_RGB, buffer);
    /* update coordinate label */
    trans_screentoworld(transform, &x, &y, x, y);
    sprintf(buffer, "(%d, %4.2f)", x, y/255.0);
    IupSetAttribute(iup_coordinate_label, IUP_TITLE, buffer);
    /* update selected color feedback */
    color_update(r, g, b);
    color_redraw_cb();
  } else {
    IupSetAttribute(iup_coordinate_label, IUP_TITLE, "");
  }
}

/***************************************************************************\
* Draws a point with tag dependent color.                                   *
\***************************************************************************/
static void draw_point(int x, int y, int tag) 
{
  switch (tag) {
    case FUNC_FIRST: case FUNC_RIGHT:
      draw_dot(x, y, CD_RED, CD_WHITE);
      break;
    case FUNC_LAST: case FUNC_LEFT:
      draw_dot(x, y, CD_BLUE, CD_WHITE);
      break;
    case FUNC_CONNECTED:
      draw_dot(x, y, CD_DARK_GREEN, CD_WHITE);
      break;
  }
}

/***************************************************************************\
* Draws a continuous line.                                                  *
\***************************************************************************/
static void draw_continuous(int x1, int y1, int x2, int y2)
{
  cdLineStyle(CD_CONTINUOUS);
  cdLineWidth(1);
  cdForeground(CD_BLACK);
  cdLine(bc(x1), bc(y1), bc(x2), bc(y2));
}

/***************************************************************************\
* Draws a dotted line.                                                      *
\***************************************************************************/
static void draw_dotted(int x1, int y1, int x2, int y2)
{
  cdLineStyle(CD_DOTTED);
  cdLineWidth(1);
  cdForeground(CD_BLACK);
  cdLine(bc(x1), bc(y1), bc(x2), bc(y2));
}

/***************************************************************************\
* Draws the whole palette.                                                  *
\***************************************************************************/
static void draw_palette(p_func func)
{
  p_point point = NULL;
  int x1, x2, tag1, tag2, y, cx1, cx2;
  int r1, g1, b1, r2, g2, b2;
  float r, g, b, dr, dg, db;
  long int os;

  /* create the interpolations between the start and end colors 
  of each segment in one line */
  while ((point = func_enum(func, point)) != NULL) {
    func_getcolor(point, &x2, &r2, &g2, &b2, &tag2);
  	trans_worldtoscreen(transform, &x2, NULL, x2, 0);
    switch (tag2) {
      case FUNC_FIRST: 
      case FUNC_RIGHT:
        break;
      case FUNC_LEFT:
      case FUNC_CONNECTED:
      case FUNC_LAST:
        dr = (float) (r2 - r1) / (x2 - x1 + 1);
        dg = (float) (g2 - g1) / (x2 - x1 + 1);
        db = (float) (b2 - b1) / (x2 - x1 + 1);

        cx1 = trans_clip(x1);
        cx2 = trans_clip(x2);
      
        /* if x2 is before the beginning, or x1 is after the end they are 
           of no use for the palette */
        if (cx2 == 0) break;
        if (cx1 == LUT_CANVASWIDTH) break;

        /*
        r = (float) (r2-r1)*(cx2-x1+1)/(x2-x1+1);
        g = (float) (g2-g1)*(cx2-x1+1)/(x2-x1+1);
        b = (float) (b2-b1)*(cx2-x1+1)/(x2-x1+1);
        */

        r = (float) (r1 + (((r2-r1)/(x2-x1+1))*(cx1-x1+1)));
        g = (float) (g1 + (((g2-g1)/(x2-x1+1))*(cx1-x1+1)));
        b = (float) (b1 + (((b2-b1)/(x2-x1+1))*(cx1-x1+1)));

        while (cx1 <= cx2) {
            pal_red[cx1] = (uchar) r;
            r += dr;
            pal_green[cx1] = (uchar) g;
            g += dg;
            pal_blue[cx1] = (uchar) b;
            b += db;
            cx1++;
          }
        break;
    }

    x1 = x2; 
    tag1 = tag2;
    r1 = r2; 
    g1 = g2; 
    b1 = b2;
  } 

  /* replicate the line generated above to fill the whole image */
  os = 256;
  for (y = 1; y < 20; y++) {
    memcpy(pal_red+os, pal_red, LUT_CANVASWIDTH);
    memcpy(pal_green+os, pal_green, LUT_CANVASWIDTH);
    memcpy(pal_blue+os, pal_blue, LUT_CANVASWIDTH);
    os += 256;
  }

  cdPutImageRGB(LUT_CANVASWIDTH, 20, pal_red, pal_green, pal_blue, bc(0), bc(0), 256, 20);

  /* draw the marks */
  while ((point = func_enum(func, point)) != NULL) {
    func_getcolor(point, &x1, NULL, NULL, NULL, &tag1);
    switch (tag1) {
      case FUNC_FIRST: 
      case FUNC_LAST:
      case FUNC_RIGHT:
        break;
      case FUNC_LEFT:
      case FUNC_CONNECTED:
		trans_worldtoscreen(transform, &x1, NULL, x1, 0);
        draw_uptriang(x1, CD_BLACK, CD_WHITE);
        break;
    }
  }
}

/***************************************************************************\
* Draws the whole opacity function.                                         *
\***************************************************************************/
static void draw_opacity(p_func func)
{
  p_point point = NULL;
  int x1, y1, x2, y2, tag1, tag2;

  /* we draw when we have the second point defining a segment. therefore,
  there is nothing to do when we get the first point. we first draw the line, 
  and then the first point of the segment. the second point will be drawn 
  as the first point of the next segment. the exception is the last point, 
  that is draw as the last point of it's segment */
  
  while ((point = func_enum(func, point)) != NULL) {
    func_getxy(point, &x2, &y2, &tag2);
    trans_worldtoscreen(transform, &x2, &y2, x2, y2);
    switch (tag2) {
      /* nothing to do */
      case FUNC_FIRST: 
        break;
      /* draw the segment line between it's two points, and the first
      point of the segment */
      case FUNC_LEFT:
      case FUNC_CONNECTED:
        draw_continuous(x1, y1, x2, y2);
        draw_point(x1, y1, tag1);
        break;
      /* draw the vertical discontinuity line between it's two points,
      and the first point of the segment. */
      case FUNC_RIGHT:
        draw_dotted(x1, y1, x2, y2);
        draw_point(x1, y1, tag1);
        break;
      /* we also draw the last point, since there are no more segments
      to go under it. */
      case FUNC_LAST:
        draw_continuous(x1, y1, x2, y2);
        draw_point(x1, y1, tag1);
        draw_point(x2, y2, tag2);
        break;
    }
    x1 = x2; y1 = y2; tag1 = tag2;
  }

  draw_selected(selected);
}

/***************************************************************************\
* Opacity editor repaint callback.                                          *
\***************************************************************************/
static int op_redraw_cb(void)
{
  cdCanvas *old_cv;

  /* we redraw everything in the back-buffer and then put the resulting
  image, so that we get a smooth redraw. */
  
  old_cv = cdActiveCanvas();
  cdActivate(cd_op_buffer_canvas);

  cdBackground(CD_WHITE); 
  cdClear();

  if (cd_histogram_image != NULL)
    cdPutImage(cd_histogram_image, bc(0), bc(0));

  draw_frame(0, 265, 0, 265);
  draw_opacity(function);
  cdActivate(cd_op_screen_canvas);
  cdPutImage(cd_op_buffer_image, 0, 0);
  if (old_cv) cdActivate(old_cv);

  return IUP_DEFAULT;
}

/***************************************************************************\
* Palette editor repaint callback.                                          *
\***************************************************************************/
static int pal_redraw_cb(void)
{
  cdCanvas *old_cv = cdActiveCanvas();
  cdActivate(cd_pal_buffer_canvas);

  cdBackground(CD_WHITE); 
  cdClear();

  draw_frame(0, 265, 0, 29);
  draw_palette(function);

  cdActivate(cd_pal_screen_canvas);
  cdPutImage(cd_pal_buffer_image, 0, 0);
  if (old_cv) cdActivate(old_cv);

  return IUP_DEFAULT;
}

/***************************************************************************\
* Redraw both the opacity function and the palette bar.                     *
\***************************************************************************/
static void both_redraw_cb(void)
{
  lut_histogram(histogram, histsize);
  op_redraw_cb();
  pal_redraw_cb();
}

/***************************************************************************\
* Moves the entire canvas.                                                  *
\***************************************************************************/
static int op_panningmotion_cb(Ihandle *self, int x, int y, char *r)
{
    /* sm means screen movement */
    int dx, dy, smx, smy; 
    
    cdCanvas2Raster(&x,&y);
    
    dx = x - px;
    dy = y - py;

    trans_screentoworldscale(transform,&dx,&dy);

    smx = ((transform->trans_xs) - dx);
    smy = ((transform->trans_ys) - dy);

/*
    if ((smx > 0) && (transform->trans_xs - abs(dx) < 0))
        return IUP_DEFAULT;

    else if ((smx < 0) && (transform->trans_xs - abs(dx) < LUT_CANVASWIDTH))
        return IUP_DEFAULT;

    else if ((smy > 0) && (transform->trans_ys - abs(dy) < 0))
        return IUP_DEFAULT;
      
    else if ((smy < 0) && (transform->trans_ys - abs(dy) < LUT_CANVASHEIGHT))
        return IUP_DEFAULT;

    else
    {
*/
    trans_settransform(&transform, 
                         smx,
                         smy, 
                         transform->trans_ws, 
                         transform->trans_hs);


      both_redraw_cb();

      px = x;
      py = y;

//    }

    return IUP_DEFAULT;
}

/***************************************************************************\
* Prepare for moving the canvas with the panning function                   *
\***************************************************************************/
static int op_buttonpanning_cb(Ihandle *self, int b, int e, int x, int y, char *r)
{

  cdCanvas2Raster(&x,&y);

  /* we just want button 1 here */
  if (b == IUP_BUTTON1)
  {
    if (e) 
    {
      IupSetAttribute(iup_op_canvas, IUP_CURSOR, IUP_HAND);
      px = x;
      py = y;
      IupSetFunction("op_motion_cb", (Icallback) op_panningmotion_cb);
    }
    else
    {
      IupSetFunction("op_motion_cb", (Icallback) op_motion_cb);
      IupSetAttribute(iup_op_canvas, IUP_CURSOR, IUP_ARROW);
      both_redraw_cb();

    }  

  }

  return IUP_DEFAULT;
}


static int op_move_cb (Ihandle *self)
{
  IupSetFunction("op_button_cb", (Icallback) op_buttonpanning_cb);
  return IUP_DEFAULT;
}


/***************************************************************************\
* When the Zoom button Transform Button is pressed, this is the new Button  *
* callback                                                                  *
\***************************************************************************/
static int op_buttonzoom_cb(Ihandle *self, int b, int e, int x, int y, char *r)
{
  cdCanvas *old_cv;
  int zw=0,zh=0, nx, ny, squarey;


  old_cv = cdActiveCanvas();
  cdActivate(cd_op_screen_canvas);
  cdCanvas2Raster(&x, &y);
  x = bci(x);
  y = bci(y);

  /* button 3 means zoom out */
  if ((b == IUP_BUTTON3) && (e == 1))
    trans_undotransform(&transform);

  else 
  {
    /* we don't want any other button here */

    if (b != IUP_BUTTON1)
      return IUP_DEFAULT;

    /* the user wants to create a zoom window from the point he's pressing to the
    point he lifts the mouse button (no matter what button is it) */
  
    if (e) {
      zx = x;
      zy = y;
      IupSetFunction("op_motion_cb", (Icallback) op_zoommotion_cb);
      return IUP_DEFAULT;
    }

    else {

      squarey = x - zx - zy;

      trans_screentoworld(transform,&zx,&zy,zx,zy);
      trans_screentoworld(transform,&nx, &ny, x, squarey);
    
      /* protection for zooms larger than the canvas */

      if (nx > transform->trans_ws) 
        nx = transform->trans_ws;

      if (ny > transform->trans_hs)
        ny = transform->trans_hs;

      if (nx < transform->trans_xs)
        nx = transform->trans_xs;

      if (ny < transform->trans_ys)
        ny = transform->trans_ys;

      zw = abs(zx - nx) + 1;
      zh = abs(zy - ny) + 1;

      /* protection for small zooms */

      if ((zw > 10) && (zh > 10))
        trans_settransform(&transform, min(zx,nx), min(zy,ny), zw, zh);

      IupSetFunction("op_motion_cb", (Icallback) op_motion_cb);

    }
  }  
  
  both_redraw_cb();

  if (old_cv) cdActivate(old_cv);
  return IUP_DEFAULT;
}


/***************************************************************************\
* Zoom Mouse Motion callback                                                *
\***************************************************************************/
static void op_zoommotion_cb (Ihandle *self, int x, int y, char *r)
{
  cdCanvas *old_cv;
  int squarey;

  op_redraw_cb();
  old_cv = cdActiveCanvas();
  cdActivate(cd_op_screen_canvas);
  cdCanvas2Raster(&x, &y);
  squarey = x - zx + zy;
  cdRect(zx,x,zy,squarey);
}




/***************************************************************************\
* Zoom Transform Button callback                                            *
\***************************************************************************/
static int op_zoom_cb(Ihandle *self)
{
  IupSetFunction("op_button_cb", (Icallback) op_buttonzoom_cb);
  IupSetAttribute(iup_op_canvas,IUP_CURSOR, IUP_CROSS);
  return IUP_DEFAULT;
}

/***************************************************************************\
* Normal button callback                                                    *
\***************************************************************************/
static int op_normal_cb(Ihandle *self)
{
  IupSetFunction("op_button_cb", (Icallback) op_button_cb);
  IupSetAttribute(iup_op_canvas,IUP_CURSOR, IUP_ARROW);
  return IUP_DEFAULT;
}

/***************************************************************************\
* Button callback.                                                          *
\***************************************************************************/
static int op_button_cb(Ihandle *self, int b, int e, int x, int y, char *r)
{
  cdCanvas *old_cv;

  old_cv = cdActiveCanvas();
  cdActivate(cd_op_screen_canvas);
  cdCanvas2Raster(&x, &y);
  x = bci(x);
  y = bci(y);

  trans_screentoworld(transform, &x, &y, x, y);

  switch (b) {

    /* the user wants to break a segment in two. if shift is pressed, we break
    in a continuous fashion, else we break discontinuously */
    case IUP_BUTTON3: 
      if (e) {
        if (isshift(r))
          func_splitconnected(function, x);
        else
          func_splitdisconnected(function, x);

        both_redraw_cb();
      }
      break;

    /* the user wants to select a point, maybe for dragging. if shift is pressed
    we cycle through overlapped points that he might want to pick. */
    case IUP_BUTTON1:
      if (e) {

        if (isshift(r))
          selected = func_pickxycycle(function, selected, x, y);
        else 
          selected = func_pickxy(function, NULL, x, y);
        if (selected)
          drag = 1;

        op_redraw_cb();
      }
      else {
        drag = 0;
      }
  }
    
  if (old_cv) cdActivate(old_cv);
  return IUP_DEFAULT;
}

/***************************************************************************\
* OK button callback.                                                       *
\***************************************************************************/
static int ok_cb(Ihandle *self)
{
  IupHide(iup_dialog);
  func_kill(backup);
  backup = NULL;
  if (callback != NULL)
    callback(LUT_OK);
  return IUP_DEFAULT;
}

/***************************************************************************\
* Apply button callback.                                                    *
\***************************************************************************/
static int apply_cb(Ihandle *self)
{
  func_kill(backup);
  backup = func_clone(function);
  if (callback != NULL)
    callback(LUT_APPLY);
  return IUP_DEFAULT;
}

/***************************************************************************\
* Cancel button callback.                                                   *
\***************************************************************************/
static int cancel_cb(Ihandle *self)
{
  IupHide(iup_dialog);
  func_kill(function);
  function = backup;
  backup = NULL;
  selected = NULL;
  if (callback != NULL)
    callback(LUT_CANCEL);
  return IUP_DEFAULT;
}

/***************************************************************************\
* Motion callback.                                                          *
\***************************************************************************/
static int op_motion_cb(Ihandle *self, int x, int y, char *r)
{
  cdCanvas *old_cv;

  if (drag) {
    old_cv = cdActiveCanvas();
    cdActivate(cd_op_screen_canvas);
    cdCanvas2Raster(&x, &y);
    x = bci(x);
    y = bci(y);

    trans_screentoworld(transform, &x, &y, x, y);

    /* all restrictions are dealt by the function, so that we don't have
    to worry here. */
    if (func_changexy(function, selected, x, y) == 1)
      both_redraw_cb();
    
    if (old_cv) cdActivate(old_cv);
  }

  return IUP_DEFAULT;  
}

/***************************************************************************\
* Color change callback.                                                    *
\***************************************************************************/
static int pal_change_cb(Ihandle *self, int r, int g, int b)
{
  char buffer[20];
  
  if (selected) {
    func_changecolor(function, selected, r, g, b);
    pal_redraw_cb();
  }

  /* update RGB texts */
  if (IupGetInt(iup_red_txt, IUP_VALUE) != r) {
    sprintf(buffer, "%d", r);
    IupSetAttribute(iup_red_txt, IUP_VALUE, buffer);
  }
  if (IupGetInt(iup_green_txt, IUP_VALUE) != g) {
    sprintf(buffer, "%d", g);
    IupSetAttribute(iup_green_txt, IUP_VALUE, buffer);
  }
  if (IupGetInt(iup_blue_txt, IUP_VALUE) != b) {
    sprintf(buffer, "%d", b);
    IupSetAttribute(iup_blue_txt, IUP_VALUE, buffer);
  }

  /* update selected color feedback */
  color_update(r, g, b);
  color_redraw_cb();

  return IUP_DEFAULT;  
}

/***************************************************************************\
* Color change callback.                                                    *
\***************************************************************************/
static int pal_drag_cb(Ihandle *self, unsigned char r, unsigned char g, 
  unsigned char b)
{
  char buffer[20];

  if (selected) {
    func_changecolor(function, selected, r, g, b);
    pal_redraw_cb();
  }

  /* update RGB texts */
  if (IupGetInt(iup_red_txt, IUP_VALUE) != r) {
    sprintf(buffer, "%d", r);
    IupSetAttribute(iup_red_txt, IUP_VALUE, buffer);
  }
  if (IupGetInt(iup_green_txt, IUP_VALUE) != g) {
    sprintf(buffer, "%d", g);
    IupSetAttribute(iup_green_txt, IUP_VALUE, buffer);
  }
  if (IupGetInt(iup_blue_txt, IUP_VALUE) != b) {
    sprintf(buffer, "%d", b);
    IupSetAttribute(iup_blue_txt, IUP_VALUE, buffer);
  }

  /* update selected color feedback */
  color_update(r, g, b);
  color_redraw_cb();

  return IUP_DEFAULT;  
}

/***************************************************************************\
* When the focus leave the RGB texts.                                       *
\***************************************************************************/
static int pal_killfocus_cb(Ihandle *self)
{
  char buffer[30];
  int c, r, g, b;

  c = IupGetInt(self, IUP_VALUE);
  if (c < 0)
    IupSetAttribute(self, IUP_VALUE, "0");
  if (c > 255)
    IupSetAttribute(self, IUP_VALUE, "255");

  r = IupGetInt(iup_red_txt, IUP_VALUE);
  g = IupGetInt(iup_green_txt, IUP_VALUE);
  b = IupGetInt(iup_blue_txt, IUP_VALUE);
  
  sprintf(buffer, "%d %d %d", r, g, b);
  IupSetAttribute(iup_colorbrowser, IUP_RGB, buffer);
  color_update(r, g, b);
  color_redraw_cb();

  if (selected) {
    func_changecolor(function, selected, r, g, b);
    pal_redraw_cb();
  }

  return IUP_DEFAULT;
}

/***************************************************************************\
* Key any callback.                                                         *
\***************************************************************************/
int op_key_cC(Ihandle *self)
{
  if (selected) {
    func_getcolor(selected, NULL, &cb_red, &cb_green, &cb_blue, NULL);
    cb_has_data = 1;
  }
  return IUP_IGNORE;
}

int op_key_cV(Ihandle *self)
{
  if (selected && cb_has_data) {
    func_changecolor(function, selected, cb_red, cb_green, cb_blue);
    both_redraw_cb();
  }

  return IUP_IGNORE;
}

static int op_key_cb(Ihandle *self, int c)
{
  int x, y;
  int dx,dy;
  p_point temp;
  
  switch (c) {
    case K_DEL:
      temp = func_enum(function, selected);
      func_deletepoint(function, selected);
      selected = temp;
      both_redraw_cb();
      return IUP_IGNORE;
    case K_TAB:
      if (!drag) {
        selected = func_enum(function, selected);
        op_redraw_cb();
      }
      return IUP_IGNORE;
    case K_sTAB:
      if (!drag) {
        selected = func_enumback(function, selected);
        op_redraw_cb();
      }
      return IUP_IGNORE;
    case K_UP:
      if (selected) {
        dy = 1;
        func_getxy(selected, NULL, &y, NULL);
        trans_worldtoscreenscale(transform, NULL, &dy);
        if (func_changey(function, selected, y+dy))
          op_redraw_cb();
      }
      return IUP_IGNORE;
    case K_sUP:
      if (selected) {
        dy = 5;
        func_getxy(selected, NULL, &y, NULL);
        trans_worldtoscreenscale(transform, NULL, &dy);
        if (func_changey(function, selected, y+dy))
          op_redraw_cb();
      }
      return IUP_IGNORE;
    case K_DOWN:
      if (selected) {
        dy = 1;
        func_getxy(selected, NULL, &y, NULL);
        trans_worldtoscreenscale(transform, NULL, &dy);
        if (func_changey(function, selected, y-dy))
          op_redraw_cb();
      }
      return IUP_IGNORE;
    case K_sDOWN:
      if (selected) {
        dy = 5;
        func_getxy(selected, NULL, &y, NULL);
        trans_worldtoscreenscale(transform, NULL, &dy);
        if (func_changey(function, selected, y-dy))
          op_redraw_cb();
      }
      return IUP_IGNORE;
    case K_LEFT:
      if (selected) {
        dx = 1;
        func_getxy(selected, &x, NULL, NULL);
        trans_worldtoscreenscale(transform, &dx, NULL);;
        if (func_changex(function, selected, x-dx))
          both_redraw_cb();
      }
      return IUP_IGNORE;
    case K_sLEFT:
      if (selected) {
        dx = 5; 
        func_getxy(selected, &x, NULL, NULL);
        trans_worldtoscreenscale(transform, &dx, NULL);;
        if (func_changex(function, selected, x-dx))
          both_redraw_cb();
      }
      return IUP_IGNORE;
    case K_RIGHT:
      if (selected) {
        dx = 1;
        func_getxy(selected, &x, NULL, NULL);
        trans_worldtoscreenscale(transform, &dx, NULL);;
        if (func_changex(function, selected, x+dx))
          both_redraw_cb();
      }
      return IUP_IGNORE;
    case K_sRIGHT:
      if (selected) {
        dx = 5;
        func_getxy(selected, &x, NULL, NULL);
        trans_worldtoscreenscale(transform, &dx, NULL);;
        if (func_changex(function, selected, x+dx))
          both_redraw_cb();
      }
      return IUP_IGNORE;
  }

  return IUP_DEFAULT;
}

/***************************************************************************\
* Exported functions.                                                       *
\***************************************************************************/

/***************************************************************************\
* Loads a histogram to be used as the background of the function editor.    *
* The vector defines the voxel count for each density value. Passing a NULL *
* vector disables the current histogram.                                    *
\***************************************************************************/
int lut_histogram(long int *count, int countsize)
{
  cdCanvas *temp;
  cdCanvas *old_cv;
  double max;
  int i, lastcount=0;
  
  old_cv = cdActiveCanvas();
  cdActivate(cd_op_buffer_canvas);

  if (!count) {
    if (cd_histogram_image) {
      cdKillImage(cd_histogram_image);
      cd_histogram_image = NULL;
      return 1;
    }
  }

  histogram = count;  /* keep "count" as the actual histogram being displayed */
  histsize = countsize;
    
  if (!cd_histogram_image) {
    cd_histogram_image = cdCreateImage(256, 256);
  }

  temp = cdCreateCanvas(CD_IMAGE, cd_histogram_image);
  cdActivate(temp);
  cdForeground(cdEncodeColor(200, 200, 200));
  cdClear();
  
  max = 0;
  for (i=0; i<countsize; i++) {
    if (count[i] > max) {
      max = count[i];
    }
  }

  for (i=1; i<countsize; i++) {
      int x1 = (int) ((256*(float)(i-1))/countsize);
      int y1 = (int) (256*count[i-1]/max);
      int x2 = (int) (((float) 256*i)/countsize);
      int y2 = (int) (256*count[i]/max);
      trans_worldtoscreen(transform, &x1, &y1, x1, y1);
      trans_worldtoscreen(transform, &x2, &y2, x2, y2);
      cdLine(x1, y1, x2, y2);
  }

  if (old_cv) cdActivate(old_cv);

  op_redraw_cb();

  return 1;
}

/***************************************************************************\
* Read a function definition from file.                                     *
\***************************************************************************/
int lut_load(char *file)
{
  int res;
  
  trans_resettransform(&transform);

  res = funclua_load(function, file);

  /* after loading a new function, the selected point has no meaning and
  keeping a reference to it will crash the program. */
  selected = NULL;
  
  both_redraw_cb();
  return res;
}

/***************************************************************************\
* Save current function definition to file.                                 *
\***************************************************************************/
int lut_save(char *file)
{
  return funclua_save(function, file);
}

/***************************************************************************\
* Shows function editor window.                                             *
\***************************************************************************/
void lut_show(void)
{
  IupShow(iup_dialog);
  backup = func_clone(function);
  both_redraw_cb();
}

/***************************************************************************\
* Hides function window editor.                                             *
\***************************************************************************/
void lut_hide(void)
{
  func_kill(function);
  function = backup;
  backup = NULL;
  IupHide(iup_dialog);
}

/***************************************************************************\
* Get a discrete map of the currently defined function. The vector MUST be  *
* long enough to hold 256 values.                                           *
\***************************************************************************/
void lut_fillopacity(double *opacity) 
{
  p_point point = NULL;
  int x1, y1, x2, y2, tag1, tag2;
  int i;
  double dy, y;

  while ((point = func_enum(function, point)) != NULL) {
    func_getxy(point, &x2, &y2, &tag2);
//    trans_worldtoscreen(transform, &x2, &y2, x2, y2);
    switch (tag2) {
      case FUNC_FIRST:
      case FUNC_RIGHT:
        break;
      case FUNC_LAST:
        opacity[255] = y2 / 255.0;
      case FUNC_CONNECTED:
      case FUNC_LEFT:
        dy = (double) ((y2 - y1)) / (255.0 * (x2 - x1)) ;
        y = y1 / 255.0;
        for (i = x1; i < x2; i++) {
          opacity[i] = y;
          y += dy;
        }
        break;
    }
    x1 = x2; y1 = y2; tag1 = tag2;
  }
}

/***************************************************************************\
* Sets the callback function void callback(int what), that will be called   *
* to notify the program of the choice of the user LUT_OK, LUT_APPLY or      *
* LUT_CANCEL. Passing a NULL parameter unsets the callback.                 *
\***************************************************************************/
void lut_setcallback(p_callback cb)
{
  callback = cb;
}

/***************************************************************************\
* Get a discrete map of the currently defined palette. The vectors MUST be  *
* long enough to hold 256 values each.                                      *
\***************************************************************************/
void lut_fillcolor(char *red, char *green, char *blue) 
{
  p_point point = NULL;
  int x1, x2, tag1, tag2;
  int r1, g1, b1, r2, g2, b2;
  float r, g, b, dr, dg, db;

  /* create the interpolations between the start and end colors 
  of each segment in one line */
  while ((point = func_enum(function, point)) != NULL) {
    func_getcolor(point, &x2, &r2, &g2, &b2, &tag2);
//    trans_worldtoscreenscale(transform, &x2, NULL);
    switch (tag2) {
      case FUNC_FIRST: 
      case FUNC_RIGHT:
        break;
      case FUNC_LEFT:
      case FUNC_CONNECTED:
      case FUNC_LAST:
        r = (float) r1;
        g = (float) g1;
        b = (float) b1;
        dr = (float) ((r2 - r1)) / (x2 - x1 + 1);
        dg = (float) ((g2 - g1)) / (x2 - x1 + 1);
        db = (float) ((b2 - b1)) / (x2 - x1 + 1);
        while (x1 <= x2) {
          red[x1] = (uchar) r;
          r += dr;
          green[x1] = (uchar) g;
          g += dg;
          blue[x1] = (uchar) b;
          b += db;
          x1++;
        }
        break;
    }
    x1 = x2; tag1 = tag2;
    r1 = r2; g1 = g2; b1 = b2;
  }
}

/***************************************************************************\
* Sets the attributes of element i and returns i.                           *
\***************************************************************************/
static Ihandle *setattrs(Ihandle *i, char *a)
{
  IupSetAttributes(i, a);
  return i;
}

/***************************************************************************\
* Sets the attributes of element i and returns i.                           *
\***************************************************************************/
static Ihandle *setattr(Ihandle *i, char *a, char *v)
{
  IupSetAttribute(i, a, v);
  return i;
}

/***************************************************************************\
* Creates IUP objects.                                                      *
\***************************************************************************/
static void create_dialog(void)
{

/* Image Buttons Definition */

  iup_img_zoom = IupImage(23,22,img_zoom);
  IupSetAttribute (iup_img_zoom, "0", "0 0 0");   
  IupSetAttribute (iup_img_zoom, "1", "123 123 123");   
  IupSetAttribute (iup_img_zoom, "2", "189 189 189"); 
  IupSetAttribute (iup_img_zoom, "3", "222 222 222");
  IupSetAttribute (iup_img_zoom, "4", "255 255 255");
  IupSetHandle ("iup_img_zoom", iup_img_zoom);


  iup_img_zoompressed = IupImage(23,22,img_zoompressed);
  IupSetAttribute (iup_img_zoompressed, "0", "0 0 0");   
  IupSetAttribute (iup_img_zoompressed, "1", "123 123 123");   
  IupSetAttribute (iup_img_zoompressed, "2", "189 189 189"); 
  IupSetAttribute (iup_img_zoompressed, "3", "222 222 222");
  IupSetAttribute (iup_img_zoompressed, "4", "255 255 255");
  IupSetHandle ("iup_img_zoompressed", iup_img_zoompressed);


/* Menu definition */ 
  iup_menu = setattrs(
    IupMenu(
      IupSubmenu(	
        "File",
        IupMenu(
  	      IupItem("Load","load_op_cb"),
          IupItem("Save","save_op_cb"),
	        NULL)), 
      NULL), "SIZE=5");
  
  IupSetHandle( "iup_menu",iup_menu);    

/* Dialog Definition */
  iup_dialog = setattrs(
    IupDialog(
      IupVbox(
          setattrs(IupFill(),"SIZE=5"),
          IupHbox(
            setattrs(IupFill(),"SIZE=5"),
            setattrs(IupButton("->","op_normal_cb"),"SIZE=18x15"),
            setattrs(IupFill(),"SIZE=5"),
            setattrs(IupButton("+","op_zoom_cb"),"SIZE=23x22,IMAGE=iup_img_zoom, IMPRESS=iup_img_zoompressed"),
            setattrs(IupFill(),"SIZE=5"),
            setattrs(IupButton("M","op_move_cb"),"SIZE=18x15"),
            setattrs(IupFill(),"SIZE=5"),
            setattrs(IupButton("M","op_reset_cb"),"SIZE=18x15"),

            IupFill(),
            NULL),

          setattrs(IupFill(), "SIZE=5"),
          IupHbox(
            setattrs(IupFill(), "SIZE=5"),
            iup_coordinate_label = setattrs(IupLabel(""), "SIZE=100"),
            setattrs(IupFill(), "SIZE=5"),
            NULL),
          setattrs(IupFill(), "SIZE=2"),
          IupHbox(
            setattrs(IupFill(), "SIZE=5"),
            IupVbox(
              iup_op_canvas = setattrs(IupCanvas("op_redraw_cb"), 
                "BUTTON_CB=op_button_cb,"
                "MOTION_CB=op_motion_cb,"
                "RASTERSIZE=266x266,"
                "K_ANY=op_key_cb,"
                "BORDER=NO,"
                "EXPAND=NO,"
                "BGCOLOR=\"255 255 255\""),
              setattrs(IupFill(), "SIZE=2"),
              iup_pal_canvas = setattrs(IupCanvas("pal_redraw_cb"), 
                "RASTERSIZE=266x30,"
                "K_ANY=op_key_cb,"
                "BORDER=NO,"
                "EXPAND=NO,"
                "BGCOLOR=\"255 255 255\""),
              NULL),
            setattrs(IupFill(), "SIZE=5"),
            IupVbox(
              iup_colorbrowser = setattrs(IupColorBrowser(),
                "DRAG_CB=pal_drag_cb,"
                "CHANGE_CB=pal_change_cb"),
              setattrs(IupFill(), "SIZE=5"),
              IupHbox(
                IupFill(),
                IupVbox(
                  IupFill(),
                  setattrs(IupHbox(
                    setattr(IupLabel("Red:"), IUP_SIZE, "28"),
                    iup_red_txt = setattrs(IupText("do_nothing"),
                      "SIZE=25x12,"
                      "BGCOLOR=\"255 255 255\","
                      "KILLFOCUS_CB=pal_killfocus_cb"),
                    NULL), "ALIGNMENT=ACENTER"),
                  setattrs(IupFill(), "SIZE=2"),
                  setattrs(IupHbox(
                    setattr(IupLabel("Green:"), IUP_SIZE, "28"),
                    iup_green_txt = setattrs(IupText("do_nothing"),
                      "SIZE=25x12,"
                      "BGCOLOR=\"255 255 255\","
                      "KILLFOCUS_CB=pal_killfocus_cb"),
                    NULL), "ALIGNMENT=ACENTER"),
                  setattrs(IupFill(), "SIZE=2"),
                  setattrs(IupHbox(
                    setattr(IupLabel("Blue:"), IUP_SIZE, "28"),
                    iup_blue_txt = setattrs(IupText("do_nothing"), 
                      "SIZE=25x12,"
                      "BGCOLOR=\"255 255 255\","
                      "KILLFOCUS_CB=pal_killfocus_cb"),
                    NULL), "ALIGNMENT=ACENTER"),
                  IupFill(),
                  NULL),
                setattrs(IupFill(), "SIZE=10"),
                IupVbox(
                  IupFill(),
                  iup_color_canvas = setattrs(IupCanvas("color_redraw_cb"),
                    "RASTERSIZE=60x37,"
                    "BORDER=NO,"
                    "EXPAND=NO,"
                    "BGCOLOR=\"255 255 255\""),
                  IupFill(),
                  NULL),
                IupFill(),
                NULL),
              IupHbox(
                IupFill(),
                setattr(IupButton("OK", "lut_ok_cb"), IUP_SIZE, "40"),
                setattrs(IupFill(), "SIZE=5"),
                setattr(IupButton("Apply", "lut_apply_cb"), IUP_SIZE, "40"),
                setattrs(IupFill(), "SIZE=5"),
                setattr(IupButton("Cancel", "lut_cancel_cb"), IUP_SIZE, "40"),
                setattrs(IupFill(),"SIZE=5"),
                NULL),
                setattrs(IupFill(),"SIZE=5"),
              NULL),
            setattrs(IupFill(),"SIZE=5"),
            NULL),
          setattrs(IupFill(),"SIZE=5"),
          NULL)   /* end matrix HBOX */

         ),  /* end dialog ( ) */
        "TITLE=\"Transfer Function Editor\","
        "CLOSE_CB=lut_cancel_cb,"
        "MAXBOX=NO,"
        "MINBOX=NO,"
        "RESIZE=NO,"
        "K_cV=op_key_cV,"
        "K_cC=op_key_cC");

  IupSetHandle( "iup_dialog",iup_dialog);


  /* Linking the menu to the dialog */

  setattr(IupGetHandle("iup_dialog"),IUP_MENU, "iup_menu");

}

/***************************************************************************\
* Initializes the IUP interface.                                            *
\***************************************************************************/
static int init_iup(void)
{
  IupColorBrowserOpen();

  create_dialog();
  
  IupMap(iup_dialog);

  /* associate callbacks */
  IupSetFunction("op_button_cb",   (Icallback) op_button_cb);
  IupSetFunction("op_redraw_cb",   (Icallback) op_redraw_cb);
  IupSetFunction("op_motion_cb",   (Icallback) op_motion_cb);
  IupSetFunction("op_key_cb",      (Icallback) op_key_cb);
  IupSetFunction("op_key_cC",      (Icallback) op_key_cC);
  IupSetFunction("op_key_cV",      (Icallback) op_key_cV);

  /* set the transform buttons callbacks */
  IupSetFunction("op_zoom_cb",     (Icallback) op_zoom_cb);
  IupSetFunction("op_normal_cb",   (Icallback) op_normal_cb);
  IupSetFunction("op_move_cb",     (Icallback) op_move_cb);

  IupSetFunction("pal_redraw_cb", (Icallback) pal_redraw_cb);
  IupSetFunction("pal_drag_cb", (Icallback) pal_drag_cb);
  IupSetFunction("pal_change_cb", (Icallback) pal_change_cb);
  IupSetFunction("pal_killfocus_cb", (Icallback) pal_killfocus_cb);

  IupSetFunction("color_redraw_cb", (Icallback) color_redraw_cb);

  IupSetFunction("lut_cancel_cb", (Icallback) cancel_cb);
  IupSetFunction("lut_ok_cb", (Icallback) ok_cb);
  IupSetFunction("lut_apply_cb", (Icallback) apply_cb);



  /* set masks for RGB text. it only works after mapping the elements */
  IupSetAttribute(iup_red_txt, IUP_MASK, "\\3#");
  IupSetAttribute(iup_green_txt, IUP_MASK, "\\3#");
  IupSetAttribute(iup_blue_txt, IUP_MASK, "\\3#");

  IupSetAttribute(iup_red_txt, IUP_VALUE, "255");
  IupSetAttribute(iup_green_txt, IUP_VALUE, "0");
  IupSetAttribute(iup_blue_txt, IUP_VALUE, "0");

  return 1;
}

/***************************************************************************\
* Create CD objcects.                                                       *
\***************************************************************************/
static int init_cd(void) 
{
  cdCanvas *old_cv;

  old_cv = cdActiveCanvas();

  cd_op_screen_canvas = cdCreateCanvas(CD_IUP, iup_op_canvas);
  cdActivate(cd_op_screen_canvas);
  cd_op_buffer_image = cdCreateImage(266, 266);
  cd_op_buffer_canvas = cdCreateCanvas(CD_IMAGE, cd_op_buffer_image);

  cd_pal_screen_canvas = cdCreateCanvas(CD_IUP, iup_pal_canvas);
  cdActivate(cd_pal_screen_canvas);
  cd_pal_buffer_image = cdCreateImage(266, 30);
  cd_pal_buffer_canvas = cdCreateCanvas(CD_IMAGE, cd_pal_buffer_image);

  cd_color_screen_canvas = cdCreateCanvas(CD_IUP, iup_color_canvas);
  cdActivate(cd_color_screen_canvas);
  cd_color_buffer_image = cdCreateImage(60, 37);
  cd_color_buffer_canvas = cdCreateCanvas(CD_IMAGE, cd_color_buffer_image);
  color_update(255, 0, 0);

  if (old_cv) cdActivate(old_cv);

  return 1;
}

/***************************************************************************\
* Initialize transference function editor.                                  *
\***************************************************************************/
int lut_open(int nclasses, int xi, int xf)
{

  hist_nclasses = nclasses;
  hist_xmin = xi;
  hist_xmax = xf;

  function = func_create(DOT_SIZE);
  if (function == NULL)
    return 0;

  transform = trans_create(hist_xmax-hist_xmin);
  if (transform == NULL)
    return 0;

  backup = NULL;
  cb_has_data = 0;

  funclua_open();

  cd_op_screen_canvas = NULL;
  cd_op_buffer_canvas = NULL;
  cd_op_buffer_image = NULL;
  cd_pal_screen_canvas = NULL;
  cd_pal_buffer_canvas = NULL;
  cd_pal_buffer_image = NULL;
  cd_color_screen_canvas = NULL;
  cd_color_buffer_canvas = NULL;
  cd_color_buffer_image = NULL;
  cd_histogram_image = NULL;

  callback = NULL;

  /* long live short-circuit!! */
  if (init_iup() == 0 || init_cd() == 0) {
    func_kill(function);
    return 0;
  }

  return 1;
}

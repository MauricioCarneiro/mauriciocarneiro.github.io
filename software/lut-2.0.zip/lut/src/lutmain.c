#include <iup.h>
#include "lut.h"

void main(void)
{
  IupOpen();
  op_open();
  op_show();
  IupMainLoop();
  IupClose();
}
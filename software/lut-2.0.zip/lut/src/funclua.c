/**********************************************************************\
* FUNCLUA.C                                                            *
* Persistence support for the FUNC module.                             *
* Diego Nehab, 10/2/99                                                 *
\**********************************************************************/

#include <stdio.h>

#include "func.h"
#include "lua.h"
#include "lauxlib.h"

static p_func current = NULL;

/**********************************************************************\
* Sets the y coort of the first point.                                 *
\**********************************************************************/
static void funclua_first(void)
{
  int y, r, g, b;

  y = (int) luaL_check_number(1);
  r = (int) luaL_check_number(2);
  g = (int) luaL_check_number(3);
  b = (int) luaL_check_number(4);

  func_changey(current, current->first, y);
  func_changecolor(current, current->first, r, g, b);
}

/**********************************************************************\
* Sets the y coort of the first point.                                 *
\**********************************************************************/
static void funclua_last(void)
{
  int y, r, g, b;

  y = (int) luaL_check_number(1);
  r = (int) luaL_check_number(2);
  g = (int) luaL_check_number(3);
  b = (int) luaL_check_number(4);

  func_changey(current, current->last, y);
  func_changecolor(current, current->last, r, g, b);
}

/**********************************************************************\
* Insert a new connected point.                                        *
\**********************************************************************/
static void funclua_connected(void)
{
  int x, y, r, g, b;

  x = (int) luaL_check_number(1);
  y = (int) luaL_check_number(2);
  r = (int) luaL_check_number(3);
  g = (int) luaL_check_number(4);
  b = (int) luaL_check_number(5);

  func_insertconnected(current, x, y, r, g, b);
}

/**********************************************************************\
* Insert a new connected point.                                        *
\**********************************************************************/
static void funclua_disconnected(void)
{
  int x, y1, y2;
  int r1, g1, b1, r2, g2, b2;

  x = (int) luaL_check_number(1);
  y1 = (int) luaL_check_number(2);
  r1 = (int) luaL_check_number(3);
  g1 = (int) luaL_check_number(4);
  b1 = (int) luaL_check_number(5);
  y2 = (int) luaL_check_number(6);
  r2 = (int) luaL_check_number(7);
  g2 = (int) luaL_check_number(8);
  b2 = (int) luaL_check_number(9);

  func_insertdisconnected(current, x, y1, r1, g1, b1, y2, r2, g2, b2);
}

/**********************************************************************\
* Initializes the persistency module.                                  *
\**********************************************************************/
void funclua_open(void)
{
  lua_open();
  
  lua_register("first", funclua_first);
  lua_register("connected", funclua_connected);
  lua_register("disconnected", funclua_disconnected);
  lua_register("last", funclua_last);
}

/**********************************************************************\
* Loads a transfer function from file into func.                       *
\**********************************************************************/
int funclua_load(p_func func, char *file)
{
  if (func == NULL)
    return 0;

  /* reset function to identity */
  func_reset(func);

  /* this will be used by all callbacks */
  current = func;
  
  /* execute the program */
  if (lua_dofile(file) != 0)
    return 0;

  return 1;
}

/**********************************************************************\
* Saves a transfer function from func to file.                         *
\**********************************************************************/
int funclua_save(p_func func, char *file)
{
  FILE *fout;
  p_point point = NULL;
  int x, y, tag, r, g, b;

  fout = fopen(file, "w");
  if (fout == NULL)
    return 0;

  while ((point = func_enum(func, point)) != NULL) {
    func_getxy(point, &x, &y, &tag);
    func_getcolor(point, NULL, &r, &g, &b, NULL);
    switch (tag) {
      case FUNC_FIRST: 
        fprintf(fout, "first(%d, %d, %d, %d)\n", y, r, g, b);
        break;
      case FUNC_CONNECTED:
        fprintf(fout, "connected(%d, %d, %d, %d, %d)\n", x, y, r, g, b);
        break;
      case FUNC_LEFT:
        fprintf(fout, "disconnected(%d, %d, %d, %d, %d, ", x, y, r, g, b);
        break;
      case FUNC_RIGHT:
        fprintf(fout, "%d, %d, %d, %d)\n", y, r, g, b);
        break;
      case FUNC_LAST:
        fprintf(fout, "last(%d, %d, %d, %d)\n", y, r, g, b);
        break;
    }
  }

  fclose(fout);

  return 1;
}
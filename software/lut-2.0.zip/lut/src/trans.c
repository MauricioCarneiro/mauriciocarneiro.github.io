/***********************************************************************\
* FUNC.C                                                                *
* linear transforms to adjust data from screen to world coordinates.    *
*                                                                       *
* Autor : Mauricio Oliveira Carneiro, 27/4/2000                         *
\***********************************************************************/


/**********************************************************************\
* Included headers.                                                    *
\**********************************************************************/
#include <math.h>
#include <stdlib.h>

#include "lut.h"
#include "trans.h"


/**********************************************************************\
* Rounds a float to an integer with floor to <= 0.5 and ceil to >0.5.  *
\**********************************************************************/
int round (float x)
{
  return ((int) floor (x+0.5));
}

/**********************************************************************\
* Returns a pointer to an initial function, the identity function.     *
\**********************************************************************/

p_trans trans_create(int newww)
{
  p_trans t;

  /* try to get memory */
  t = (p_trans) calloc (1, sizeof (t_trans));
  if (t == NULL)
    return NULL;

  /* determinates the identity transform with the following parameters */ 

  t->trans_xs = 0;    
  t->trans_ys = 0;    
  t->trans_ws = newww;    
  t->trans_hs = LUT_CANVASHEIGHT;    
  t->trans_xw = 0;    
  t->trans_yw = 0;    
  t->trans_ww = newww;    
  t->trans_hw = TRANS_HEIGHTPRECISION;  

  trans_calccoeficients(t);
  
  return t;
}

/***********************************************************************\
* Resets the transform parameters to Default.                           *
\***********************************************************************/
int trans_resettransform(p_trans t)
{
  /* determinates the initial transform */ 

  if (t)	
  {
    t->trans_xs = t->trans_xw;
    t->trans_ys = t->trans_yw;
    t->trans_ws = LUT_CANVASWIDTH;
    t->trans_hs = LUT_CANVASHEIGHT;
    trans_calccoeficients(t);
	  
    return 1;
  }
  
  return 0;
}
/***********************************************************************\
* Zooms in                                                              *
\***********************************************************************/
void trans_zoomin (p_trans t, int x, int y, int w, int h)
{
  int dx=0;

  /* the zoom out can only be done if the x and y coordinates are 
   at least equal to the world's x and y */ 

  trans_settransform(&t, x, y, w, h);

  /* in case I have an overflow in the left side ... */
  if ((x < t->trans_xw) || (y < t->trans_yw))
    trans_panning(t,t->trans_xw, t->trans_yw);

  /* in case I have an overflow in the right side ... */
  else if (x+w > t->trans_xw + t->trans_ww)
  {
    dx = (x + w) - (t->trans_xw + t->trans_ww);
    trans_panning(t,x-dx, y);
  }
}

/***********************************************************************\
* Zooms out                                                             *
\***********************************************************************/
void trans_zoomout (p_trans t, int x, int y, int w, int h)
{
  int dx=0;

  /* the zoom out can only be done if the x and y coordinates are 
     at least equal to the world's x and y */ 

  trans_settransform(&t, x, y, w, h);

  /* in case I have an overflow in the left side ... */
  if ((x < t->trans_xw) || (y < t->trans_yw))
    trans_panning(t,t->trans_xw, t->trans_yw);

  /* in case I have an overflow in the right side ... */
  else if (x+w > t->trans_xw + t->trans_ww)
  {
    dx = (x + w) - (t->trans_xw + t->trans_ww);
    trans_panning(t,x-dx, y);
  }

}

/***********************************************************************\
* Moves the entire screen                                               *
\***********************************************************************/
void trans_panning (p_trans t, int x, int y)
{
  if ((x >= t->trans_xw) && (y >= t->trans_yw) &&
      (x + t->trans_ws <= t->trans_xw + t->trans_ww))
  trans_settransform(&t, x, y, t->trans_ws, t->trans_hs);
}

/***********************************************************************\
* Set Screen Coordinates                                                *
\***********************************************************************/
void trans_settransform (p_trans *t, int x, int y, int w, int h)
{
  if((w > 0)  && (w < (*t)->trans_ww) && 
     (h > 0)  && (h < (*t)->trans_hw))
  {
    (*t)->trans_xs = x;
    (*t)->trans_ys = y;
    (*t)->trans_ws = w;
    (*t)->trans_hs = h;

    /* Recalculate the coeficients */
    trans_calccoeficients(*t);
  }
  
  else
    trans_resettransform(*t);
}

/***********************************************************************\
* Transform from world coordinates to screen coordinates                *
\***********************************************************************/

void trans_worldtoscreen(p_trans t, int *xs, int *ys, int x, int y)
{
  if (xs)
    *xs = round((t->trans_axws * x) - t->trans_bxws);

  if (ys)
    *ys = round((t->trans_ayws * y) - t->trans_byws);
}

/***********************************************************************\
* Transform from screen coordinates to world coordinates                *
\***********************************************************************/

void trans_screentoworld(p_trans t, int *xw, int *yw, int x, int y)
{
  if (xw)
    *xw = round((t->trans_axsw * x) + t->trans_bxsw);

  if (yw)
    *yw = round((t->trans_aysw * y) + t->trans_bysw);
}

/***********************************************************************\
* Transform from screen to world scale                                  *
\***********************************************************************/

void trans_screentoworldscale(p_trans t, int *alpha, int *beta)
{
  if (alpha)
    *alpha = round (*alpha * t->trans_axsw);
  
  if (beta)
    *beta = round(*beta * t->trans_aysw);
}

/***********************************************************************\
* Transform from world to screen scale                                  *
\***********************************************************************/

void trans_worldtoscreenscale(p_trans t, int *alpha, int *beta)
{
  if (alpha)
    *alpha = round(*alpha * t->trans_axws);

  if (beta)
    *beta = round(*beta * t->trans_ayws);
}

/***********************************************************************\
* Push actual transformation into the stack                             *
\***********************************************************************/

int trans_pushtransform(p_trans t)
{
  if (!t)
    return 0;

  /* Allocate space for the next and last nodes */
  t->u->next = (p_undo) malloc (sizeof (undo));
  
  if (!t->u->next)
    return 0;

  t->u->next->next = NULL;

  /* point actual node, to last of the new one*/
  t->u->next->last = t->u;
  
  /* Now, the actual node, is the next */
  t->u = t->u->next;

  t->u->trans_lastxs = t->trans_xs;
  t->u->trans_lastys = t->trans_ys;
  t->u->trans_lastws = t->trans_ws; 
  t->u->trans_lasths = t->trans_hs; 
  t->u->trans_lastaxsw = t->trans_axsw;
  t->u->trans_lastbxsw = t->trans_bxsw; 
  t->u->trans_lastaysw = t->trans_aysw; 
  t->u->trans_lastbysw = t->trans_bysw; 
  t->u->trans_lastaxws = t->trans_axws; 
  t->u->trans_lastbxws = t->trans_bxws; 
  t->u->trans_lastayws = t->trans_ayws; 
  t->u->trans_lastbyws = t->trans_byws; 

  return 1;

}

/***********************************************************************\
* Pops the last transformation from stack                               *
\***********************************************************************/

int trans_poptransform(p_trans t)
{
  int x,y,wover2,hover2;
  
  if (t->u->last == NULL)
    return 0;


  wover2 = (int) t->trans_ws / 2;
  hover2 = (int) t->trans_hs / 2;

  trans_screentoworldscale(t,&wover2,&hover2);

  /* get the actual viewport's center point x,y */   
  x = (int) wover2 + t->trans_xs; 
  y = (int) hover2 + t->trans_ys;
  
  /* get the old transform coeficients so that I'll be able to get the actual
     x,y in the old transform */

  t->trans_ws = t->u->trans_lastws; 
  t->trans_hs = t->u->trans_lasths; 

  t->trans_axsw = t->u->trans_lastaxsw;
  t->trans_bxsw = t->u->trans_lastbxsw;
  t->trans_aysw = t->u->trans_lastaysw;
  t->trans_bysw = t->u->trans_lastbysw;
  t->trans_axws = t->u->trans_lastaxws;
  t->trans_bxws = t->u->trans_lastbxws;
  t->trans_ayws = t->u->trans_lastayws;
  t->trans_byws = t->u->trans_lastbyws;

  /* put them in the old viewport */
  trans_worldtoscreen(t, &x, &y, x, y);


  /* calculate new xs and ys */
  wover2 = (int) t->trans_ws / 2;
  hover2 = (int) t->trans_hs / 2;

  trans_screentoworldscale(t,&wover2,&hover2);

  t->trans_xs = x - wover2;
  t->trans_ys = y - hover2;

  /* the actual undo transform parameters are now the last ones */
  t->u = t->u->last;

  /* just to make sure */
  if (t->u->next)
    free (t->u->next);
  
  t->u->next = NULL;

  return 1;

}

/***********************************************************************\
* Calculates the coeficients of a transformation                        *
\***********************************************************************/

int trans_calccoeficients(p_trans t)
{
  if (!t)
    return 0;
  
  t->trans_axws = (float) LUT_CANVASWIDTH  / (float) t->trans_ws;
  t->trans_bxws = (float) LUT_CANVASHEIGHT * (float) t->trans_xs / (float) t->trans_ws;
  t->trans_ayws = (float) LUT_CANVASHEIGHT / (float) t->trans_hs;
  t->trans_byws = (float) LUT_CANVASWIDTH  * t->trans_ys / t->trans_hs;

  t->trans_axsw = (float) t->trans_ws / (float) LUT_CANVASWIDTH;
  t->trans_bxsw = (float) t->trans_xs;
  t->trans_aysw = (float) t->trans_hs / (float) LUT_CANVASHEIGHT;
  t->trans_bysw = (float) t->trans_ys;

  return 1;

}

/***********************************************************************\
* Clips points that are no longer inside the viewport                   *
\***********************************************************************/
int trans_clip(int realinteger)
{
  if (realinteger < 0)
    return 0;
  else if (realinteger > LUT_CANVASWIDTH)
    return LUT_CANVASWIDTH;
  else 
    return realinteger;
}

/***********************************************************************\
* Sets the maximum histogram Y value (for bounding reasons)             *
\***********************************************************************/
void trans_setmaxhistvalue(p_trans t, int max)
{
  t->trans_maxhistvalue = max;
}
   

/**********************************************************************\
* FUNC.C                                                               *
* Linear by parts function data structure.                             *
* Diego Nehab, 10/2/99                                                 *
\**********************************************************************/

/**********************************************************************\
* Included headers.                                                    *
\**********************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "func.h"

/**********************************************************************\
* Macros.                                                              *
\**********************************************************************/
#ifndef max
#define max(a, b) ((a > b) ? a : b)
#endif

#ifndef min
#define min(a, b) ((a < b) ? a : b)
#endif

#define segment_y(x, x0, y0, x1, y1) ((int)(y0 + ((float) (y1 - y0))*(x - x0)/(x1 - x0)))

/**********************************************************************\
* Auxiliary functions prototypes.                                      *
\**********************************************************************/
static p_point point_new(void);
static void point_print(p_point point);

/**********************************************************************\
* Returns a pointer to an initial function, the identity function.     *
\**********************************************************************/
p_func func_create(int dot_size)
{
  p_func func;
  p_point first, last;

  /* try to get memory */
  func = (p_func) calloc(1, sizeof(t_func));
  if (func == NULL)
    return NULL;
  
  first = point_new();
  last = point_new();
  if (last == NULL || first == NULL) {
    /* freeing a NULL pointer is ANSI, but some implementations 
    don't like it */
    if (first) free(first); 
    if (last) free(last);
    return NULL;
  }

  /* the identity function is defined by two points, the first at
  (0, 0) and the last at (255, 255) */
  first->left = NULL;
  first->right = last;
  first->tag = FUNC_FIRST;
  first->x = first->y = 0;
  first->r = first->g = first->b = 0;

  last->left = first;
  last->right = NULL;
  last->tag = FUNC_LAST;
  last->x = last->y = 255;
  last->r = last->g = last->b = 255;

  func->first = first;
  func->last = last;
  func->dot_size = dot_size;

  return func;
}

/**********************************************************************\
* Resets a function to identity.                                       *
\**********************************************************************/
int func_reset(p_func func)
{
  p_point temp, killer;
  p_point first, last;

  /* just checking... */
  if (func == NULL)
    return 0;

  /* if there are points, kill them */
  if ((killer = func->first) != NULL) {
    do {
      temp = killer->right;
      free(killer);
      killer = temp;
    } while (killer != NULL);
  }

  first = point_new();
  last = point_new();
  if (last == NULL || first == NULL) {
    /* freeing a NULL pointer is ANSI, but some implementations 
    don't like it */
    if (first) free(first); 
    if (last) free(last);
    return 0;
  }

  /* the identity function is defined by two points, the first at
  (0, 0) and the last at (255, 255) */
  first->left = NULL;
  first->right = last;
  first->tag = FUNC_FIRST;
  first->x = first->y = 0;
  first->r = first->g = first->b = 0;

  last->left = first;
  last->right = NULL;
  last->tag = FUNC_LAST;
  last->x = last->y = 255;
  last->r = last->g = last->b = 255;

  func->first = first;
  func->last = last;

  return 1;
}

/**********************************************************************\
* Returns a copy of func, or NULL if not enough memory.                *
\**********************************************************************/
p_func func_clone(p_func old_func)
{
  p_func func;
  p_point n, o;

  if (!old_func || !old_func->first)
    return NULL;
  
  /* try to get memory */
  func = (p_func) calloc(1, sizeof(t_func));
  if (func == NULL)
    return NULL;

  func->dot_size = old_func->dot_size;

  /* first case is different... */
  n = calloc(1, sizeof(t_point));
  if (n == NULL) {
    free(func);
    return NULL;
  }

  func->first = func->last = n;
  o = old_func->first;
  memcpy(n, o, sizeof(t_point));
  n->left = n->right = NULL;

  o = o->right;
  
  /* at each loop, the function is always valid */
  while (o != NULL) {

    n = calloc(1, sizeof(t_point));
    if (n == NULL) {
      func_kill(func);
      return NULL;
    }

    memcpy(n, o, sizeof(t_point));

    n->right = NULL;
    func->last->right = n;
    n->left = func->last;
    func->last = n;

    o = o->right;
  }

  return func;
}

/**********************************************************************\
* Enumerates all the points of the function.                           *
\**********************************************************************/
p_point func_enum(p_func func, p_point last)
{
  p_point next;
  
  /* just checking... */
  if (func == NULL)
    return NULL;

  if (last == NULL)
    next = func->first;
  else
    next = last->right;

  return next;
}

/**********************************************************************\
* Enumerates all the points of the function backwards.                 *
\**********************************************************************/
p_point func_enumback(p_func func, p_point last)
{
  p_point next;
  
  /* just checking... */
  if (func == NULL)
    return NULL;

  if (last == NULL)
    next = func->last;
  else
    next = last->left;

  return next;
}

/**********************************************************************\
* Frees the memory used by the function.                               *
\**********************************************************************/
void func_kill(p_func func)
{
  p_point temp, killer;

  /* just checking... */
  if (func == NULL)
    return;

  /* if there are points, kill them */
  if ((killer = func->first) != NULL) {
    do {
      temp = killer->right;
      free(killer);
      killer = temp;
    } while (killer != NULL);
  }

  free(func);
}

/**********************************************************************\
* Deletes a point from the list, if the point is on the list.          *
\**********************************************************************/
void func_deletepoint(p_func func, p_point point)
{
  p_point temp = NULL;

  if (func == NULL || point == NULL)
    return;

  /* try to find the point */
  while (((temp = func_enum(func, temp)) != NULL) && temp != point);

  /* if we can't find it forget it */
  if (temp == NULL)
    return;

  switch (point->tag) {
    /* cannot delete the first or the last point */
    case FUNC_FIRST: case FUNC_LAST:
      return;
    /* easy, just remove it from the list and kill it */
    case FUNC_CONNECTED:
      point->left->right = point->right;
      point->right->left = point->left;
      free(point);
      break;
    /* here we must transform the point into a connected point */
    case FUNC_LEFT:
      point->left->right = point->right;
      point->right->left = point->left;
      point->right->tag = FUNC_CONNECTED;
      free(point);
      break;
    case FUNC_RIGHT:
      point->left->right = point->right;
      point->right->left = point->left;
      point->left->tag = FUNC_CONNECTED;
      free(point);
      break;
  }
}

/**********************************************************************\
* Insert a new point at a specified x coordinate, breaking the segment *
* to which x belongs into two connected segments.                      *
\**********************************************************************/
void func_splitconnected(p_func func, int x)
{
  p_point point;
  p_point middle;
  p_point left, right;

  /* long live short-circuit! */
  if (func == NULL || func->first == NULL || x <= 0 || x >= 255)
    return;

  /* advance to the first point of the segment to be broken */
  point = func->first;
  while ((point->right != NULL) && (point->right->x <= x))
    point = point->right;

  left = point;
  right = point->right;

  /* if we already have a point in this coordinate, ignore the call */
  if (x == left->x || x == right->x)
    return;

  /* get memory for the new point */
  middle = point_new();
  if (middle == NULL)
    return;

  middle->left = left;
  middle->right = right;
  middle->tag = FUNC_CONNECTED;
  middle->x = x;
  middle->y = segment_y(x, left->x, left->y, right->x, right->y);
  middle->r = segment_y(x, left->x, left->r, right->x, right->r);
  middle->g = segment_y(x, left->x, left->g, right->x, right->g);
  middle->b = segment_y(x, left->x, left->b, right->x, right->b);

  /* insert the new point in the broken segment */
  left->right = middle;
  right->left = middle;
}

/**********************************************************************\
* Insert a new point at a specified (x, y) coordinate, breaking the    *
* segment to which x belongs into two connected segments.              *
\**********************************************************************/
void func_insertconnected(p_func func, int x, int y, int r, int g, int b)
{
  p_point point;
  p_point middle;
  p_point left, right;

  /* long live short-circuit! */
  if (func == NULL || func->first == NULL || x <= 0 || x >= 255)
    return;

  /* advance to the first point of the segment to be broken */
  point = func->first;
  while ((point->right != NULL) && (point->right->x <= x))
    point = point->right;

  left = point;
  right = point->right;

  /* if we already have a point in this coordinate, ignore the call */
  if (x == left->x || x == right->x)
    return;

  /* get memory for the new point */
  middle = point_new();
  if (middle == NULL)
    return;

  middle->left = left;
  middle->right = right;
  middle->tag = FUNC_CONNECTED;
  middle->x = x;
  middle->r = r;
  middle->g = g;
  middle->b = b;
  middle->y = min(255, max(y, 0));

  /* insert the new point in the broken segment */
  left->right = middle;
  right->left = middle;
}

/**********************************************************************\
* Insert a new point at a specified x coordinate, breaking the segment *
* to which x belongs into two disconnected segments.                   *
\**********************************************************************/
void func_splitdisconnected(p_func func, int x)
{
  p_point point;
  p_point left, right;
  p_point middle_left, middle_right;

  /* just checking... */
  if (func == NULL || func->first == NULL || x <= 0 || x >= 255)
    return;

  /* advance to the first point of the segment to be broken */
  point = func->first;
  while ((point->right != NULL) && (point->right->x <= x))
    point = point->right;

  left = point;
  right = point->right;

  /* if we already have a point in this coordinate, ignore the call */
  if (x == left->x || x == right->x)
  return;

  /* get memory for the two new points */
  middle_left = point_new();
  middle_right = point_new();
  if (middle_left == NULL || middle_right == NULL) {
    if (middle_left) free(middle_left);
    if (middle_right) free(middle_right);
    return;
  }

  middle_left->tag = FUNC_LEFT;
  middle_right->tag = FUNC_RIGHT;
  middle_left->left = left;
  middle_left->right = middle_right;
  middle_right->left = middle_left;
  middle_right->right = right;
  middle_right->x = middle_left->x = x;
  middle_right->y = middle_left->y = segment_y(x, left->x, left->y, 
    right->x, right->y);
  middle_right->r = middle_left->r = segment_y(x, left->x, left->r, 
    right->x, right->r);
  middle_right->g = middle_left->g = segment_y(x, left->x, left->g, 
    right->x, right->g);
  middle_right->b = middle_left->b = segment_y(x, left->x, left->b, 
    right->x, right->b);

  /* insert the two new points in the broken segment */
  left->right = middle_left;
  right->left = middle_right;

  /* tilt a little the y position so that both point are visible */
  middle_left->y = max(0, middle_right->y - 1);
  middle_right->y = min(255, middle_right->y + 1);
}

/**********************************************************************\
* Insert a new point at a specified (x, y) coordinate, breaking the    *
* segment to which x belongs into two disconnected segments.           *
\**********************************************************************/
void func_insertdisconnected(p_func func, int x, int y1, int r1, int g1,
  int b1, int y2, int r2, int g2, int b2)
{
  p_point point;
  p_point left, right;
  p_point middle_left, middle_right;

  /* just checking... */
  if (func == NULL || func->first == NULL || x <= 0 || x >= 255)
    return;

  /* advance to the first point of the segment to be broken */
  point = func->first;
  while ((point->right != NULL) && (point->right->x <= x))
    point = point->right;

  left = point;
  right = point->right;

  /* if we already have a point in this coordinate, ignore the call */
  if (x == left->x || x == right->x)
  return;

  /* get memory for the two new points */
  middle_left = point_new();
  middle_right = point_new();
  if (middle_left == NULL || middle_right == NULL) {
    if (middle_left) free(middle_left);
    if (middle_right) free(middle_right);
    return;
  }

  middle_left->tag = FUNC_LEFT;
  middle_right->tag = FUNC_RIGHT;
  middle_left->left = left;
  middle_left->right = middle_right;
  middle_right->left = middle_left;
  middle_right->right = right;
  middle_right->x = middle_left->x = x;
  middle_left->r = r1;
  middle_left->g = g1;
  middle_left->b = b1;
  middle_right->r = r2;
  middle_right->g = g2;
  middle_right->b = b2;
  middle_left->y = min(255, max(y1, 0));
  middle_right->y = min(255, max(y2, 0));

  /* insert the two new points in the broken segment */
  left->right = middle_left;
  right->left = middle_right;
}

/**********************************************************************\
* Change y-coord of point, if y is in valid range.                     * 
* Returns 1 if altered, 0 if unaltered                                 *
\**********************************************************************/
int func_changey(p_func func, p_point point, int y)
{
  int old_y;

  /* just checking... */
  if (func == NULL || point == NULL) 
    return 0;

  old_y = point->y;
  point->y = max(0, min(y, 255));

  if (y == old_y)
    return 0;

  return 1;
}

/**********************************************************************\
* Change x-coord of point, if x is in valid range.                     * 
* Returns 1 if altered, 0 if unaltered                                 *
\**********************************************************************/
int func_changex(p_func func, p_point point, int x)
{
  int min_x, max_x, old_x;
  p_point associate;

  /* just checking... */
  if (func == NULL || point == NULL) 
    return 0;

  switch (point->tag) {

    /* in the LEFT and RIGHT cases, we have to keep the x-coords of 
    the associate points with the same value */
    case FUNC_LEFT: 
      old_x = point->x;
      associate = point->right;
      min_x = max(0, point->left->x + 1);
      max_x = min(255, associate->right->x - 1);
      point->x = min(max_x, max(min_x, x));
      associate->x = point->x;
      if (x == old_x)
        return 0;

      return 1;

    case FUNC_RIGHT:
      old_x = point->x;
      associate = point->left;
      min_x = max(0, associate->left->x + 1);
      max_x = min(255, point->right->x - 1);
      point->x = min(max_x, max(min_x, x));
      associate->x = point->x;
      if (x == old_x)
        return 0;

      return 1;

    /* in the CONNECTED there is only one coordinate to change */
    case FUNC_CONNECTED:
      old_x = point->x;
      min_x = max(0, point->left->x + 1);
      max_x = min(255, point->right->x - 1);
      point->x = min(max_x, max(min_x, x));
      if (x == old_x)
        return 0;

      return 1;

    /* the first and the last points have fixed x-coords */
    case FUNC_FIRST: case FUNC_LAST:
      return 0;
  }

  /* shouldn't get here... */
  return 0;
}

/**********************************************************************\
* Change x and y coordinates of point, if (x, y) is in valid range.    * 
* Returns 1 if altered, 0 if unaltered                                 *
\**********************************************************************/
int func_changexy(p_func func, p_point point, int x, int y)
{
  int result = 0;
  
  result += func_changex(func, point, x);
  result += func_changey(func, point, y);

  return (result != 0);
}

/**********************************************************************\
* Change color of point.                                               * 
* Returns 1 if altered, 0 if unaltered                                 *
\**********************************************************************/
int func_changecolor(p_func func, p_point point, int r, int g, int b)
{
  /* just checking... */
  if (func == NULL || point == NULL) 
    return 0;

  point->r = max(0, min(r, 255));
  point->g = max(0, min(g, 255));
  point->b = max(0, min(b, 255));

  return 1;
}

/**********************************************************************\
* Returns the first point hit by the coortinate (xp, yp), after last.  *
* in the list. If last is NULL, the first point hit is returned. If no *
* point is hit after last, the function returns NULL.                  *
\**********************************************************************/
p_point func_pickxy(p_func func, p_point last, int xp, int yp)
{
  p_point point;
  int x, y;

  point = last;
  while ((point = func_enum(func, point)) != NULL) {
    func_getxy(point, &x, &y, NULL);
    if (abs(xp-x) <= func->dot_size && abs(yp-y) <= func->dot_size)
        break;
  }

  return point;
}

/**********************************************************************\
* Returns the first point hit by the coortinate (xp, yp), after last.  *
* in the list. If last is NULL, the first point hit is returned. If no *
* point is hit the function returns NULL. Else, the function cycles    *
* through all points hit.                                              *
\**********************************************************************/
p_point func_pickxycycle(p_func func, p_point last, int xp, int yp)
{
  p_point temp;

  temp = func_pickxy(func, last, xp, yp);
  if (temp == NULL)
    return func_pickxy(func, NULL, xp, yp);
  else
    return temp;
}

/**********************************************************************\
* Returns the first point hit by the coortinate xp (ignoring the y     *
* coordinate), after last in the list. If last is NULL, the first      *
* point hit is returned. If no point after last is hit the function    *
* returns NULL.                                                        *
\**********************************************************************/
p_point func_pickx(p_func func, p_point last, int xp)
{
  p_point point;
  int x;

  point = last;
  while ((point = func_enum(func, point)) != NULL) {
    func_getxy(point, &x, NULL, NULL);
    if (abs(xp-x) <= func->dot_size)
      if (point != last)
        break;
  }

  return point;
}

/**********************************************************************\
* Returns the first point hit by the coortinate xp (ignoring the y     *
* coordinate), after last in the list. If last is NULL, the first      *
* point hit is returned. If no point is hit the function returns NULL. *
* Else, the function cycles through all hit points.                    *
\**********************************************************************/
p_point func_pickxcycle(p_func func, p_point last, int xp)
{
  p_point temp;

  temp = func_pickx(func, last, xp);
  if (temp == NULL)
    return func_pickx(func, NULL, xp);
  else
    return temp;
}

/**********************************************************************\
* Gets the point fields.                                               * 
\**********************************************************************/
void func_getxy(p_point point, int *x, int *y, int *tag)
{
  if (point == NULL) {
    if (x) *x = 0;
    if (y) *y = 0;
    if (tag) *tag = -1;
    return;
  }

  if (x) *x = point->x;
  if (y) *y = point->y;
  if (tag) *tag = point->tag;
}

/**********************************************************************\
* Gets the point color.                                                * 
\**********************************************************************/
void func_getcolor(p_point point, int *x, int *r, int *g, int *b, int *tag)
{
  if (point == NULL) {
    if (r) *r = 0;
    if (g) *g = 0;
    if (b) *b = 0;
    if (x) *x = 0;
    if (tag) *tag = -1;
    return;
  }

  if (r) *r = point->r;
  if (g) *g = point->g;
  if (b) *b = point->b;
  if (x) *x = point->x;
  if (tag) *tag = point->tag;
}

/**********************************************************************\
* Auxiliary functions.                                                 * 
\**********************************************************************/
static void func_main(void)
{
  p_func func;
  p_point point;

  func = func_create(2);
  
  func_splitconnected(func, 64);
  func_splitdisconnected(func, 130);
  func_splitconnected(func, 80);
  
  printf("Listing...\n");
  func_print(func);
  
  printf("Picking...\n");
  point = func_pickxy(func, NULL, 10, 20);
  point_print(point);
  point = func_pickxy(func, NULL, 255, 255);
  point_print(point);
  point = func_pickxy(func, NULL, 82, 77);
  point_print(point);

  func_kill(func);
}

/**********************************************************************\
* Prints the all the points of the function.                           * 
\**********************************************************************/
void func_print(p_func func)
{
  p_point point = NULL;

  while ((point = func_enum(func, point)) != NULL)
    point_print(point);
}

/**********************************************************************\
* Prints the information of a point.                                   * 
\**********************************************************************/
static void point_print(p_point point)
{
  char *type;

  if (point == NULL) {
    printf("null\n");
    return;
  }

  switch(point->tag) {
    case FUNC_FIRST:
      type = "first"; break;
    case FUNC_LAST:
      type = "last"; break;
    case FUNC_CONNECTED:
      type = "connected"; break;
    case FUNC_LEFT:
      type = "open"; break;
    case FUNC_RIGHT:
      type = "closed"; break;
  }

  printf("%s, (%d, %d)\n", type, point->x, point->y);
}

/**********************************************************************\
* Allocates memory for a point.                                        * 
\**********************************************************************/
static p_point point_new(void)
{
  return (p_point) calloc(1, sizeof(t_point));
}


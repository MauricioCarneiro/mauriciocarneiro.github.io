/***************************************************************************\
* LUT.H                                                                     *
* Interative transference function look up table editor for DVR programs.   *
* Diego Nehab, 14/11/97                                                     *
\***************************************************************************/

#ifndef __LUT_H
#define __LUT_H

/***************************************************************************\
* Definitions.                                                              *
\***************************************************************************/
enum {
  LUT_OK,
  LUT_CANCEL,
  LUT_APPLY
};

/***************************************************************************\
* Defines.                                                                  *
\***************************************************************************/

#define LUT_CANVASHEIGHT 256
#define LUT_CANVASWIDTH  256


typedef void (*p_callback) (int what);

/***************************************************************************\
* Initialize transference function editor. With the initial values for the  *
* data that the program will handle                                         *
\***************************************************************************/
int lut_open(int nclasses, int xi, int xf);

/***************************************************************************\
* Shows function editor window.                                             *
\***************************************************************************/
void lut_show(void);

/***************************************************************************\
* Hides function window editor.                                             *
\***************************************************************************/
void lut_hide(void);

/***************************************************************************\
* Read function definition from file.                                       *
\***************************************************************************/
int lut_load(char *file);

/***************************************************************************\
* Save current function definition to file.                                 *
\***************************************************************************/
int lut_save(char *file);

/***************************************************************************\
* Get a discrete map of the currently defined function. The vector MUST be  *
* long enough to hold 256 values.                                           *
\***************************************************************************/
void lut_fillopacity(double *opacity);

/***************************************************************************\
* Get a discrete map of the currently defined palette. The vectors MUST be  *
* long enough to hold 256 values each.                                      *
\***************************************************************************/
void lut_fillcolor(char *red, char *green, char *blue);

/***************************************************************************\
* Loads a histogram to be used as the background of the function editor.    *
* The vector defines the voxel count for each density value. Passing a NULL *
* vector disables the current histogram. Countsize is the size of the       *
* histogram                                                                 *
\***************************************************************************/
int lut_histogram(long int *count, int countsize);

/***************************************************************************\
* Sets the callback function void callback(int what), that will be called   *
* to notify the program of the choice of the user LUT_OK, LUT_APPLY or      *
* LUT_CANCEL. Passing a NULL parameter unsets the callback.                 *
\***************************************************************************/
void lut_setcallback(p_callback callback);

#endif

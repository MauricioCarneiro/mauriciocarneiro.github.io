/**********************************************************************\
* FUNCLUA.H                                                            *
* Persistence support for the FUNC module.                             *
* Diego Nehab, 10/2/99                                                 *
\**********************************************************************/

#ifndef __FUNCLUA_H
#define __FUNCLUA_H

/**********************************************************************\
* Initializes the persistency module.                                  *
\**********************************************************************/
void funclua_open(void);

/**********************************************************************\
* Loads a transfer function from file into func.                       *
\**********************************************************************/
int funclua_load(p_func func, char *file);

/**********************************************************************\
* Saves a transfer function from func to file.                         *
\**********************************************************************/
int funclua_save(p_func func, char *file);

#endif





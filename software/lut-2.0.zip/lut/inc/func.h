/**********************************************************************\
* FUNC.H                                                               *
* Linear by parts function data structure.                             *
* Diego Nehab, 10/2/99                                                 *
\**********************************************************************/

#ifndef __FUNC_H
#define __FUNC_H

/**********************************************************************\
* Data types definitions.                                              *
\**********************************************************************/
typedef enum {
  FUNC_FIRST,
  FUNC_LEFT,
  FUNC_RIGHT,
  FUNC_CONNECTED,
  FUNC_LAST
};

typedef struct _t_point *p_point;
typedef struct _t_point {
  int tag;
  int x, y;
  int r, g, b;
  p_point left, right;
} t_point;

typedef struct _t_func *p_func;
typedef struct _t_func {
  p_point first;
  p_point last;
  int dot_size;
} t_func;

/**********************************************************************\
* Returns a pointer to an initial function, the identity function.     *
\**********************************************************************/
p_func func_create(int dot_size);

/**********************************************************************\
* Resets a function to identity.                                       *
\**********************************************************************/
int func_reset(p_func func);

/**********************************************************************\
* Returns a copy of func, or NULL if not enough memory.                *
\**********************************************************************/
p_func func_clone(p_func func);

/**********************************************************************\
* Frees the memory used by the function.                               *
\**********************************************************************/
void func_kill(p_func func);

/**********************************************************************\
* Gets the point fields.                                               * 
\**********************************************************************/
void func_getxy(p_point point, int *x, int *y, int *tag);

/**********************************************************************\
* Gets the point fields.                                               * 
\**********************************************************************/
void func_getcolor(p_point point, int *x, int *r, int *g, int *b, int *tag);

/**********************************************************************\
* Enumerates all the points of the function.                           *
\**********************************************************************/
p_point func_enum(p_func func, p_point last);

/**********************************************************************\
* Enumerates all the points of the function backwards.                 *
\**********************************************************************/
p_point func_enumback(p_func func, p_point last);

/**********************************************************************\
* Deletes a point from the list, if the point is on the list.          *
\**********************************************************************/
void func_deletepoint(p_func func, p_point point);

/**********************************************************************\
* Insert a new point at a specified x coordinate, breaking the segment *
* to which x belongs into two connected segments.                      *
\**********************************************************************/
void func_splitconnected(p_func func, int x);

/**********************************************************************\
* Insert a new point at a specified x coordinate, breaking the segment *
* to which x belongs into two disconnected segments.                   *
\**********************************************************************/
void func_splitdisconnected(p_func func, int x);

/**********************************************************************\
* Insert a new point at a specified (x, y) coordinate, breaking the    *
* segment to which x belongs into two connected segments.              *
\**********************************************************************/
void func_insertconnected(p_func func, int x, int y, int r, int g, int b);

/**********************************************************************\
* Insert a new point at a specified (x, y1) and (x, y2) coordinate,    *
* breaking the segment to which x belongs into two disconnected        *
* segments.                                                            *
\**********************************************************************/
void func_insertdisconnected(p_func func, int x, int y1, int r1, int g1,
  int b1, int y2, int r2, int g2, int b2);

/**********************************************************************\
* Change y-coord of point, if y is in valid range.                     * 
* Returns 1 if altered, 0 if unaltered                                 *
\**********************************************************************/
int func_changey(p_func func, p_point point, int y);

/**********************************************************************\
* Change x-coord of point, if x is in valid range.                     * 
* Returns 1 if altered, 0 if unaltered                                 *
\**********************************************************************/
int func_changex(p_func func, p_point point, int x);

/**********************************************************************\
* Change x and y coordinates of point, if (x, y) is in valid range.    * 
* Returns 1 if altered, 0 if unaltered                                 *
\**********************************************************************/
int func_changexy(p_func func, p_point point, int x, int y);

/**********************************************************************\
* Change color of point.                                               * 
* Returns 1 if altered, 0 if unaltered                                 *
\**********************************************************************/
int func_changecolor(p_func func, p_point point, int r, int g, int b);

/**********************************************************************\
* Returns the first point hit by the coortinate xp (ignoring the y     *
* coordinate), after last in the list. If last is NULL, the first      *
* point hit is returned. If no point is hit the function returns NULL. *
\**********************************************************************/
p_point func_pickx(p_func func, p_point last, int xp);

/**********************************************************************\
* Returns the first point hit by the coortinate xp (ignoring the y     *
* coordinate), after last in the list. If last is NULL, the first      *
* point hit is returned. If no point is hit the function returns NULL. *
* Else, the function cycles through all hit points.                    *
\**********************************************************************/
p_point func_pickxcycle(p_func func, p_point last, int xp);

/**********************************************************************\
* Returns the first point hit by the coortinate (xp, yp), after last.  * 
* If last is NULL, the first point hit is returned. If no point is hit *
* the function returns NULL.                                           *
\**********************************************************************/
p_point func_pickxy(p_func func, p_point last, int xp, int yp);

/**********************************************************************\
* Returns the first point hit by the coortinate (xp, yp), after last.  *
* in the list. If last is NULL, the first point hit is returned. If no *
* point is hit the function returns NULL. Else, the function cycles    *
* through all points hit.                                              *
\**********************************************************************/
p_point func_pickxycycle(p_func func, p_point last, int xp, int yp);

/**********************************************************************\
* Prints the all the points of the function.                           * 
\**********************************************************************/
void func_print(p_func func);


#endif
/***********************************************************************\
* TRANS.H                                                               *
* linear transforms to adjust data from screen to world coordinates.    *
* Autor : Mauricio Oliveira Carneiro, 27/4/2000                         *
\***********************************************************************/

#ifndef __TRANS_H
#define __TRANS_H

/**********************************************************************\
* Defines                                                              *
\**********************************************************************/

#define TRANS_HEIGHTPRECISION  65536
#define TRANS_ZOOM_FACTOR        0.8   /* 1 - zoomin % */

/**********************************************************************\
* Structures                                                           *
\**********************************************************************/
typedef struct undo undo, *p_undo;

typedef struct _t_trans *p_trans;
typedef struct _t_trans { 
  int trans_xs;     // Xo of the Screen
  int trans_ys;     // Yo of the Screen 
  int trans_ws;     // Width of the Screen
  int trans_hs;     // Height of the Screen
  int trans_xw;     // Xo of the World
  int trans_yw;     // Yo of the World
  int trans_ww;     // Width of the World
  int trans_hw;     // Height of the World

  int trans_maxhistvalue; // Maximum histogram Y value

  float trans_axsw; // Screen to World transform coeficient
  float trans_bxsw; // Screen to World transform linear coeficient
  float trans_aysw; // Screen to World transform coeficient
  float trans_bysw; // Screen to World transform linear coeficient
  float trans_axws; // World to screen transform coeficient
  float trans_bxws; // World to screen transform linear coeficient
  float trans_ayws; // World to screen transform coeficient
  float trans_byws; // World to screen transform linear coeficient

  // undo structure

  struct undo
  {
    int trans_lastxs; // Last Xo of the Screen
    int trans_lastys; // Last Yo of the Screen 
    int trans_lastws; // Last Width of the Screen
    int trans_lasths; // Last Height of the Screen
    float trans_lastaxsw; // Last Screen to World transform coeficient
    float trans_lastbxsw; // Last Screen to World transform linear coeficient
    float trans_lastaysw; // Last Screen to World transform coeficient
    float trans_lastbysw; // Last Screen to World transform linear coeficient
    float trans_lastaxws; // Last World to screen transform coeficient
    float trans_lastbxws; // Last World to screen transform linear coeficient
    float trans_lastayws; // Last World to screen transform coeficient
    float trans_lastbyws; // Last World to screen transform linear coeficient

    struct undo *next,*last;
  } *u;
} t_trans;


/* ALL INTERFACE FUNCTIONS FROM THIS STRUCTURE HAVE A POINTER TO THE MOTHER
   STRUCTURE AS THE FIRST PARAMETER */


/**********************************************************************\
* Returns a pointer to an initial function, the identity function.     *
\**********************************************************************/

p_trans trans_create(int newww);

/***********************************************************************\
* Resets the transform parameters to Default.                           *
\***********************************************************************/

int trans_resettransform(p_trans t);

/***********************************************************************\
* Zooms in                                                              *
\***********************************************************************/
void trans_zoomin (p_trans t, int x, int y, int w, int h);

/***********************************************************************\
* Zooms out                                                             *
\***********************************************************************/
void trans_zoomout (p_trans t, int x, int y, int w, int h);

/***********************************************************************\
* Moves the entire screen                                               *
\***********************************************************************/
void trans_panning (p_trans t, int x, int y);


/***********************************************************************\
* Set size of transforms.                                               *
\***********************************************************************/

void trans_settransform(p_trans *t, int x, int y, int w, int h);

/***********************************************************************\
* Transform from world coordinates to screen coordinates                *
\***********************************************************************/

void trans_worldtoscreen(p_trans t, int *xs, int *ys, int x, int y);

/***********************************************************************\
* Transform from screen coordinates to world coordinates                *
\***********************************************************************/

void trans_screentoworld(p_trans t, int *xw, int *yw, int x, int y);

/***********************************************************************\
* Transform from screen to world scale                                  *
\***********************************************************************/

void trans_screentoworldscale(p_trans t, int *alpha, int *beta);

/***********************************************************************\
* Transform from world to screen scale                                  *
\***********************************************************************/

void trans_worldtoscreenscale(p_trans t, int *alpha, int *beta);

/***********************************************************************\
* Calculates the coeficients of a transformation                        *
\***********************************************************************/

int trans_calccoeficients(p_trans t);

/***********************************************************************\
* Clips points that are no longer inside the viewport                   *
\***********************************************************************/

int trans_clip(int realinteger);

/***********************************************************************\
* Push actual transformation into the stack                             *
\***********************************************************************/

int trans_pushtransform(p_trans t);

/***********************************************************************\
* Pops the last transformation from stack                               *
\***********************************************************************/

int trans_poptransform(p_trans t);

/***********************************************************************\
* Sets the maximum histogram Y value (for bounding reasons)             *
\***********************************************************************/

void trans_setmaxhistvalue(p_trans t, int max);

#endif